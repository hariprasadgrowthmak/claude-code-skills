---
name: meta-ads-expert
description: An autonomous skill for end-to-end Meta Ads marketing, including competitor research, ad copy and creative generation, landing page strategy, scientific creative testing, advanced tracking, campaign management, performance monitoring, optimization, and post-conversion retention. Use this skill for managing comprehensive Meta Ads campaigns with built-in human approval checkpoints.
---

# Meta Ads Expert

## Overview

This skill transforms Manus into a specialized Meta Ads marketing expert, capable of executing a full-lifecycle advertising strategy at an elite agency level. It automates the process of identifying winning competitor ads, extracting their core elements, generating new high-performing ad copy and video creatives, designing conversion-optimized landing pages, implementing advanced tracking, conducting scientific creative testing, assisting with campaign setup, and providing continuous monitoring, optimization, and post-conversion retention strategies. A key feature is the integration of human-in-the-loop approval mechanisms at critical decision points, ensuring transparency and control over campaign execution.

## Core Capabilities

This skill provides a structured workflow for managing Meta Ads campaigns, broken down into the following core capabilities:

### 1. Competitor Research & Analysis

**Objective:** Identify high-performing competitor ads to inform strategy and creative development.

**Process:**
1.  **Facebook Ads Library Access:** Navigate to the Facebook Ads Library (https://www.facebook.com/ads/library/) to search for competitors by name or Facebook Page IDs.
2.  **Winning Ad Selection:** Identify ads that have been running for 6-7 months, indicating sustained success.
3.  **Creative Extraction:** Download video creatives and analyze ad copy from selected winning ads.

**Human-in-the-Loop:** Manus will present a summary of identified winning ads and their running duration, asking for user confirmation to proceed with creative extraction.

### 2. Offer Engineering & Hook Mapping

**Objective:** Optimize the core offer and ensure alignment between ad creative hooks and landing page value propositions for maximum conversion.

**Process:**
1.  **Offer Analysis:** Evaluate the competitiveness and appeal of the user's current offer (e.g., lead magnet, discount, product value).
2.  **Hook Mapping:** Analyze competitor hooks and align them with the user's offer to create compelling ad narratives.
3.  **Value Proposition Refinement:** Refine the core value proposition to resonate deeply with the target audience.

**Human-in-the-Loop:** Manus will present the analyzed offer, proposed hook mapping, and refined value proposition, asking for user approval before proceeding.

### 3. Ad Script Extraction

**Objective:** Convert video ad creatives into text scripts for analysis.

**Process:**
1.  **Video to Transcript Conversion:** Utilize external tools (e.g., via web search for "video to transcript converter") to generate text transcripts from the downloaded video ads.
2.  **Script Collection:** Collect transcripts from a minimum of 10 winning ads.

**Human-in-the-Loop:** Manus will present the extracted scripts and ask for user approval before proceeding to AI script generation.

### 4. AI Ad Script Generation

**Objective:** Generate new, high-converting ad scripts based on successful competitor patterns and user product details.

**Process:**
1.  **Common Element Analysis:** Analyze the collected scripts to identify 15 common, high-impact elements (e.g., hooks, calls-to-action, pain points, benefits, social proof).
2.  **Product Context Integration:** Incorporate the user's product description and advertising goals.
3.  **AI-Powered Scripting:** Use an advanced language model (e.g., ChatGPT) with a tailored prompt to generate 10 new ad scripts, explicitly leveraging the identified common elements and product context.

**Human-in-the-Loop:** Manus will present the generated ad scripts and ask for user review and selection before proceeding to video creative generation.

**Best Output File Format:** Markdown (`.md`) or plain text (`.txt`) for easy review and editing. For structured data, CSV (`.csv`) can be used.

### 5. Landing Page Strategy & Design

**Objective:** Design a conversion-optimized landing page (LP) that aligns with the ad strategy and optimized offer.

**Process:**
1.  **Funnel Determination:** Based on competitor research and offer engineering, determine the optimal marketing funnel (e.g., Direct-to-Offer, Lead Magnet, Quiz Funnel).
2.  **Copywriting Framework:** Apply proven frameworks like AIDA (Attention, Interest, Desire, Action) or PAS (Problem, Agitation, Solution) to draft the LP content, ensuring alignment with ad hooks.
3.  **Prompt-Based Design:** Use AI-powered design tools (e.g., Kleap, LanderLab, or prompt-to-Figma) to generate a visual preview of the landing page.
4.  **Conversion Optimization:** Ensure the LP includes clear CTAs, social proof, and mobile-responsive layouts.

**Human-in-the-Loop:** Manus will present the landing page strategy, the drafted copy, and a visual preview (screenshot or link) for user approval before proceeding to campaign setup.

**Best Output File Format:** Markdown (`.md`) for the copy and strategy, and a PNG/WebP screenshot for the visual preview.

### 6. Ad Creative Generation

**Objective:** Produce initial video ad creatives in required formats based on the approved scripts.

**Process:**
1.  **Video Generation:** Utilize AI-powered video generation tools to create video ads from the selected scripts.
2.  **Format Adaptation:** Generate videos in common Meta Ads formats (e.g., 1:1 for feed, 9:16 for stories/reels).

**Human-in-the-Loop:** Manus will present the generated video creatives for user review and final approval before scientific creative testing.

**Best Output File Format:** MP4 (`.mp4`) for video files, accompanied by a Markdown (`.md`) file detailing the script used for each video.

### 7. Scientific Creative Testing (3:2:2 Method)

**Objective:** Systematically test creative elements to identify winning combinations before scaling campaigns.

**Process:**
1.  **Test Design:** Implement a structured testing methodology (e.g., 3 hooks, 2 bodies, 2 CTAs) to isolate winning creative elements.
2.  **Small Budget Deployment:** Launch a small-scale campaign with varied creative combinations to gather performance data.
3.  **Data Analysis:** Analyze key metrics (CTR, CVR, CPC) to identify top-performing creative "DNA."

**Human-in-the-Loop:** Manus will present the creative testing results and the identified winning creative elements, asking for user approval to proceed with scaling.

### 8. Tracking & Attribution Architecture

**Objective:** Ensure robust and accurate conversion tracking through server-side implementation.

**Process:**
1.  **CAPI Implementation Plan:** Develop a plan for implementing Meta Conversions API (CAPI) to send server-side events.
2.  **Event Mapping:** Map key conversion events (e.g., Purchase, Lead, AddToCart) to CAPI.
3.  **Testing & Verification:** Verify CAPI implementation using Meta Event Manager to ensure data accuracy and deduplication.

**Human-in-the-Loop:** Manus will present the CAPI implementation plan and verification results, asking for user approval before campaign launch.

### 9. Campaign Creation & Management Assistance

**Objective:** Assist in setting up and managing Meta Ads campaigns.

**Process:**
1.  **Campaign Configuration:** Guide the user through campaign objective selection, audience targeting, budget allocation, and ad set creation within Meta Ads Manager.
2.  **Ad Placement:** Upload approved creatives and ad copy to appropriate ad placements.

**Human-in-the-Loop:** For sensitive actions like publishing a campaign or making significant budget changes, Manus will require explicit user confirmation, detailing the "Current Status" and "Expected Impact" of the action.

### 10. Performance Monitoring & Optimization

**Objective:** Continuously monitor campaign performance, identify trends, and recommend optimizations.

**Process:**
1.  **Natural Language Reporting:** Provide regular performance summaries and insights (e.g., "Summarize performance over the last 7 days and explain why ROAS declined.").
2.  **Anomaly Detection:** Proactively flag unusual performance shifts (e.g., sudden CPA spikes, unexpected delivery drops).
3.  **Optimization Recommendations:** Suggest specific actions to improve campaign performance (e.g., "Increase budget for Ad Set X by 15% due to high ROAS," "Pause Ad Y due to low CTR").

**Human-in-the-Loop:** All optimization recommendations will be presented to the user with "Current Status" and "Expected Impact" for approval before execution.

**Best Output File Formats:**
*   **Audit/Reports:** Markdown (`.md`) for detailed analysis and insights, PDF (`.pdf`) for final, shareable reports. Raw data can be provided in CSV (`.csv`).
*   **Optimization Recommendations:** Markdown (`.md`) for clear, actionable steps.

### 11. Post-Click Experience & Retention

**Objective:** Maximize the value of generated leads and customers through effective post-conversion strategies.

**Process:**
1.  **CRM Integration Plan:** Develop a plan for integrating lead data from landing pages into a CRM system.
2.  **Follow-up Sequence Design:** Outline immediate email or SMS follow-up sequences for new leads to nurture them towards conversion.
3.  **Retention Strategy:** Suggest strategies for customer retention and repeat purchases.

**Human-in-the-Loop:** Manus will present the proposed CRM integration and follow-up sequences, asking for user approval to implement.

## Human-in-the-Loop Approval Process

At critical junctures, this skill will pause and request user approval. For each approval step, Manus will provide:

*   **Current Status:** A clear, concise summary of the current state, relevant data, and what has been achieved so far.
*   **Expected Impact:** An explanation of what will happen if the proposed action is approved, including potential benefits or risks.

This ensures that the user maintains full control and understanding of the campaign at all times.

## Resources

This skill will utilize the following types of resources:

### scripts/
*   `video_to_transcript.py`: A script to interface with video-to-transcript APIs or local tools.
*   `ad_elements_analyzer.py`: A script to programmatically identify common elements in ad scripts.
*   `video_generator.py`: A script to interface with AI video generation APIs.
*   `lp_content_generator.py`: A script to generate landing page copy using specific marketing frameworks.
*   `capi_implementer.py`: A script to assist with Meta CAPI implementation and verification.
*   `creative_tester.py`: A script to manage and analyze scientific creative tests.
*   `crm_integrator.py`: A script to assist with CRM integration and follow-up automation.

### references/
*   `meta_ads_api_guide.md`: A reference document for common Meta Ads API calls and best practices.
*   `winning_ad_criteria.md`: Detailed criteria for identifying successful ads (e.g., duration, engagement metrics).
*   `chatgpt_prompts.md`: Templates for effective prompts to generate ad copy and scripts.
*   `copywriting_frameworks.md`: Detailed guide on AIDA, PAS, and other conversion frameworks.
*   `capi_best_practices.md`: Best practices for Meta Conversions API implementation.
*   `creative_testing_methodologies.md`: Guide on scientific creative testing methods (e.g., 3:2:2).
*   `offer_optimization_guide.md`: Guide on engineering compelling offers and hook mapping.
*   `crm_followup_strategies.md`: Strategies for effective post-conversion follow-up.

### templates/
*   `ad_script_template.md`: A Markdown template for structuring generated ad scripts.
*   `lp_strategy_template.md`: A template for presenting landing page strategy and copy.
*   `report_template.md`: A Markdown template for performance audit and optimization reports.
*   `video_creative_specs.json`: A JSON file detailing required video ad specifications (resolutions, aspect ratios, lengths).
*   `capi_event_mapping.json`: A JSON template for mapping conversion events.
*   `creative_test_report.md`: A Markdown template for scientific creative testing results.
*   `crm_sequence_template.md`: A Markdown template for outlining email/SMS follow-up sequences.
