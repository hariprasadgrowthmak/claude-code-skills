# Winning Ad Criteria

This document outlines the criteria used to identify "winning" or high-performing Facebook ads from the Ads Library.

## Primary Criteria

1.  **Running Duration:** Ads that have been active for **6-7 months or longer** are considered strong indicators of success, as advertisers typically pause underperforming creatives.
2.  **Ad Type:** Focus primarily on video ads, as they are often more engaging and provide richer content for script extraction.

## Secondary Indicators (for manual review, if needed)

*   **Engagement Metrics:** High number of likes, comments, shares (though not directly accessible via Ads Library API, can be inferred from public-facing ads).
*   **Creative Consistency:** Brands running similar creative concepts across multiple ads or campaigns.
*   **Call to Action (CTA):** Clear and compelling CTAs.

## Data Points to Collect per Ad

*   Ad ID
*   Advertiser Name/Page ID
*   Start Date
*   End Date (if applicable)
*   Platform (Facebook, Instagram, Audience Network, Messenger)
*   Creative Type (Image, Video, Carousel)
*   Video URL (for download)
*   Ad Copy Text
*   CTA Button Text
*   Landing Page URL
