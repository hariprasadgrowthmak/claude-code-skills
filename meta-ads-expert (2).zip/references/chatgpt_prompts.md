# ChatGPT Prompts for Ad Script Generation

This document contains templates for prompts to be used with large language models (LLMs) like ChatGPT for generating ad copy and video scripts.

## Prompt for Identifying Common Elements

```
Analyze the following 10 ad scripts. Identify and list 15 common, high-impact elements that contribute to their effectiveness. These elements could include, but are not limited to: strong hooks, clear problem statements, compelling benefits, unique selling propositions (USPs), social proof, urgency, calls-to-action (CTAs), emotional appeals, storytelling, specific product features, guarantees, scarcity, curiosity, authority, and relatable scenarios.

[Insert 10 ad scripts here]
```

## Prompt for Generating New Ad Scripts

```
My product is [Your Product Description]. My advertising goal is [Your Advertising Goal, e.g., drive website traffic, increase conversions, generate leads].

I have analyzed my top 10 performing competitor ads, and the following 15 elements were common among them:

[Insert 15 common elements here, e.g.,
- Strong, attention-grabbing hook
- Clearly stated problem that the product solves
- Focus on key benefits rather than just features
- Inclusion of social proof (testimonials, reviews)
- Clear and urgent call-to-action
...]

Based on these 15 common elements and considering my product and advertising goal, write 10 unique video ad scripts. Each script should be concise, engaging, and designed to maximize conversions. Ensure each script incorporates at least 5-7 of the identified common elements naturally. For each script, also suggest a visual concept.

Product Description: [Detailed description of the product, its features, and benefits]
Advertising Goal: [Specific goal for the ad campaign]
```
