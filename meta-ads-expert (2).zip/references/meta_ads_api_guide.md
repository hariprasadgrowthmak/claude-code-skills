# Meta Ads API Guide

This document provides a high-level overview and best practices for interacting with the Meta Ads API.

## Key Concepts

*   **Access Tokens:** Required for authenticating API requests. Ensure proper handling and refreshing.
*   **Graph API:** The primary way to interact with Meta's social graph, including Ads Manager data.
*   **Rate Limiting:** Be mindful of API rate limits to avoid service interruptions.

## Common API Endpoints

*   `/me/adaccounts`: Retrieve a list of ad accounts associated with the current user.
*   `/{ad-account-id}/campaigns`: Manage campaigns within a specific ad account.
*   `/{ad-account-id}/ads`: Manage individual ads.
*   `/{ad-account-id}/insights`: Retrieve performance data and metrics.

## Best Practices for AI Agents

1.  **Read-Only First:** Prioritize read-only operations (e.g., fetching insights, ad creatives) before attempting write operations.
2.  **Granular Permissions:** Request only the necessary permissions for each task.
3.  **Error Handling:** Implement robust error handling for API responses.
4.  **Asynchronous Operations:** Utilize asynchronous calls for efficiency when dealing with large datasets.
5.  **Human-in-the-Loop:** For any destructive or budget-altering operations, always seek user confirmation.

## Further Reading

*   [Meta Marketing API Documentation](https://developers.facebook.com/docs/marketing-api)
*   [Facebook Ads Library API](https://www.facebook.com/ads/library/api/)
