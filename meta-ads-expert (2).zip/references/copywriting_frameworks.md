# Conversion Copywriting Frameworks

This document outlines the primary copywriting frameworks used to create high-converting landing pages and ad copy.

## 1. AIDA (Attention, Interest, Desire, Action)

**Best for:** Sales pages, direct-response ads, and landing pages for new products.

*   **Attention:** Grab the reader's attention with a bold headline or hook.
*   **Interest:** Provide interesting facts, statistics, or stories to keep them reading.
*   **Desire:** Build a desire for the product by highlighting benefits and solving pain points.
*   **Action:** Provide a clear and compelling call to action (CTA).

## 2. PAS (Problem, Agitation, Solution)

**Best for:** Landing pages addressing specific pain points or complex problems.

*   **Problem:** Clearly identify the problem the target audience is facing.
*   **Agitation:** Agitate the problem by explaining the consequences of not solving it.
*   **Solution:** Present your product or service as the ultimate solution.

## 3. BAB (Before-After-Bridge)

**Best for:** Case studies, testimonials, and transformation-focused landing pages.

*   **Before:** Describe the world of the prospect before using your product (the pain).
*   **After:** Describe the world of the prospect after using your product (the pleasure).
*   **Bridge:** Explain how your product is the bridge that gets them from Before to After.

## 4. FAB (Features, Advantages, Benefits)

**Best for:** Product detail pages and technical landing pages.

*   **Features:** What the product does or has.
*   **Advantages:** Why those features matter.
*   **Benefits:** What the user actually gets out of it (the emotional or practical win).

## 5. The 4 P's (Promise, Picture, Proof, Push)

**Best for:** Long-form sales letters and comprehensive landing pages.

*   **Promise:** Make a big promise early on.
*   **Picture:** Paint a picture of the results.
*   **Proof:** Provide evidence (testimonials, data, case studies).
*   **Push:** Give them a final push to take action.
