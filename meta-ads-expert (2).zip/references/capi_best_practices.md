# Meta Conversions API (CAPI) Best Practices

This document outlines best practices for implementing and verifying Meta Conversions API (CAPI) to ensure accurate and robust conversion tracking.

## 1. Why CAPI?

*   **Data Accuracy:** Overcomes limitations of browser-side tracking (ad blockers, cookie restrictions).
*   **Enhanced Measurement:** Provides a more complete view of the customer journey.
*   **Improved Optimization:** Feeds more reliable data back to Meta for better ad delivery and optimization.

## 2. Implementation Steps

1.  **Choose an Integration Method:**
    *   Direct Integration (server-to-server)
    *   Partner Integrations (e.g., Shopify, Segment, Zapier)
    *   Gateway Solutions (e.g., Google Tag Manager Server-Side)
2.  **Event Deduplication:** Implement `event_id` and `event_name` parameters to prevent duplicate events when using both Pixel and CAPI.
3.  **Customer Information Parameters (CIPs):** Send as many hashed customer data parameters as possible (email, phone, name, address) to improve match rates.
4.  **Event Matching Quality:** Aim for an Event Matching Quality score of "Good" or "Excellent" in Events Manager.

## 3. Verification

*   **Test Events Tool:** Use the "Test Events" tool in Meta Events Manager to send test events and verify successful reception.
*   **Event Debugging:** Monitor server logs and Meta Events Manager for any errors or warnings.
*   **Data Comparison:** Compare CAPI data with Pixel data to ensure consistency.
