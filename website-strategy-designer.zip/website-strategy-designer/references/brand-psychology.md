# Brand Psychology Reference

## Color Psychology

Colors create subconscious emotional responses before a visitor reads a single word.
Match the color to the emotional state you want the ICP to feel when they land on the site.

### Color Emotional Map

| Color Family       | Psychological Effect                              | Best For                                          |
|--------------------|--------------------------------------------------|---------------------------------------------------|
| Deep Navy          | Trust, authority, stability, premium              | B2B, enterprise, finance, legal, SaaS             |
| Sky Blue           | Openness, clarity, optimism, approachability      | Productivity tools, wellness, communication       |
| Emerald Green      | Growth, prosperity, forward motion, health        | Fintech, growth tools, sustainability, health     |
| Teal               | Calm innovation, sophistication, balance          | Health tech, modern B2B, SaaS                     |
| Purple             | Luxury, creativity, wisdom, transformation        | AI tools, coaching, premium tech, beauty          |
| Deep Purple        | Sophistication, exclusivity, intelligence         | Premium SaaS, AI platforms, luxury tech           |
| Orange             | Enthusiasm, warmth, energy, accessibility         | Consumer apps, education, affordable services     |
| Coral              | Approachability, modern warmth, vitality          | Lifestyle, wellness, consumer, creative           |
| Red                | Urgency, passion, action, intensity               | CTAs, sales urgency, food, entertainment          |
| Gold / Amber       | Achievement, confidence, premium, success         | Consulting, coaching, luxury, awards              |
| Charcoal / Black   | Power, luxury, authority, sophistication          | Luxury, fashion, premium, enterprise              |
| White              | Clarity, simplicity, cleanliness, purity          | Healthcare, tech, minimalist brands               |
| Warm Gray          | Professionalism, neutrality, balance              | B2B, corporate, supporting neutrals               |

### CTA Button Color Psychology

The CTA must create contrast AND a psychological push to act:

- **Orange** — High-action, low-commitment feel. Works for free trials and signups
- **Green** — "Go" signal, positive, safe choice. Works for confirmations and next steps
- **Bright Blue** — Clear, trustworthy, decisive. Strong for B2B and SaaS
- **Red** — Urgency. Use sparingly — can feel aggressive or alarming
- **Contrasting brand accent** — Most effective when it pops against the page background

### Color Palette Recipes (2026)

| Palette Style      | Colors                                    | Psychological Story                         |
|--------------------|-------------------------------------------|---------------------------------------------|
| Premium Dark       | Deep navy + gold + white                  | Authority + achievement + clarity           |
| Modern SaaS        | Midnight blue + electric violet + white   | Innovation + trust + forward thinking       |
| Warm Growth        | Forest green + amber + cream              | Prosperity + warmth + reliability           |
| Bold Tech          | Near-black + electric teal + white        | Power + innovation + clarity                |
| Human B2B          | Slate blue + coral + light gray           | Professional + approachable + warm          |
| Luxury Services    | Charcoal + gold + ivory                   | Exclusivity + premium + timeless            |
| Clean Health       | White + teal + soft green                 | Purity + healing + growth                   |
| Creative Studio    | Deep purple + vibrant coral + off-white   | Creative + energetic + sophisticated        |

---

## Font Psychology

Typography communicates personality before anyone reads the words.
The shape of letters carries emotional weight at a subconscious level.

### Typeface Category Emotions

**Serif Fonts** (decorative lines at letter ends — Georgia, Playfair Display, Lora, Merriweather)
- Feel: Traditional, trustworthy, authoritative, established, editorial
- Message: "We have history. You can trust us."
- Use for: Law, finance, publishing, consulting, premium services

**Humanist Sans-Serif** (clean, human proportions — Inter, DM Sans, Plus Jakarta Sans, Nunito)
- Feel: Modern, approachable, friendly, clean, human
- Message: "We are easy to work with. No complexity."
- Use for: SaaS, consumer apps, startups, modern services

**Geometric Sans-Serif** (built on precise shapes — Poppins, Raleway, Jost, Outfit)
- Feel: Technical precision, innovation, mathematical, forward-thinking
- Message: "We think in systems. We are the future."
- Use for: AI tools, engineering, tech platforms, modern B2B

**Display/Editorial Fonts** (expressive, distinctive — Clash Display, Cabinet Grotesk)
- Feel: Bold, creative, memorable, strong personality
- Message: "We have a point of view. We are different."
- Use for: Headlines only — creative agencies, bold consumer brands

**Monospace** (equal-width characters — code aesthetic)
- Feel: Technical, developer-focused, precise, raw
- Use for: Developer tools, APIs, technical products — accent only

### Pairing Psychology

The heading font sets the personality. The body font builds trust through readability.

| Pairing                              | Psychological Effect            | Good For                           |
|--------------------------------------|---------------------------------|------------------------------------|
| Serif heading + Sans body            | Authority + accessibility       | Consulting, finance, premium       |
| Geometric sans heading + Humanist body | Innovation + warmth           | SaaS, modern B2B, tech platforms   |
| Display heading + Clean sans body    | Bold personality + clarity      | Creative agencies, bold brands     |
| Transitional serif + Neutral sans    | Classic meets modern            | Healthcare, legal, established brands |

### Font Weight Emotions

- Light/Thin — Elegant, premium, delicate (use for display only)
- Regular — Neutral, readable, professional
- Medium/SemiBold — Confident, clear, action-oriented
- Bold — Assertive, important, draws attention
- Black/Heavy — Powerful, commanding (hero headlines only)

---

## 2026 Design Trends

Choose trends that amplify the brand naturally — do not force trends for their own sake.

### Trend 1: Calm Technology Aesthetics
The backlash against cluttered, overwhelming interfaces.
- Generous white/neutral space — every element earns its place
- Reduced visual noise with one vivid accent color
- Typography doing the heavy lifting instead of decoration
- Soft, desaturated palettes with precise use of color
- **Best for**: SaaS, B2B, productivity tools, mental health, premium services

### Trend 2: Authentic Imperfection
Rejection of the overly polished, generic stock-photo look.
- Real photography of real people — not models
- Organic textures, grain overlays, subtle noise
- Hand-drawn elements mixed with digital polish
- Candid, editorial-style imagery
- Slightly imperfect illustrations that feel human
- **Best for**: Consumer brands, creative agencies, coaching, lifestyle, D2C

### Trend 3: Typographic Dominance
Type as the primary visual element — not imagery.
- Giant, expressive hero headlines
- Oversized numbers and statistics as visual anchors
- Type-only hero sections (no images)
- Variable fonts with dynamic weight
- **Best for**: Agencies, bold B2B, tools, modern services

### Trend 4: Dark Mode Premium
Rich, immersive dark-first interfaces.
- Deep backgrounds (near-black, deep navy, dark charcoal)
- Bright glowing accents (electric blue, violet, teal, lime)
- Glassmorphism — frosted glass panels with backdrop blur
- Subtle gradient glows and ambient light effects
- **Best for**: AI tools, dev tools, premium tech, fintech, gaming

### Trend 5: Bento Grid Layouts
Modular card-based information design.
- Asymmetric grid of feature cards at different sizes
- Each card tells one focused story
- Clean borders, subtle shadows, rounded corners
- Feels like a product showcase without being a screenshot dump
- **Best for**: SaaS feature pages, product showcases, portfolios

### Trend 6: Immersive Scroll Storytelling
Pages that reveal information progressively as you scroll.
- Scroll-triggered animations (elements slide, fade, scale in)
- Sticky sections with changing content panels
- Progress indicators
- **Best for**: High-consideration products, brand storytelling, premium services

### Trend 7: Bold Color Blocking
Contrast-first design that demands attention.
- Large blocks of saturated color separating content zones
- Unexpected color combinations — not safe pastels
- High contrast as a design system, not just a button tactic
- **Best for**: Consumer brands, creative industries, youth-targeted products

### Trend 8: AI-Native Aesthetic
Visual language that communicates intelligence and data.
- Neural network and constellation patterns as decorative elements
- Data visualization used as ambient design
- Gradient mesh backgrounds
- Floating 3D abstract elements
- **Best for**: AI tools, data platforms, research tools, advanced tech

### Trend 9: Microinteraction-Driven UI
Interfaces that feel alive and responsive.
- Hover states that reveal extra information
- Button ripples, icon morphs, subtle CTA pulses
- Cursor effects on hero sections
- Satisfying loading states
- **Best for**: SaaS products, apps, interactive tools

### Trend 10: Human-Scale Photography
Moving away from aspirational lifestyle photography.
- Close-up, intimate shots of hands, faces, real workspaces
- Natural lighting and authentic moments
- Diverse representation that feels genuinely real (not performatively diverse)
- Documentary/editorial style
- **Best for**: B2B services, coaching, healthcare, consumer products

---

## Decision Framework

When making brand decisions, work through these questions in order:

1. **What emotional state is the ICP in when they arrive?**
   Frustrated → calming colors. Ambitious → energizing colors. Anxious → trustworthy colors.

2. **What feeling should they have when they leave?**
   Confident → authority palette. Excited → warm/vibrant. Reassured → stable/trusted.

3. **What does the competitive landscape look like?**
   If all competitors use blue, consider teal or green to differentiate while staying trusted.

4. **What does the brand voice say?**
   Bold voice → bold typography. Warm voice → rounded humanist fonts. Premium → refined type with space.

5. **Which 2026 trend fits this brand and ICP naturally?**
   Do not force trends. Choose what amplifies the brand — not what looks current for its own sake.
