# CRO Framework Reference

## Core Principle

Every page has exactly one job: move a specific visitor one step closer to conversion.
A page that tries to do everything converts nothing.

Before analyzing any page, identify:
1. **Page Type** — What kind of page is this?
2. **Primary Conversion Goal** — The ONE thing the page must get visitors to do
3. **Traffic Context** — Where visitors come from (determines message match needs)

---

## CRO Analysis Dimensions (Priority Order)

### 1. Value Proposition Clarity (Highest Impact)

The visitor must understand "what is this, why should I care, is this for me" within 5 seconds.

Check for:
- Is the primary benefit clear, specific, and differentiated?
- Is it written in the customer's language (not company jargon)?
- Is it benefit-focused, not feature-focused?
- Does it address a real pain point the ICP actually has?

Common failures:
- "The best solution for your needs" (says nothing)
- "Streamline your workflow" (meaningless)
- "We help businesses grow" (every competitor says this)
- Trying to say five things at once

Strong value proposition patterns:
- Outcome-focused: "Get [desired result] without [specific pain]"
- Specificity: Include numbers, timeframes, concrete details
- Social proof embedded: "Join 10,000+ teams who..."
- Direct pain address: "Tired of [specific problem]? Here's what works."

---

### 2. Headline Effectiveness

Evaluate:
- Does it communicate the core value prop?
- Is it specific enough to be meaningful?
- Does it match the source messaging? (Ad → page = exact message match required)
- Does it speak to the ICP directly, not to everyone?

Strong patterns:
- "[Outcome] for [specific audience]"
- "The [adjective] way to [do thing]"
- "[Specific number/result] in [specific timeframe]"
- "[Pain point]? [Solution in one line]."

---

### 3. CTA Placement, Copy, and Hierarchy

Primary CTA assessment:
- Is there ONE clear primary action?
- Is it visible above the fold without scrolling?
- Does button copy communicate value, not just mechanics?
  - Weak: "Submit", "Sign Up", "Learn More", "Click Here"
  - Strong: "Start Free Trial", "Get My Free Report", "Book a 15-Min Demo", "See Pricing"
- Is there sufficient contrast to make it visually dominant?

CTA hierarchy rules:
- Primary CTA: 1 per page, visually dominant
- Secondary CTA: Lower commitment, visually subordinate
- CTAs repeat at: after hero, after key benefits, after social proof, at page bottom

---

### 4. Visual Hierarchy and Scannability

Most visitors scan before they read. Design for the scanner first.

Check:
- Can someone understand the main message from just the headlines and bullets?
- Is information organized H1 → H2 → body (not walls of equal-weight text)?
- Is there breathing room (whitespace) between elements?
- Do images support the message or just fill space?

Common failures:
- Walls of text with no visual breaks
- Too many elements competing for attention equally
- Important information buried below the fold
- Generic stock photos that communicate nothing specific

---

### 5. Trust Signals and Social Proof

Visitors are skeptical by default. Every claim needs validation placed near it.

Types (in rough priority order):
- Customer logos (especially recognizable brands)
- Testimonials with: full name, photo, job title, company, specific outcome
- Case study snippets with real numbers ("43% increase in revenue in 3 months")
- Review scores and counts from G2, Capterra, Google, etc.
- Security badges (SOC2, GDPR, SSL — near forms)
- "As featured in" media mentions
- Customer count ("10,000+ companies trust us")
- Team/founder credibility (credentials, years of experience)

Placement rules:
- Near every CTA (reduces fear at decision moment)
- After every bold claim (validates the claim)
- Near pricing (where fear is highest)

---

### 6. Objection Handling

Identify the ICP's objections for this page and make sure the page pre-empts them.

Common objection categories:
- Price/value: "Is this worth it? Too expensive for what I get?"
- Fit: "Will this work for my specific situation?"
- Complexity: "How hard is this to implement or use?"
- Time to value: "How long before I see results?"
- Switching cost: "What about my current setup and team?"
- Trust: "Are these people legitimate? Will they actually deliver?"
- Risk: "What if it does not work? Am I locked in?"

Address through:
- FAQ sections (answer real objections, not softball questions)
- Guarantee or refund policy near CTAs
- "How it works" section — removes complexity fear
- Case studies showing time-to-value
- Integration info — reduces switching cost anxiety

---

### 7. Friction Reduction

Friction = anything that makes the visitor hesitate, stop, or leave.

Common friction sources:
- Too many form fields (only ask what you need right now)
- Unclear next steps ("What happens after I submit this?")
- Navigation pulling focus away from the conversion goal
- Requiring phone number when it is not needed
- Slow page load (each second costs conversions)
- Poor mobile experience
- Confusing pricing or unclear commitment

---

## Page-Specific Frameworks

### Homepage

Homepages serve multiple audiences (cold visitors, warm leads, existing customers).

Key concerns:
- Clear positioning statement for cold visitors within 5 seconds
- Fast path to the primary conversion action
- Help different visitor types self-select ("For agencies", "For teams")
- Handle both "ready to act now" and "still researching" visitors

Recommended section order:
1. Hero: Problem/solution + primary CTA
2. Social proof block: Logos or stat to build immediate credibility
3. Problem statement: Make the ICP feel understood
4. Solution: How you solve it — benefit-focused, not feature list
5. How it works: Simple 3-step process
6. Benefits deep-dive: Key outcomes with supporting evidence
7. Testimonials: Specific, attributed, with photos and outcomes
8. Final CTA: Repeat primary CTA with urgency or guarantee

---

### Landing Page

Single-purpose pages. Visitors came from an ad or email — they have specific intent.

Key concerns:
- Message match: mirror the ad/email language exactly
- Remove navigation — nothing should compete with the CTA
- Complete the argument on one page
- Genuine urgency/scarcity only (never fake it)

---

### Pricing Page

High-intent visitors seriously considering. This is a Decision-stage page.

Key concerns:
- Clear plan comparison
- Visual "Recommended" indicator on the target plan
- Feature clarity: exactly what is included and excluded per plan
- Address "which plan is right for me?" anxiety proactively
- Frictionless path from pricing to checkout
- Testimonials placed near price points
- FAQ addressing common pricing objections
- Money-back guarantee or free trial option visible

---

### Feature/Product Page

Visitors researching whether the product does what they need.

Key concerns:
- Connect every feature to a specific benefit for the ICP
- Show real use cases ("Here is how [persona type] uses this")
- Compare to alternatives clearly
- End with CTA to try or see the feature in action

---

### About Page

Visitors come here when they want to trust you.

Key concerns:
- Mission that resonates with the ICP's values
- Founder/team story that builds credibility and human connection
- Why this company — not just "we saw a gap in the market"
- Timeline or milestones that show stability and momentum
- CTA at the bottom — most visitors are warm by the time they finish reading

---

### Blog Post

Organic traffic that needs a bridge from content to product.

Key concerns:
- Contextual CTAs that match the article topic exactly
- Lead magnets directly related to what the article covers
- Inline CTAs at natural reading pauses (not just top and bottom)
- "Next steps" section at end with clear link toward the product

---

## Conversion Principles Cheat Sheet

| Principle               | Application                                                    |
|-------------------------|----------------------------------------------------------------|
| One goal per page       | Remove anything that does not serve the primary CTA            |
| Message match           | Copy must match where the visitor came from                    |
| Benefit over feature    | What it does FOR them, not what it IS                          |
| Specific over vague     | Numbers, names, outcomes over generalities                     |
| Proof near claims       | Every bold claim gets validation nearby                        |
| Reduce cognitive load   | Fewer choices, cleaner layout, shorter forms                   |
| Address fear before CTA | Handle the biggest objection right before asking for action    |
| Momentum                | Every page must make the next step obvious and desirable       |
