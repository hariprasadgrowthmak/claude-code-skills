# Apify Actors Reference — Competitive Intelligence

## API Key
Store as: `APIFY_API_KEY`
Base URL: `https://api.apify.com/v2`

## Core Function: Run an Actor

```python
import requests
import time

APIFY_API_KEY = "apify_api_xDsMnNwTuw2ZrGonwAvR0nen72CaYZ1KOHNP"

def run_apify_actor(actor_id, input_data, timeout_secs=300):
    """Run an Apify actor and return results."""
    
    # Start the actor
    response = requests.post(
        f"https://api.apify.com/v2/acts/{actor_id}/runs",
        headers={
            "Authorization": f"Bearer {APIFY_API_KEY}",
            "Content-Type": "application/json"
        },
        json=input_data,
        params={"timeout": timeout_secs}
    )
    run_id = response.json()["data"]["id"]
    
    # Wait for completion
    while True:
        status_response = requests.get(
            f"https://api.apify.com/v2/actor-runs/{run_id}",
            headers={"Authorization": f"Bearer {APIFY_API_KEY}"}
        )
        status = status_response.json()["data"]["status"]
        
        if status == "SUCCEEDED":
            dataset_id = status_response.json()["data"]["defaultDatasetId"]
            break
        elif status in ["FAILED", "ABORTED", "TIMED-OUT"]:
            raise Exception(f"Actor run failed with status: {status}")
        
        time.sleep(5)
    
    # Fetch results
    results = requests.get(
        f"https://api.apify.com/v2/datasets/{dataset_id}/items",
        headers={"Authorization": f"Bearer {APIFY_API_KEY}"},
        params={"format": "json", "limit": 1000}
    )
    return results.json()
```

---

## Actor: Meta Ad Library Scraper

**Actor ID**: `apify/facebook-ads-scraper`
**Use**: Competitor ad intelligence on Meta/Instagram

```python
meta_ads_input = {
    "startUrls": [
        f"https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=US&q={competitor_name}"
    ],
    "maxItems": 50,
    "scrapeAdDetails": True,  # Gets EU transparency data, reach, etc.
    "proxy": {
        "useApifyProxy": True,
        "apifyProxyGroups": ["RESIDENTIAL"]
    }
}

results = run_apify_actor("apify/facebook-ads-scraper", meta_ads_input)
```

**Returns per ad**:
- `adText`: Body copy
- `adTitle`: Headline
- `imageUrls`: Creative images
- `videoUrls`: Creative videos
- `ctaText`: Call-to-action button text
- `ctaLink`: Destination URL
- `startDate` / `endDate`: Dates running
- `impressionsMin` / `impressionsMax`: Reach estimate
- `pageId` / `pageName`: Advertiser
- `platforms`: Where running (FB, IG, etc.)

---

## Actor: Google Ads Transparency Scraper

**Actor ID**: `lexis-solutions/google-ads-scraper`
**Use**: Competitor search + display ad intelligence

```python
google_ads_input = {
    "url": f"https://adstransparency.google.com/?region=anywhere&domain={competitor_domain}",
    "maxItems": 30,
    "downloadMedia": False  # Set True to download creative files
}

results = run_apify_actor("lexis-solutions/google-ads-scraper", google_ads_input)
```

**Returns per ad**:
- `adText`: Full ad copy
- `advertiser`: Company name
- `imageUrls`: Display ad creatives
- `videoUrls`: Video ad URLs
- `region`: Where ads ran
- `format`: TEXT, IMAGE, VIDEO
- `dateRange`: When it ran

---

## Actor: TikTok Ads Scraper (if available)

**Use**: TikTok creative intelligence

```python
# Search TikTok Creative Center (public)
tiktok_input = {
    "keyword": competitor_brand_name,
    "country": "US",
    "industry": "software",  # or relevant industry
    "maxItems": 20
}
# Actor: clockworks/tiktok-ads-scraper or similar
```

---

## Competitive Intelligence Analysis Pipeline

After scraping, run through this analysis:

```python
def analyze_competitor_ads(ads_data):
    """
    Send to Claude API for structured competitive analysis.
    Returns: hooks, angles, offers, creative_formats, gaps
    """
    import anthropic
    
    client = anthropic.Anthropic()
    
    # Prepare ad data summary
    ad_summaries = []
    for ad in ads_data[:30]:  # Analyze top 30
        ad_summaries.append({
            "copy": ad.get("adText", ""),
            "headline": ad.get("adTitle", ""),
            "cta": ad.get("ctaText", ""),
            "running_since": ad.get("startDate", ""),
            "estimated_impressions": ad.get("impressionsMax", 0)
        })
    
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        messages=[{
            "role": "user",
            "content": f"""Analyze these competitor ads and extract:
            
1. Top 5 hooks/opening lines they use most
2. Core offer angles (what benefit/outcome they lead with)
3. CTA patterns (soft vs hard, urgency tactics)
4. Creative format preferences (image, video, carousel)
5. Messaging gaps — what angles are they NOT covering (our opportunity)
6. Longest-running ads (likely highest performers)

Ads data:
{json.dumps(ad_summaries, indent=2)}

Return as structured JSON with keys: hooks, angles, cta_patterns, creative_formats, gaps, top_performers"""
        }]
    )
    
    return json.loads(response.content[0].text)
```

---

## MCP Integration Option

Apify actors can also be connected via MCP server for direct Claude tool use:

```
MCP Server URL: https://mcp.apify.com/sse
Actor trigger: Send API messages with actor_id + input
```

When available via MCP, prefer MCP over manual API calls for cleaner integration.

---

## Competitive Intel Report Template

After analysis, present as:

```
COMPETITOR INTELLIGENCE REPORT
==============================
Competitors analyzed: [List]
Ads scraped: [Total count]
Date: [Today]

TOP HOOKS THEY USE:
1. [Hook pattern + frequency]
2. ...

OFFER ANGLES:
1. [Angle description]
...

CREATIVE PREFERENCES:
- Image: X% | Video: Y% | Carousel: Z%
- Average ad length: X days running

LONGEST-RUNNING ADS (Proven winners):
1. [Ad copy excerpt] — Running X days
...

GAPS WE SHOULD EXPLOIT:
1. [Angle not covered] — Why this is opportunity
...

RECOMMENDED ANGLES TO TEST FIRST:
1. [Angle] — Based on: [reasoning]
2. ...
```

---

## Usage Notes

- Run competitive scrape at campaign start + monthly refresh
- Focus on advertisers with 100+ days running (they're profitable)
- Short-lived ads = didn't work, long-lived = working
- High impression counts = big budget behind it (they're confident)
- Apify free tier: $5/month credits. Scale plan for agency volume.
