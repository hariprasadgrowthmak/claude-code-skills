# Meta Ads Reference — 2025/2026

## API Version
Use **Marketing API v25.0+** (legacy ASC/AAC deprecated Q1 2026)

## Authentication
- System User Access Token (never expires, for production)
- Store in environment variable: `META_ACCESS_TOKEN`
- Ad Account ID format: `act_XXXXXXXXXX`

## Campaign Structure

```
Account
└── Campaign (objective + budget type)
    └── Ad Set (targeting + bid + schedule)
        └── Ad (creative + copy + URL)
```

## 2025 Key Rule: Unified Advantage+ API

No more `smart_promotion_type` flag. Campaigns automatically enter Advantage+ state based on three levers:
1. **Budget**: Campaign Budget Optimization (CBO) enabled
2. **Audience**: Advantage+ audience enabled
3. **Placement**: Advantage Placements enabled

Activate all three = full Advantage+ mode.

## Campaign Creation

```python
import requests

url = f"https://graph.facebook.com/v25.0/{ad_account_id}/campaigns"
params = {
    "access_token": META_ACCESS_TOKEN,
    "name": "META_Conv_Broad_FreeTrial_202601",
    "objective": "OUTCOME_SALES",  # or OUTCOME_LEADS, OUTCOME_AWARENESS, OUTCOME_TRAFFIC
    "status": "PAUSED",
    "special_ad_categories": [],
    "budget_rebalance_flag": True,  # for CBO
    "daily_budget": 5000,  # in cents
}
response = requests.post(url, params=params)
campaign_id = response.json()["id"]
```

**Objectives (2025)**:
- `OUTCOME_SALES` — purchases, conversions
- `OUTCOME_LEADS` — lead gen
- `OUTCOME_AWARENESS` — reach, brand awareness
- `OUTCOME_TRAFFIC` — link clicks, landing page views
- `OUTCOME_ENGAGEMENT` — post engagement
- `OUTCOME_APP_PROMOTION` — app installs

## Ad Set Creation

```python
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/adsets"
params = {
    "access_token": META_ACCESS_TOKEN,
    "campaign_id": campaign_id,
    "name": "AdSet_Broad_18-45_US",
    "optimization_goal": "OFFSITE_CONVERSIONS",
    "billing_event": "IMPRESSIONS",
    "bid_strategy": "LOWEST_COST_WITHOUT_CAP",  # or COST_CAP, MINIMUM_ROAS
    "targeting": {
        "age_min": 18,
        "age_max": 65,
        "geo_locations": {"countries": ["US"]},
        # 2025: Broad targeting preferred. Let algorithm optimize.
        # Add interests only for early testing with limited data.
    },
    "promoted_object": {
        "pixel_id": PIXEL_ID,
        "custom_event_type": "PURCHASE"
    },
    "status": "PAUSED",
    "start_time": "2026-01-20T00:00:00+0000",
}
```

**Bid Strategies**:
- `LOWEST_COST_WITHOUT_CAP` — maximize results (no spending control)
- `COST_CAP` — set max CPA, algorithm stays near it
- `MINIMUM_ROAS` — set min ROAS floor
- `LOWEST_COST_WITH_BID_CAP` — set max CPM/CPC bid

## Creative Upload

```python
# Upload image
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/adimages"
files = {"filename": open("creative.jpg", "rb")}
params = {"access_token": META_ACCESS_TOKEN}
response = requests.post(url, files=files, params=params)
image_hash = response.json()["images"]["creative.jpg"]["hash"]

# Create ad creative
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/adcreatives"
params = {
    "access_token": META_ACCESS_TOKEN,
    "name": "Creative_ProblemLed_A",
    "object_story_spec": {
        "page_id": PAGE_ID,
        "link_data": {
            "image_hash": image_hash,
            "link": "https://yoursite.com/landing-page",
            "message": "Primary text goes here (125 chars recommended)",
            "name": "Headline (40 chars max)",
            "description": "Description (30 chars)",
            "call_to_action": {"type": "LEARN_MORE"}  # or SHOP_NOW, SIGN_UP, GET_QUOTE
        }
    }
}
```

## Ad Creation

```python
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/ads"
params = {
    "access_token": META_ACCESS_TOKEN,
    "adset_id": adset_id,
    "name": "Ad_ProblemLed_A_Feed",
    "creative": {"creative_id": creative_id},
    "status": "PAUSED",
    "tracking_specs": [
        {"action.type": ["offsite_conversion"], "fb.pixel": [PIXEL_ID]}
    ]
}
```

## Performance Data Pull

```python
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/insights"
params = {
    "access_token": META_ACCESS_TOKEN,
    "level": "ad",  # or campaign, adset
    "fields": "campaign_name,adset_name,ad_name,spend,impressions,clicks,ctr,cpc,cpm,actions,cost_per_action_type,frequency,reach",
    "date_preset": "last_7d",  # or last_30d, last_14d
    "breakdowns": "age,gender",  # optional demographic breakdown
}
```

## 2025 Targeting Philosophy

**OLD WAY** (largely obsolete):
- Stack interests + demographics + behaviors
- Layer AND conditions for precision

**2025 WAY**:
- Start broad (18–65, no interests)
- Let CAPI + Pixel data guide the algorithm
- Use Advantage+ audience — Meta finds best people
- Add audience signals (customer list) but don't restrict
- Interests only useful for cold testing new angles with <50 conversions

## Audience Creation

```python
# Custom audience from website
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/customaudiences"
params = {
    "access_token": META_ACCESS_TOKEN,
    "name": "Website - All Visitors 30d",
    "rule": {"inclusions": {"operator": "or", "rules": [
        {"event_sources": [{"id": PIXEL_ID, "type": "pixel"}],
         "retention_seconds": 2592000,  # 30 days
         "filter": {"operator": "and", "filters": [
             {"field": "event", "operator": "eq", "value": "PageView"}
         ]}}
    ]}}
}

# Lookalike
url = f"https://graph.facebook.com/v25.0/{ad_account_id}/customaudiences"
params = {
    "access_token": META_ACCESS_TOKEN,
    "name": "LAL 1% - Purchasers",
    "subtype": "LOOKALIKE",
    "origin_audience_id": purchaser_custom_audience_id,
    "lookalike_spec": {"type": "similarity", "starting_ratio": 0.0, "ratio": 0.01, "country": "US"}
}
```

## Exclusions (Always Set)

```python
# In ad set targeting, add:
"exclusions": {
    "custom_audiences": [
        {"id": existing_customers_audience_id},
        {"id": recent_converters_7d_audience_id}
    ]
}
```

## CAPI Setup Verification

Before launching, verify CAPI events are firing:
```python
url = f"https://graph.facebook.com/v25.0/{PIXEL_ID}/events"
# Check event match quality score > 7.0
# Check deduplication is working (event_id matches browser pixel)
```

## Common Meta Errors

| Error | Cause | Fix |
|---|---|---|
| Error 100 | Invalid parameter | Check field names for API version |
| Error 200 | Permissions | Verify `ads_management` scope |
| Error 613 | Rate limit | Implement exponential backoff |
| Error 1487390 | Learning phase | Don't make changes for 7 days |
| Error 2446141 | Audience too small | Expand targeting or lookalike ratio |

## Naming Convention

```
META_{OBJECTIVE}_{AUDIENCE}_{OFFER}_{YYYYMM}
Examples:
META_Conv_Broad_FreeTrial_202601
META_LeadGen_LAL1pct_Demo_202601
META_Retarget_CartAband_Offer30_202601
```

## Scientific Creative Testing (3:2:2 Method)

**Objective:** Systematically test creative elements to find the most effective combinations before scaling.

1. **Identify Variables:** 3 distinct hooks, 2 main ad body texts, 2 calls-to-action (CTAs).
2. **Combine Creatives:** 3 hooks * 2 bodies * 2 CTAs = 12 unique ad variations.
3. **Small Budget Test:** Run a dedicated campaign with a small budget.
4. **Analyze & Isolate:** Identify top-performing elements based on CTR, CVR, CPC.
5. **Scale Winners:** Combine winning elements and scale in main Advantage+ campaigns.

## Script Extraction & Winning Ad Criteria

When scraping competitor ads via Apify or Browser:
1. Look for ads active for **6-7 months or longer**.
2. Focus on video ads.
3. Extract transcripts from 10+ winning videos.
4. Analyze for 15 common high-impact elements (hooks, USPs, social proof, urgency).
5. Feed these elements into LLM prompts to generate new scripts.
