# LinkedIn Ads Reference — 2025/2026

## When to Use LinkedIn
- B2B selling to specific job titles/companies
- Product LTV > $500 (justifies higher CPCs: $8–15+)
- Need to reach C-suite or decision-makers
- ABM (Account-Based Marketing) campaigns
- **DO NOT** use for B2C or low-ticket offers

## API Authentication
```
Base URL: https://api.linkedin.com/v2
Auth: OAuth 2.0 access token
Scopes: r_ads, w_ads, r_ads_reporting
```

## Campaign Structure
```
Ad Account
└── Campaign Group (budget container)
    └── Campaign (objective + targeting)
        └── Ad (sponsored content, message, doc, etc.)
```

## Minimum Requirements
- **Audience minimum**: 50,000 — below this, can't exit learning phase
- **Daily budget minimum**: $10 (recommend $100+ for meaningful data)
- **CPCs**: $8–15+ (factor into CAC calculations)

## Targeting That Works in 2025

**Job-Based (strongest signal)**:
```json
{
  "targetingCriteria": {
    "include": {
      "and": [
        {"or": {"urn:li:adTargetingFacet:titles": ["CMO", "VP Marketing", "Head of Marketing"]}},
        {"or": {"urn:li:adTargetingFacet:seniorities": ["VP", "CXO", "Director"]}},
        {"or": {"urn:li:adTargetingFacet:companySizes": ["201-500", "501-1000", "1001-5000"]}}
      ]
    }
  }
}
```

**Company-Based (ABM)**:
```json
{
  "or": {"urn:li:adTargetingFacet:employers": ["company_urn_1", "company_urn_2"]}
}
```

## Campaign Types
- **Sponsored Content**: Feed posts (single image, carousel, video)
- **Message Ads**: InMail direct to inbox (15% open rate average)
- **Lead Gen Forms**: In-platform capture (pre-fills from LinkedIn profile)
- **Document Ads**: Gated content (whitepaper, case study)
- **Conversation Ads**: Multi-step interactive message sequence

## Creative Rules
- Image: 1.91:1 ratio, max 5MB
- Video: 15s–30min, 360p–1080p
- Text: 150 chars for intro text; 70 chars headline
- Professional tone — no hype language
- Data and results resonate strongly

## Naming Convention
```
LI_{OBJECTIVE}_{AUDIENCE}_{OFFER}_{YYYYMM}
LI_LeadGen_CMOs-SaaS_Whitepaper_202601
LI_Conv_VPMktg_Demo_202601
```

---

# TikTok Ads Reference — 2025/2026

## When to Use TikTok
- Audience 18–35 years old
- Can create native, UGC-style video content
- B2C products with visual appeal
- Brand awareness + upper funnel
- Impulse purchase products (low-mid ticket)

## API Version
Use **Upgraded Smart+ API** (legacy deprecated March 31, 2026)
```
Base URL: https://business-api.tiktok.com/open_api/v1.3
Auth: Access token in header
```

## Campaign Structure
```
Ad Account
└── Campaign (objective + budget)
    └── Ad Group (targeting + placement + schedule)
        └── Ad (video creative + copy + CTA)
```

## Smart+ API (2025 Standard)

All new campaigns use Upgraded Smart+ which handles:
- Automatic targeting optimization
- Creative rotation
- Budget CBO
- Placement optimization

```python
import requests

def create_tiktok_campaign(advertiser_id, campaign_name, objective, budget):
    response = requests.post(
        "https://business-api.tiktok.com/open_api/v1.3/campaign/create/",
        headers={
            "Access-Token": TIKTOK_ACCESS_TOKEN,
            "Content-Type": "application/json"
        },
        json={
            "advertiser_id": advertiser_id,
            "campaign_name": campaign_name,
            "objective_type": objective,  # CONVERSIONS, REACH, TRAFFIC, APP_PROMOTION, LEAD_GENERATION
            "budget_mode": "BUDGET_MODE_DAY",
            "budget": budget,
            "operation_status": "DISABLE",  # Start paused
            "special_industries": [],
        }
    )
    return response.json()["data"]["campaign_id"]
```

## TikTok Creative Rules (CRITICAL)

**The TikTok creative principle**: Must feel native. Polished production = lower performance.

1. **Vertical 9:16 always** — no exceptions
2. **Hook in first 1-2 seconds** — TikTok users scroll faster than any platform
3. **Captions always** — auto-gen or manual
4. **UGC style beats brand style** — lo-fi wins
5. **Music matters** — use trending audio when possible
6. **Text overlays native to TikTok style** — not designed graphics
7. **No talking head in front of blank wall** — show action

## Symphony Automation (TikTok Native AI Creative)
TikTok's built-in AI can generate TikTok-native video from:
- Product URL
- Existing creative assets
- Text brief

Available via Smart+ campaign creative settings. Use alongside Kling for volume.

## Spark Ads
Boost existing organic TikTok posts as ads:
- Requires post authorization code from creator
- Often outperforms purpose-built ads
- Maintains social proof (likes, comments, shares)

## Performance Benchmarks (TikTok 2025)
- Good CTR: 1.5–3%
- Good CVR: 1.5–3% (landing page)
- CPA: Highly variable by vertical
- CPM: $8–15 for broad audiences

## Naming Convention
```
TT_{OBJECTIVE}_{AUDIENCE}_{CONCEPT}_{YYYYMM}
TT_Conv_18-35_UGCstyle_202601
TT_Awareness_Broad_ProductDemo_202601
```

---

# X/Twitter Ads Reference — 2025/2026

## When to Use X/Twitter
- Tech/SaaS audiences (still strong on X)
- Thought leadership amplification
- Real-time/news-adjacent campaigns
- Lower CPMs than Meta (but lower intent)
- B2B with tech-savvy audience

## Campaign Types
- **Promoted Posts**: Amplify organic tweets as ads
- **Follower campaigns**: Grow account followers
- **Website clicks**: Drive traffic
- **App installs**: Mobile acquisition
- **Video views**: Awareness

## Key Characteristics
- **Audience targeting**: Follower lookalikes, keyword targeting, interest
- **Format**: Keep it conversational, native to X voice
- **CPMs**: $3–8 (lower than Meta, but lower quality intent)
- **CTR benchmark**: 0.3–0.8%

## Creative Rules
- Lead with a strong opinion or hook
- Include an image or video (lifts CTR significantly)
- Thread-style copy (continue story in replies) can work well
- Avoid overly branded language — sounds like ads

## API
```
Base URL: https://ads-api.twitter.com/12
Auth: OAuth 1.0a
```

## Naming Convention
```
X_{OBJECTIVE}_{AUDIENCE}_{CONCEPT}_{YYYYMM}
X_Traffic_TechFounders_ThoughtLead_202601
```
