# AI Creative Generation Reference — 2025/2026

## Philosophy: Creative IS the Targeting

In 2025, platform algorithms find the audience. Your job is to give them creative that
self-selects the right people. Strong creative = lower CAC. This is the moat.

**Creative hierarchy for testing:**
1. Angle/concept (biggest impact — 60%)
2. Hook/opening line (30%)
3. Visual style (7%)
4. CTA (3%)

Always test concept before optimizing copy.

---

## Static Image Generation: FLUX

**Best for**: Ad statics, product shots, lifestyle imagery, text-overlay ads

**API**: Black Forest Labs (FLUX Pro 1.1)
```
Endpoint: https://api.bfl.ai/v1/flux-pro-1.1
Method: POST
Headers: 
  X-Key: {FLUX_API_KEY}
  Content-Type: application/json
```

```python
import requests

def generate_ad_static(prompt, width=1080, height=1080):
    response = requests.post(
        "https://api.bfl.ai/v1/flux-pro-1.1",
        headers={"X-Key": FLUX_API_KEY, "Content-Type": "application/json"},
        json={
            "prompt": prompt,
            "width": width,
            "height": height,
            "steps": 28,
            "guidance": 3.5,
            "output_format": "jpeg",
            "output_quality": 95,
        }
    )
    result = response.json()
    # Poll for result
    import time
    while True:
        poll = requests.get(result["id"], headers={"X-Key": FLUX_API_KEY})
        if poll.json().get("status") == "Ready":
            return poll.json()["result"]["sample"]
        time.sleep(2)

# Sizes to generate per concept:
SIZES = {
    "feed_square": (1080, 1080),
    "stories_vertical": (1080, 1920),
    "link_ad_landscape": (1200, 628),
}
```

### Prompt Framework for Ad Statics

```
[STYLE] + [SUBJECT] + [CONTEXT] + [MOOD] + [AD NOTES]

Example:
"Clean product photography style. A professional holding a tablet showing a dashboard 
with charts and graphs, modern office background, confident and calm expression, 
natural lighting, shallow depth of field. No text overlay. The product UI on the 
screen should show colorful graphs. Photo-realistic, high quality, editorial style."

Notes:
- Always specify "no text overlay" — add text in post via design tool
- Keep text under 20% of image for Meta compliance
- Specify aspect ratio mood: vertical = personal/intimate, square = editorial
- Use reference to competitor ad style if available from intel phase
```

### Ad Static Checklist

For each creative concept, generate:
- [ ] 3 angle variations (problem, outcome, proof)
- [ ] 3 sizes per angle (1:1, 9:16, 1.91:1)
- [ ] Clean version (no text) for flexible overlay
- [ ] Save with naming: `{Platform}_{Concept}_{Angle}_{Size}_{Date}`

---

## Video Generation: Kling AI (Primary)

**Best for**: Cinematic, photorealistic, action-based, product demos, lifestyle

**Why Kling**: 2-minute max, 1080p, excellent physics simulation, bulk generation, cost-effective

**API**:
```
Base URL: https://api.klingai.com/v1
Auth: Bearer token in header
```

```python
import requests
import time

def generate_video_kling(prompt, duration=15, aspect_ratio="9:16"):
    # Create task
    response = requests.post(
        "https://api.klingai.com/v1/videos/text2video",
        headers={
            "Authorization": f"Bearer {KLING_API_KEY}",
            "Content-Type": "application/json"
        },
        json={
            "model_name": "kling-v2",
            "prompt": prompt,
            "negative_prompt": "blurry, low quality, text overlay, watermark, ugly",
            "cfg_scale": 0.5,
            "mode": "pro",  # standard or pro (pro = higher quality)
            "duration": duration,  # 5 or 10 seconds for text2video; up to 120 for image2video
            "aspect_ratio": aspect_ratio,  # 16:9, 9:16, 1:1
        }
    )
    task_id = response.json()["data"]["task_id"]
    
    # Poll for completion
    while True:
        status = requests.get(
            f"https://api.klingai.com/v1/videos/text2video/{task_id}",
            headers={"Authorization": f"Bearer {KLING_API_KEY}"}
        ).json()
        
        if status["data"]["task_status"] == "succeed":
            return status["data"]["task_result"]["videos"][0]["url"]
        elif status["data"]["task_status"] == "failed":
            raise Exception(f"Video generation failed: {status}")
        time.sleep(5)
```

### Video Prompt Framework

```
[OPENING SCENE] + [ACTION/MOVEMENT] + [PRODUCT CONTEXT] + [MOOD/STYLE] + [TECHNICAL]

For 15-second ad:
"[0-3s hook] Person sitting at desk surrounded by sticky notes and multiple spreadsheets, 
frustrated expression, messy workspace. [3-8s problem] They're clearly overwhelmed, 
rubbing their temples. [8-20s solution] They open their laptop and a clean dashboard 
appears - their face lights up. [20-30s CTA implied] They're now smiling, taking notes 
confidently. Cinematic lighting, professional office setting, realistic style, 
no text or logos."

Technical specs:
- Duration: 15s (for Meta/TikTok feed) or 30s (for YouTube/longer placements)
- 9:16 for Stories, Reels, TikTok
- 16:9 for YouTube, LinkedIn
- 1:1 for Facebook/Instagram feed
```

### Video Structure Templates

**Problem-Solution (15s)**
```
0-3s:  Visual hook — relatable frustration
3-8s:  Problem escalation
8-13s: Product as solution appears
13-15s: Happy outcome moment
```

**Testimonial-Style (30s)**
```
0-5s:  Person speaks directly to camera (bold statement)
5-15s: Visual evidence / screen recording / before-after
15-25s: Key benefit with numbers
25-30s: CTA with visual
```

**Product Demo (30s)**
```
0-5s:  Hook question ("Tired of X?")
5-10s: Problem shown
10-20s: Product UI/action walkthrough
20-25s: Result/metric shown
25-30s: CTA
```

---

## Video Generation: Runway Gen-4 (Alternative)

**Best for**: Brand consistency, multi-shot campaigns, premium polished content

```python
def generate_video_runway(prompt, duration=10):
    response = requests.post(
        "https://api.runwayml.com/v1/image_to_video",
        headers={
            "Authorization": f"Bearer {RUNWAY_API_KEY}",
            "X-Runway-Version": "2024-11-06",
            "Content-Type": "application/json"
        },
        json={
            "model": "gen4_turbo",
            "promptImage": seed_image_url,  # Start from FLUX-generated static
            "promptText": prompt,
            "duration": duration,  # 5 or 10
            "ratio": "768:1344",  # 9:16 vertical
            "watermark": False
        }
    )
    task_id = response.json()["id"]
    
    # Poll
    while True:
        status = requests.get(
            f"https://api.runwayml.com/v1/tasks/{task_id}",
            headers={"Authorization": f"Bearer {RUNWAY_API_KEY}"}
        ).json()
        if status["status"] == "SUCCEEDED":
            return status["output"][0]
        time.sleep(3)
```

**Runway advantage**: Start with FLUX static → animate it with Runway.
This ensures brand consistency and controlled visual output.

---

## Creative Testing Framework

### Naming Convention for Creatives
```
{Platform}_{Concept}_{Angle}_{Format}_{Size}_{YYYYMM}
META_FreeTrial_ProblemLed_Video_9x16_202601
META_FreeTrial_OutcomeLed_Static_1x1_202601
GOOG_DemoRequest_SocialProof_Responsive_202601
```

### Testing Priority Order
1. **Concept** (problem vs outcome vs social proof vs contrarian)
2. **Hook** (question vs bold statement vs stat vs pattern interrupt)
3. **Visual style** (UGC vs polished vs product-only)
4. **CTA** (soft vs hard vs urgency)

**Rule**: One variable at a time. Need 100+ conversions per variant for statistical significance.
**Kill rule**: If CTR < 0.5% (Meta) or CPA > 200% of target after 3 days + 50 clicks → pause.

### Minimum Creative Set per Campaign Launch
- 3 static image variations (different concepts)
- 2 video variations (different hooks)
- All in required sizes for each placement

### Creative Fatigue Signals (trigger refresh)
- Frequency > 3.0 on Meta
- CTR declining >25% week-over-week
- CPA increasing >30% while spend is stable
- Reach plateau despite available budget

---

## Copy Frameworks

### Primary Text Formulas

**PAS (Problem-Agitate-Solve)**
```
[Problem]: "Spending 10 hours/week on manual reporting?"
[Agitate]: "While you're buried in spreadsheets, your competitors are acting on real-time data."
[Solve]: "[Product] automates your reports in 60 seconds."
[CTA]: "Start free →"
```

**BAB (Before-After-Bridge)**
```
[Before]: "Chasing approvals across email, Slack, and spreadsheets."
[After]: "Every approval tracked, automated, and on time."
[Bridge]: "[Product] connects your tools so nothing falls through the cracks."
```

**Social Proof Lead**
```
"[Client] cut reporting time by 75%."
"[Product] is how marketing teams stop guessing and start knowing."
"[CTA]"
```

### Hook Library (steal liberally)
- "The [common tool] replacement your team will actually use"
- "How we [impressive result] in [short time]"
- "Why we stopped [common behavior]"
- "The [industry] secret no one talks about"
- "If you're still doing [X], this will change everything"
- "[Number] [job titles] switched from [X] to us this month"

### CTA Guide by Funnel Stage
- **TOF**: Learn More, See How It Works, Watch Demo
- **MOF**: Get Free Trial, Book a Demo, See Pricing
- **BOF**: Start Free, Get Started Today, Claim Your Spot

---

## Platform-Specific Creative Rules

| Platform | Format | Max Text | Key Rule |
|---|---|---|---|
| Meta Feed | 1:1, 1.91:1 | <20% of image | High contrast, clear product |
| Meta Stories/Reels | 9:16 | Minimal | Native feel, no polish |
| Google PMAX | Multiple | Headline 30 chars | Fill ALL asset slots |
| TikTok | 9:16 vertical | Captions only | Must feel organic/UGC |
| LinkedIn | 1.91:1 | Professional | Show data/results |
| YouTube | 16:9 | Skip-proof first 5s | Hook before skip button |

---

## Creative Storage & Organization

Organize generated assets:
```
creatives/
├── {client_name}/
│   ├── {campaign}/
│   │   ├── statics/
│   │   │   ├── concept_a/
│   │   │   └── concept_b/
│   │   └── videos/
│   └── archive/
└── templates/
```

Log all generations with: prompt used, tool, date, size, performance (once live).
