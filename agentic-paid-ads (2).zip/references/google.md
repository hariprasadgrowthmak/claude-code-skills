# Google Ads Complete Reference — 2026

## Quick Navigation

This comprehensive reference covers:
1. [API Version & Setup](#api-version--setup)
2. [Account Structure & Hierarchy](#account-structure--hierarchy)
3. [Campaign Types & Specifications](#campaign-types--specifications)
4. [Character Limits for All Ad Elements](#character-limits-for-all-ad-elements)
5. [Ad Extensions (Complete List)](#ad-extensions-complete-list)
6. [Keyword Management](#keyword-management)
7. [Bidding Strategies](#bidding-strategies)
8. [Targeting Options](#targeting-options)
9. [Conversion Tracking](#conversion-tracking)
10. [Quality Score & Optimization](#quality-score--optimization)
11. [Account Limits](#account-limits)
12. [Display & Video Ads Specifications](#display--video-ads-specifications)
13. [Budget Management](#budget-management)
14. [Performance Metrics & KPIs](#performance-metrics--kpis)

---

## API Version & Setup

**Google Ads API v18+** (use latest stable)  
Authentication via OAuth2 + developer token

```python
from google.ads.googleads.client import GoogleAdsClient

client = GoogleAdsClient.load_from_dict({
    "developer_token": GOOGLE_ADS_DEVELOPER_TOKEN,
    "client_id": GOOGLE_CLIENT_ID,
    "client_secret": GOOGLE_CLIENT_SECRET,
    "refresh_token": GOOGLE_REFRESH_TOKEN,
    "login_customer_id": MANAGER_ACCOUNT_ID,  # MCC
})
customer_id = CLIENT_CUSTOMER_ID
```

---

## Account Structure & Hierarchy

Google Ads operates on a three-layer hierarchical structure:

```
ACCOUNT (Top Level)
├── Email Address & Password
├── Billing Information
├── Account-Level Settings
│
├── CAMPAIGN (Middle Level)
│   ├── Budget & Settings
│   ├── Bidding Strategy
│   ├── Targeting (Location, Device, Audience)
│   ├── Campaign-Level Assets
│   │
│   └── AD GROUP (Bottom Level)
│       ├── Keywords
│       ├── Ads (Headlines, Descriptions)
│       ├── Ad Group-Level Assets
│       └── Ad Group Targeting
```

**Best Practice**: 5-20 campaigns per account, 7-10 ad groups per campaign, 15-20 keywords per ad group

---

## Campaign Types & Specifications

| Type | Use Case | API Channel Type | Best For |
|---|---|---|---|
| Search | High-intent keyword capture | SEARCH | Lead generation, direct response |
| Performance Max | AI cross-channel (all inventory) | PERFORMANCE_MAX | Scaling with conversion data |
| Demand Gen | YouTube + Gmail + Discover (visual) | DEMAND_GEN | Brand awareness, consideration |
| Display | Banner retargeting | DISPLAY | Remarketing, brand awareness |
| Shopping | Ecom product listings | SHOPPING | E-commerce product sales |
| Video | YouTube brand/awareness | VIDEO | Brand awareness, storytelling |

---

## Character Limits for All Ad Elements

### Responsive Search Ads (RSAs) - RECOMMENDED FORMAT

**Headlines**:
- **Quantity**: 3-15 headlines (minimum 3, maximum 15)
- **Character Limit**: 30 characters max per headline
- **Best Practice**: Provide 10-15 headlines for Google to test
- **Recommendation**: At least one headline should be ≤15 characters

**Descriptions**:
- **Quantity**: 2-5 descriptions (minimum 2, maximum 5)
- **Character Limit**: 90 characters max per description
- **Best Practice**: Provide 4-5 descriptions for optimal testing

**Long Headlines** (Optional):
- **Quantity**: 1-5 long headlines
- **Character Limit**: 90 characters max

**Business Name**:
- **Character Limit**: 25 characters max
- **Requirement**: Must match domain name or verified business name

**Display URL Path** (Optional):
- **Quantity**: 1-2 paths
- **Character Limit**: 15 characters max per path
- **Example**: /services or /book-now

**Final URL**:
- **Character Limit**: 2,048 characters max
- **Requirement**: Must be valid, working URL

### RSA Creation Code

```python
ad_group_ad_service = client.get_service("AdGroupAdService")
operation = client.get_type("AdGroupAdOperation")
ad_group_ad = operation.create

ad_group_ad.ad_group = ad_group_resource_name
ad_group_ad.status = client.enums.AdGroupAdStatusEnum.PAUSED

rsa = ad_group_ad.ad.responsive_search_ad

def add_headline(text, pinned_field=None):
    headline = client.get_type("AdTextAsset")
    headline.text = text
    if pinned_field:
        headline.pinned_field = pinned_field
    rsa.headlines.append(headline)

# 15 headlines (mix of keyword, benefit, action, question formats)
add_headline("Project Management Software")
add_headline("Save 10 Hours Every Week")
add_headline("Trusted by 500+ Teams")
add_headline("Try Free for 14 Days")
# ... up to 15

# 4 descriptions
desc = client.get_type("AdTextAsset")
desc.text = "Stop managing projects across 5 tools. One platform for tasks, timelines, and reporting."
rsa.descriptions.append(desc)
# ... up to 4

response = ad_group_ad_service.mutate_ad_group_ads(
    customer_id=customer_id,
    operations=[operation]
)
```

---

## Ad Extensions (Complete List)

### Sitelink Extensions

**Purpose**: Direct users to specific pages on your website

**Specifications**:
- **Text Length**: 25 characters max per sitelink
- **Description**: 35 characters max (optional, 2 lines)
- **Quantity**: Minimum 2, recommended 4-6, maximum 20
- **Level**: Account, campaign, or ad group

**Examples**:
- "Book Now" - Schedule your appointment
- "Services" - View all services
- "Locations" - Find a location near you

### Callout Extensions

**Purpose**: Highlight unique offers and business features

**Specifications**:
- **Text Length**: 25 characters max
- **Quantity**: Minimum 2, recommended 4-10, maximum 20
- **Level**: Account, campaign, or ad group

**Examples**:
- "Free Consultation"
- "5-Star Rated"
- "Same-Day Service"
- "Licensed Professionals"

### Structured Snippet Extensions

**Purpose**: Show specific categories of information

**Specifications**:
- **Header**: Pre-defined by Google (Services, Styles, Features, Brands, Amenities, etc.)
- **Values**: 25 characters max per value
- **Quantity**: 3-10 values per snippet

**Example**:
- Header: "Services"
- Values: "Lash Extensions | Lash Lift | Volume Lashes"

### Call Extensions

**Purpose**: Make phone numbers prominent and clickable

**Specifications**:
- **Phone Number**: Valid, clickable format
- **Quantity**: Multiple numbers per campaign
- **Display**: Shows as clickable button on mobile

### Location Extensions

**Purpose**: Show business address and distance

**Specifications**:
- **Address**: Business location(s)
- **Quantity**: Multiple locations per campaign
- **Display**: Shows address and distance on mobile

### Promotion Extensions

**Purpose**: Highlight special offers and promotions

**Specifications**:
- **Promotion Text**: 90 characters max
- **Discount Type**: Percentage, amount, or generic

### Price Extensions

**Purpose**: Show product/service pricing

**Specifications**:
- **Price**: Currency and amount
- **Description**: 25 characters max
- **Quantity**: 3-8 prices

### Lead Form Extensions

**Purpose**: Collect customer information directly from ad

**Specifications**:
- **Form Fields**: Customizable
- **Privacy Policy**: Required
- **Quantity**: One per campaign

### App Extensions

**Purpose**: Drive downloads to mobile apps

**Specifications**:
- **App Store**: iOS or Android
- **App URL**: Valid app store link
- **Quantity**: One per platform

### Message Extensions

**Purpose**: Enable SMS messaging from ads

**Specifications**:
- **Message Text**: 160 characters max
- **Phone Number**: Valid SMS-enabled number
- **Quantity**: One per campaign

### Dynamic Location Extensions

**Purpose**: Automatically show nearest business location

**Specifications**:
- **Locations**: From Google Business Profile
- **Radius**: Automatic based on relevance

---

## Keyword Management

### Keyword Match Types

**Exact Match [keyword]**
- Only exact searches or close variants
- Lowest reach, highest relevance
- Best for high-intent, specific terms

**Phrase Match "keyword"**
- Phrase must appear in search, can have words before/after
- Medium reach and relevance
- Balanced approach

**Broad Match keyword**
- Related searches, synonyms, variations
- Highest reach, lowest control
- Requires strong negative keywords

### Keyword Creation Code

```python
ad_group_criterion_service = client.get_service("AdGroupCriterionService")
operation = client.get_type("AdGroupCriterionOperation")
criterion = operation.create

criterion.ad_group = ad_group_resource_name
criterion.keyword.text = "project management software"
criterion.keyword.match_type = client.enums.KeywordMatchTypeEnum.EXACT  # or PHRASE, BROAD
criterion.status = client.enums.AdGroupCriterionStatusEnum.ENABLED

# 2026 approach: Fewer, more intent-rich keywords
# Exact match for proven converters
# Phrase for research intent
# Broad ONLY if you have smart bidding with 50+ conversions
```

### Negative Keywords

```python
# Shared negative keyword list
negative_list_service = client.get_service("SharedSetService")
# Create list → Link to campaigns → Add keywords
# Always include: [free, jobs, careers, DIY, tutorial, how to (if B2B)]
```

### Keyword Research via Keyword Planner

1. **Discover**: Enter product terms or competitor URLs into Keyword Planner
2. **Analyze**: Extract search volume, competition level, and top-of-page bid estimates
3. **Group**: Organize into intent-based ad groups
4. **Negatives**: Proactively build negative keyword lists

**Best Practice**: 15-20 keywords per ad group, mix short (1-2 words) and long-tail (3+ words)

---

## Bidding Strategies

### Manual CPC (Cost Per Click)

**How It Works**: You set maximum bid for each keyword

**Best For**: Testing, control, small budgets

**Pros**: Maximum control, transparent bidding

**Cons**: Time-consuming, requires constant monitoring

### Maximize Clicks

**How It Works**: Google automatically sets bids to get maximum clicks

**Best For**: Building traffic, new campaigns

**Pros**: Automated optimization, maximizes traffic

**Cons**: May waste budget on low-quality clicks

### Target CPA (Cost Per Acquisition)

**How It Works**: You set target cost per conversion, Google sets bids automatically

**Best For**: Lead generation, conversion-focused campaigns

**Requirements**: Minimum 30 conversions in last 30 days

**Pros**: Predictable cost per conversion, automated optimization

**Cons**: Requires conversion data, may limit volume

```python
campaign.maximize_conversions.target_cpa_micros = target_cpa * 1_000_000
# OR: campaign.target_cpa.target_cpa_micros = target_cpa * 1_000_000
```

### Target ROAS (Return on Ad Spend)

**How It Works**: You set target ROAS, Google sets bids to achieve it

**Best For**: E-commerce campaigns, scaling profitable campaigns

**Requirements**: Minimum 50 conversions in last 35 days, conversion value tracking required

**Pros**: Optimizes for profitability, scales winners

**Cons**: Requires conversion value data, complex setup

```python
campaign.target_roas.target_roas = 3.0  # 300% ROAS
```

### Maximize Conversion Value

**How It Works**: Google maximizes total conversion value within budget

**Best For**: E-commerce, high-value transactions

**Requirements**: Minimum 30 conversions in last 30 days, conversion value tracking required

### Maximize Conversions

**How It Works**: Google maximizes conversion volume within budget

**Best For**: Lead generation, conversion-focused campaigns

**Requirements**: Minimum 30 conversions in last 30 days

### Bidding Strategy Comparison

| Situation | Strategy | Notes |
|---|---|---|
| New account (<50 conv/mo) | Maximize Clicks → Manual CPC | Build data first |
| 50-100 conv/mo | Maximize Conversions | No target yet |
| 100+ conv/mo | Target CPA | Set 20% above actual CPA initially |
| Scaling PMAX | Target ROAS | Set 10% below actual ROAS |
| Brand protection | Manual CPC | Cheap, don't need automation |

---

## Targeting Options

### Location Targeting

**Country/Region Targeting**: Country, region, state, city

**Radius Targeting (Proximity Targeting)**:
- **Radius Options**: 1-50 miles or 1-50 kilometers
- **Center Point**: Specific address or coordinates
- **Best Practice**: 5-15 mile radius for service businesses

**Location Categories**: Target by location type (airports, shopping centers, etc.)

### Device Targeting

**Device Types**: Desktop, Mobile, Tablet, TV Screens

**Bid Adjustments**: -100% to +900%
- Example: +50% for mobile, -30% for tablet

### Audience Targeting

**In-Market Audiences**: Target users actively researching/buying

**Affinity Audiences**: Target users by lifestyle and interests

**Custom Affinity Audiences**: Create custom audience segments

**Custom Intent Audiences**: Target users by recent search behavior

**Similar Audiences**: Reach users similar to your customers

**Remarketing Audiences**: Target users who visited your website

---

## Conversion Tracking

### Conversion Types

**Website Conversions**:
- Page load
- Event (form submission, purchase, etc.)
- Click
- Time on site

**Call Conversions**:
- Phone calls
- Call extension clicks

**App Conversions**:
- App installs
- App events
- App engagement

**Offline Conversions**:
- Manual upload
- CRM integration

### Conversion Tracking Setup

```python
query = """
    SELECT
      conversion_action.name,
      conversion_action.status,
      conversion_action.type,
      conversion_action.counting_type,
      metrics.conversions,
      metrics.conversion_value
    FROM conversion_action
    WHERE conversion_action.status = 'ENABLED'
"""
# Verify conversion_action.type is WEBPAGE (not IMPORT) for proper tracking
```

### Conversion Value

**Purpose**: Track monetary value of conversions

**Setup**:
- Set static value (e.g., $50 per lead)
- Or dynamic value (e.g., purchase amount)
- Used for ROAS and value-focused bidding

### Conversion Windows

**Definition**: How long after ad click a conversion counts

**Options**: 1, 7, 14, 30, 60, 90 days (default: 30 days for clicks)

**Best Practice**: Match your sales cycle

### Enhanced Conversions Best Practices

**What**: Hashes first-party customer data (email, phone) and sends to Google for accurate matching

**Implementation**: Enable in Google Ads. Use GTM, gtag.js, or Google Ads API to send SHA256 hashed data

**Verification**: Use Google Tag Assistant and Ads Diagnostics to ensure data is received correctly

---

## Quality Score & Optimization

### Quality Score (1-10 Scale)

Quality Score is a diagnostic tool that measures keyword quality:

**Expected CTR**: Will your ad be clicked?
- Based on historical performance
- Improve by: Better copy, relevant keywords, improve position

**Ad Relevance**: Does ad match keyword intent?
- Based on keyword in copy, clarity
- Improve by: Include keyword in headline, match intent, write specific copy

**Landing Page Experience**: Is page relevant and useful?
- Based on speed, mobile-friendliness, content relevance, CTA clarity
- Improve by: Mobile-friendly, fast loading, relevant content, clear CTA

**Target**: 7-10 for competitive keywords

### Optimization Score (0-100%)

**Definition**: Estimate of how well your account is set to perform

**Components**:
- Account settings
- Campaign settings
- Keyword quality
- Ad quality
- Asset coverage
- Bidding strategy
- Conversion tracking

**Best Practice**: Target 80%+ optimization score, but prioritize business goals over score

---

## Account Limits

### Campaign & Ad Group Limits

| Item | Limit |
|------|-------|
| Campaigns per account | 10,000 |
| Ad groups per campaign | 20,000 |
| Active ads per ad group | 50 |
| Performance Max campaigns | 100 per account |
| Campaign drafts | 25 per account |

### Keyword & Targeting Limits

| Item | Limit |
|------|-------|
| Keywords per account | Unlimited |
| Negative keywords per campaign | 10,000 |
| Negative keywords per list | 5,000 |
| Location targets per campaign | 10,500 |
| Proximity targets per campaign | 500 |

### Asset Limits

| Item | Limit |
|------|-------|
| Sitelinks per account | 20 max |
| Callouts per campaign | 20 max |
| Ad group-level assets per account | 250,000 |
| Campaign-level assets per account | 50,000 |

---

## Display & Video Ads Specifications

### Display Ads - Image Specifications

**Responsive Display Ads (Recommended)**:
- **Landscape**: 1.91:1 (1200 x 628 px minimum 600 x 314 px)
- **Square**: 1:1 (1200 x 1200 px minimum 300 x 300 px)
- **Vertical**: 4:5 (1200 x 1500 px minimum 320 x 400 px)
- **Format**: JPG, PNG, GIF
- **File Size**: 5 MB max
- **Best Practice**: Submit 5-10 images per aspect ratio

**Standard Display Ads**:
- 300 x 250 (Medium Rectangle)
- 728 x 90 (Leaderboard)
- 160 x 600 (Wide Skyscraper)
- 300 x 600 (Half Page)
- 970 x 90 (Large Leaderboard)
- 250 x 250 (Square)

### Video Ads - Specifications

**In-Stream Ads (YouTube)**:
- **Skippable**: 12 seconds minimum (15-30 seconds recommended)
- **Non-Skippable**: 60 seconds maximum
- **Bumper**: 6 seconds (non-skippable)
- **Aspect Ratios**: 16:9 (1920 x 1080), 9:16 (1080 x 1920), 1:1 (1080 x 1080)
- **Format**: MP4, MOV, AVI, WMV, FLV, 3GP, 3G2, WebM, MKV, MPEGPS, WM, ASF, RM, RMVB, VOB, OGV
- **Codec**: H.264 video, AAC audio
- **Resolution**: Minimum 1280 x 720 (HD)

**Best Practice**: Hook viewers in first 3 seconds, include captions, clear CTA at end

---

## Budget Management

### Daily Budget

**Definition**: Average amount you're willing to spend per day

**How It Works**: Google may spend up to 2x daily budget on high-traffic days, averages out over month

**Minimum Daily Budget**:
- **Recommended**: $5-10 minimum
- **Practical**: $20+ for meaningful results
- **Optimal**: $50+ for testing and optimization

### Campaign Total Budget

**Definition**: Fixed budget for entire campaign duration

**How It Works**: Cannot exceed total budget, no daily overspending

**Best Practice**: Use for limited-time or seasonal campaigns

### Budget Creation Code

```python
campaign_budget_service = client.get_service("CampaignBudgetService")
budget_operation = client.get_type("CampaignBudgetOperation")
budget = budget_operation.create

budget.name = f"Budget_{campaign_name}"
budget.amount_micros = daily_budget_dollars * 1_000_000
budget.delivery_method = client.enums.BudgetDeliveryMethodEnum.STANDARD

response = campaign_budget_service.mutate_campaign_budgets(
    customer_id=customer_id,
    operations=[budget_operation]
)
budget_resource_name = response.results[0].resource_name
```

---

## Performance Metrics & KPIs

### Essential Metrics

**Impressions**: Number of times ad is shown (benchmark: 1,000+ per day for Search)

**Clicks**: Number of times ad is clicked (benchmark: 10-50+ per day depending on budget)

**Click-Through Rate (CTR)**: Clicks / Impressions (benchmark: 2-5% for Search, 0.5-2% for Display)

**Cost Per Click (CPC)**: Total cost / Clicks (varies by industry, keyword, competition)

**Conversions**: Number of tracked conversion actions (benchmark: 1-5% of clicks)

**Conversion Rate**: Conversions / Clicks (benchmark: 1-5% for Search, 0.5-2% for Display)

**Cost Per Conversion (CPA)**: Total cost / Conversions (varies by industry and business model)

**Return on Ad Spend (ROAS)**: Conversion value / Cost (benchmark: 3:1 to 5:1 depending on industry)

### Advanced Metrics

**Quality Score**: 1-10 diagnostic score (target: 7-10)

**Ad Rank**: Position in auction = Max CPC × Quality Score (target: Top 3 positions)

**Impression Share**: Impressions / Eligible impressions (target: 80%+ for important keywords)

**Search Lost Impression Share (Budget)**: Lost impressions due to budget (target: <5%)

**Search Lost Impression Share (Rank)**: Lost impressions due to low ad rank (target: <10%)

**Average Position**: Average ad position in search results (target: 1-3 for high-intent keywords)

### Weekly Performance Report Query

```sql
SELECT
  campaign.name,
  ad_group.name,
  ad_group_ad.ad.responsive_search_ad.headlines,
  metrics.impressions,
  metrics.clicks,
  metrics.ctr,
  metrics.average_cpc,
  metrics.conversions,
  metrics.cost_per_conversion,
  metrics.cost_micros,
  metrics.search_impression_share
FROM ad_group_ad
WHERE segments.date DURING LAST_7_DAYS
  AND campaign.status = 'ENABLED'
  AND ad_group.status = 'ENABLED'
ORDER BY metrics.cost_micros DESC
LIMIT 50
```

---

## Data Pull via GAQL

```python
ga_service = client.get_service("GoogleAdsService")

query = """
    SELECT
      campaign.id,
      campaign.name,
      campaign.status,
      campaign.bidding_strategy_type,
      metrics.cost_micros,
      metrics.clicks,
      metrics.impressions,
      metrics.ctr,
      metrics.average_cpc,
      metrics.conversions,
      metrics.cost_per_conversion,
      metrics.conversions_value,
      metrics.roas
    FROM campaign
    WHERE segments.date DURING LAST_30_DAYS
      AND campaign.status = 'ENABLED'
    ORDER BY metrics.cost_micros DESC
"""

response = ga_service.search(customer_id=customer_id, query=query)
for row in response:
    cost = row.metrics.cost_micros / 1_000_000  # convert from micros
    roas = row.metrics.roas
```

---

## Performance Max Campaign

Best for scaling with sufficient conversion data (50+ conversions/month).

```python
# Create PMAX campaign
campaign.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.PERFORMANCE_MAX
# No ad groups — use Asset Groups instead

# Asset Group creation
asset_group_service = client.get_service("AssetGroupService")
operation = client.get_type("AssetGroupOperation")
asset_group = operation.create

asset_group.campaign = campaign_resource_name
asset_group.name = "AssetGroup_MainOffer"
asset_group.final_urls.append("https://yoursite.com/landing-page")

# Assets required:
# - 20 images (various sizes)
# - 5 videos (or Google will auto-generate — provide your own!)
# - 5 short headlines (30 chars max)
# - 5 long headlines (90 chars max)
# - 5 descriptions (90 chars max)
# - Business name
# - Logo

# Audience Signal (not restriction, just guidance)
asset_group_signal = client.get_type("AssetGroupSignal")
audience = asset_group_signal.audience
audience.audience = customer_list_resource_name
```

---

## Naming Convention

```
GOOG_{TYPE}_{AUDIENCE/THEME}_{OFFER}_{YYYYMM}

Examples:
GOOG_Search_Brand_Demo_202601
GOOG_Search_Competitor_Trial_202601
GOOG_PMAX_Ecom_ProductCatalog_202601
GOOG_DemandGen_Retarget_Offer_202601
```

---

## Common Issues & Solutions

| Issue | Diagnosis | Fix |
|---|---|---|
| Learning limited | <50 conversions/month | Loosen target CPA / use Maximize Conversions |
| Low quality score | Ad relevance or LP mismatch | Tighten ad group themes, improve LP |
| Impression share lost | Budget or rank | Increase budget or improve ad quality |
| PMAX cannibalization | PMAX stealing brand traffic | Add brand exclusion in PMAX settings |
| Broad match runaway | Too much irrelevant traffic | Add negatives, check search terms report weekly |

---

## Scientific Creative Testing (Search & Display)

Apply the 3:2:2 method to Google Ads:

1. **Search**: Test 3 pinned headlines, 2 pinned descriptions, 2 different final URLs (landing pages)
2. **Display**: Test 3 main images, 2 headlines, 2 CTAs
3. **Analyze**: Use CTR and Conversion Rate to identify winning assets before scaling into PMAX

---

**Document Version**: 2.0  
**Last Updated**: March 18, 2026  
**Scope**: Google Ads 2026 specifications, API, and best practices
