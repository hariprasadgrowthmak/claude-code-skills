# Meta Ads Performance Report - [Date Range]

**Prepared By:** Manus AI
**Date:** [Current Date]

## Executive Summary

[Brief overview of overall campaign performance during the specified date range. Highlight key successes, challenges, and major trends.]

## Key Metrics Overview

| Metric | Current Period | Previous Period | Change (%) | Status |
| :----- | :------------- | :-------------- | :--------- | :----- |
| Spend | $[Total Spend] | $[Previous Spend] | [Change %] | [Status] |
| Impressions | [Total Impressions] | [Previous Impressions] | [Change %] | [Status] |
| Reach | [Total Reach] | [Previous Reach] | [Change %] | [Status] |
| Clicks | [Total Clicks] | [Previous Clicks] | [Change %] | [Status] |
| CTR | [CTR %] | [Previous CTR %] | [Change %] | [Status] |
| Conversions | [Total Conversions] | [Previous Conversions] | [Change %] | [Status] |
| CPA | $[CPA] | $[Previous CPA] | [Change %] | [Status] |
| ROAS | [ROAS] | [Previous ROAS] | [Change %] | [Status] |

## Performance Analysis

### Spend & Delivery
[Analyze spend patterns, delivery issues, and budget utilization. Mention any significant fluctuations or anomalies.]

### Conversion & ROAS
[Detailed analysis of conversion performance and Return on Ad Spend. Discuss factors influencing these metrics.]

### Audience Insights
[Insights into audience performance, including top-performing demographics, interests, or custom audiences.]

### Creative Performance
[Analysis of ad creative performance. Which creatives are performing best/worst and why?]

## Optimization Recommendations

Based on the analysis, here are the recommended actions to improve campaign performance:

1.  **[Recommendation 1]:** [Detailed explanation of the recommendation, including expected impact and rationale.]
    *   **Current Status:** [Relevant current data or campaign state.]
    *   **Expected Impact:** [Anticipated outcome if the recommendation is implemented.]

2.  **[Recommendation 2]:** [Detailed explanation of the recommendation, including expected impact and rationale.]
    *   **Current Status:** [Relevant current data or campaign state.]
    *   **Expected Impact:** [Anticipated outcome if the recommendation is implemented.]

3.  **[Recommendation 3]:** [Detailed explanation of the recommendation, including expected impact and rationale.]
    *   **Current Status:** [Relevant current data or campaign state.]
    *   **Expected Impact:** [Anticipated outcome if the recommendation is implemented.]

## Next Steps

[Outline the immediate next steps and actions to be taken, pending user approval.]
