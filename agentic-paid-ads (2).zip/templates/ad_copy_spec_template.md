# Google Ads Ad Copy & Asset Plan - [Campaign Name]

**Prepared By:** Manus AI
**Date:** [Current Date]

## Campaign Overview

*   **Campaign Name:** [Name of the Google Ads Campaign]
*   **Objective:** [Campaign Objective, e.g., Drive Sales, Generate Leads, Increase Brand Awareness]
*   **Target Audience:** [Description of the target audience]
*   **Key Selling Proposition:** [Unique value proposition of the product/service]

## Responsive Search Ads (RSAs) - Ad Group: [Ad Group Name]

### Headlines (Max 30 characters each)

| Headline # | Content | Pin Position (Optional) |
| :--------- | :------ | :---------------------- |
| 1 | [Headline 1 Text] | Position 1 |
| 2 | [Headline 2 Text] | Position 2 |
| 3 | [Headline 3 Text] | |
| 4 | [Headline 4 Text] | |
| 5 | [Headline 5 Text] | |

### Descriptions (Max 90 characters each)

| Description # | Content | Pin Position (Optional) |
| :------------ | :------ | :---------------------- |
| 1 | [Description 1 Text] | Position 1 |
| 2 | [Description 2 Text] | |
| 3 | [Description 3 Text] | |
| 4 | [Description 4 Text] | |

## Ad Extensions (Assets)

### Sitelinks

| Sitelink Text | Description Line 1 | Description Line 2 | Final URL |
| :------------ | :----------------- | :----------------- | :-------- |
| [Sitelink 1] | [Description 1] | [Description 2] | [URL] |
| [Sitelink 2] | [Description 1] | [Description 2] | [URL] |

### Callouts

| Callout Text |
| :----------- |
| [Callout 1] |
| [Callout 2] |

### Structured Snippets

| Header | Values |
| :----- | :----- |
| [Header] | [Value 1], [Value 2], [Value 3] |

## Display & Video Ad Creative Brief

### Ad Type: [e.g., Responsive Display Ad, YouTube In-Stream]

*   **Key Message:** [Primary message to convey]
*   **Visual Concept:** [Description of visual elements, imagery, or video style]
*   **Call to Action:** [Specific CTA text and desired action]
*   **Target Audience:** [Brief description of the audience for this creative]
*   **Assets Required:**
    *   **Images:** [List image sizes/types, e.g., 1200x628, 1200x1200]
    *   **Videos:** [List video lengths/aspect ratios, e.g., 15-30s, 16:9]
    *   **Logos:** [Logo requirements]

## Performance Max Asset Group Plan

### Asset Group Name: [Asset Group Name]

*   **Final URL:** [Landing page for this asset group]
*   **Headlines:** [List of 3-5 headlines]
*   **Long Headlines:** [List of 1-5 long headlines]
*   **Descriptions:** [List of 2-4 descriptions]
*   **Business Name:** [Business Name]
*   **Images:** [List of image assets with sizes/aspect ratios]
*   **Logos:** [List of logo assets with sizes/aspect ratios]
*   **Videos:** [List of YouTube video URLs]
