# CRM Follow-up Sequence - [Campaign Name]

**Prepared By:** Manus AI
**Date:** [Current Date]

## Sequence Overview

*   **Trigger:** [e.g., Lead Magnet Download, Demo Request, Purchase]
*   **Goal:** [e.g., Nurture lead to sale, Onboard new customer, Encourage repeat purchase]
*   **Channels:** [e.g., Email, SMS]
*   **Target Audience Segment:** [Description of the segment this sequence targets]

## Sequence Steps

### Step 1: [Day 0] - Welcome/Confirmation
*   **Channel:** [Email/SMS]
*   **Subject/Message:** [e.g., "Your Free Guide is Here!", "Thanks for requesting a demo!"]
*   **Content Focus:** Deliver immediate value, confirm action, set expectations.
*   **CTA:** [e.g., "Download Now", "Schedule Your Demo"]

### Step 2: [Day 1-2] - Value Add/Problem Solving
*   **Channel:** [Email]
*   **Subject:** [e.g., "Did you know [Problem]? Here's how to fix it."]
*   **Content Focus:** Provide additional valuable content related to their initial interest, address common pain points.
*   **CTA:** [e.g., "Read Our Blog", "Watch a Tutorial"]

### Step 3: [Day 3-4] - Product/Service Introduction
*   **Channel:** [Email]
*   **Subject:** [e.g., "How [Your Product] Solves [Problem]"]
*   **Content Focus:** Introduce your product/service as the solution, highlight key benefits.
*   **CTA:** [e.g., "Learn More", "See Features"]

### Step 4: [Day 5-7] - Social Proof/Objection Handling
*   **Channel:** [Email/SMS]
*   **Subject:** [e.g., "Don't just take our word for it...", "Common Questions About [Product]"]
*   **Content Focus:** Share testimonials, case studies, or address common objections.
*   **CTA:** [e.g., "Read Case Study", "View FAQs"]

### Step 5: [Day 7-10] - Final Offer/Urgency
*   **Channel:** [Email/SMS]
*   **Subject:** [e.g., "Last Chance: [Offer] Ends Soon!"]
*   **Content Focus:** Present a clear offer with urgency or scarcity.
*   **CTA:** [e.g., "Get Started Now", "Claim Your Discount"]

## Notes & Considerations

*   **Personalization:** Utilize CRM data for personalized messages.
*   **A/B Testing:** Continuously test subject lines, content, and CTAs.
*   **Exit Intent:** Consider different sequences for users who show exit intent.
*   **Integration:** Ensure seamless integration with [CRM System Name] and [Email/SMS Platform Name].
