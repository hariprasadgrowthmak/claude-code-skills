# Creative Test Report - [Test Name]

**Prepared By:** Manus AI
**Date:** [Current Date]

## Test Overview

*   **Campaign:** [Campaign Name]
*   **Objective:** [e.g., Identify best performing headline, optimize CTR]
*   **Test Period:** [Start Date] to [End Date]
*   **Budget Allocated:** [Amount]
*   **Methodology:** [e.g., 3:2:2 Method, A/B Test]

## Key Findings

*   **Winning Element(s):** [Describe the creative element(s) that performed best]
*   **Key Metrics Impact:**
    *   **CTR:** [Percentage increase/decrease]
    *   **CVR:** [Percentage increase/decrease]
    *   **CPC:** [Percentage increase/decrease]
    *   **CPA:** [Percentage increase/decrease]

## Creative Variations & Performance

| Creative Element | Variation 1 | Variation 2 | Variation 3 | Winning Variation |
| :--------------- | :---------- | :---------- | :---------- | :---------------- |
| **Headline**     | [Headline A]| [Headline B]| [Headline C]| [Winning Headline]|
| **Description**  | [Desc 1]    | [Desc 2]    |             | [Winning Desc]    |
| **CTA**          | [CTA X]     | [CTA Y]     |             | [Winning CTA]     |

## Detailed Performance Data

| Metric        | Variation 1 | Variation 2 | Variation 3 | Control (if any) |
| :------------ | :---------- | :---------- | :---------- | :--------------- |
| Impressions   | [Value]     | [Value]     | [Value]     | [Value]          |
| Clicks        | [Value]     | [Value]     | [Value]     | [Value]          |
| CTR           | [Value]%    | [Value]%    | [Value]%    | [Value]%         |
| Conversions   | [Value]     | [Value]     | [Value]     | [Value]          |
| CVR           | [Value]%    | [Value]%    | [Value]%    | [Value]%         |
| Spend         | [Value]     | [Value]     | [Value]     | [Value]          |
| CPC           | [Value]     | [Value]     | [Value]     | [Value]          |
| CPA           | [Value]     | [Value]     | [Value]     | [Value]          |

## Recommendations

*   **Action:** [e.g., Scale winning creative, further test specific element]
*   **Expected Impact:** [e.g., Increase overall campaign ROAS by X%, reduce CPA by Y%]
