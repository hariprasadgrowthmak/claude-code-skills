# Writesonic API — Tool Reference

Writesonic is the **primary AI content engine** for this SEO/GEO workflow.
All content generation, optimization, and AI-assisted SEO tasks should use Writesonic first
before falling back to Claude's own generation.

---

## API Configuration

**Base URL**: `https://api.writesonic.com`
**Auth Header**: `X-API-KEY: [see config/api-keys.env]`
**Content-Type**: `application/json`

**Engine**: Use `"gpt-4o"` for quality work. Use `"economy"` for high-volume batch tasks.

---

## Core API Endpoints Used in This Workflow

### 1. Chatsonic (Primary — Use for most tasks)
Writesonic's most powerful endpoint. Supports web search, SEO context, and long-form generation.

```bash
POST https://api.writesonic.com/v2/business/content/chatsonic?engine=premium&language=en

Headers:
  X-API-KEY: [WRITESONIC_API_KEY]
  Content-Type: application/json

Body:
{
  "enable_google_results": true,
  "enable_memory": false,
  "input_text": "[Your prompt here]"
}
```

**Use for**: Research, content outlines, article drafts, FAQ generation, meta tag writing,
competitor analysis summaries, schema markup generation.

---

### 2. Article Writer v5 (Long-form SEO Content)
Optimized for SEO blog posts and articles with keyword targeting.

```bash
POST https://api.writesonic.com/v2/business/content/article-writer-5?engine=premium&language=en&num_copies=1

Body:
{
  "article_title": "[Exact title]",
  "article_intro": "[Optional intro paragraph]",
  "article_sections": ["Section 1", "Section 2", "Section 3"],
  "writing_style": "informative",
  "conclusion_and_cta": "Contact us for a free consultation"
}
```

**Use for**: Full blog post generation (Phase 3), pillar page drafts, cluster content creation.

---

### 3. SEO Meta Tags
Generates optimized title tags and meta descriptions.

```bash
POST https://api.writesonic.com/v2/business/content/seo-meta-tags?engine=premium&language=en&num_copies=3

Body:
{
  "product_name": "[Page/Post Title]",
  "product_description": "[Brief description of the page content]",
  "search_term": "[Primary target keyword]"
}
```

**Use for**: Batch meta tag optimization (Phase 3), title tag A/B variants.

---

### 4. Landing Page / Service Page Copy
Generates full service page copy with SEO-optimized structure.

```bash
POST https://api.writesonic.com/v2/business/content/landing-pages?engine=premium&language=en&num_copies=1

Body:
{
  "product_name": "[Service Name]",
  "product_description": "[What it does, who it's for]",
  "features": ["Feature 1", "Feature 2", "Feature 3"],
  "customer_pain_points": ["Pain 1", "Pain 2"]
}
```

**Use for**: Service page creation (Phase 3), GEO location page generation (Phase 5).

---

### 5. Content Rephrase / Rewrite
Rewrites existing content while preserving SEO intent.

```bash
POST https://api.writesonic.com/v2/business/content/content-rephrase?engine=premium&language=en&num_copies=1

Body:
{
  "content": "[Existing content to rephrase]",
  "tone_of_voice": "professional"
}
```

**Use for**: Content refresh (Phase 3), improving thin content, location page differentiation (Phase 5).

---

## Workflow Integration by Phase

### Phase 1 (Keyword Research)
- Use Chatsonic to generate seed keyword ideas: prompt it with the business description
- Use Chatsonic to analyze search intent for a list of keywords
- Use Chatsonic to identify content gaps vs competitors by describing their site

### Phase 3 (On-Page Content) ← Primary usage
- Generate content briefs using Chatsonic
- Draft full articles using Article Writer v5 with the exact H2 structure from the brief
- Generate 3 variants of title tags + meta descriptions using SEO Meta Tags endpoint
- Generate FAQ sections using Chatsonic with: "Generate 8 FAQ questions and 50-word answers for [topic]"
- Generate location page copy using Landing Pages endpoint

### Phase 5 (GEO)
- Use Chatsonic to draft AI-optimized content (direct answer format)
- Generate GBP business descriptions using Chatsonic
- Generate location-specific service page variants using Content Rephrase

### Phase 6 (Reporting)
- Use Chatsonic to generate monthly report narrative commentary from raw data
- "Here is this month's SEO data: [data]. Write a 3-paragraph performance summary in a professional, data-led tone."

---

## Prompt Templates for Common SEO Tasks

### Content Brief Generation
```
You are an expert SEO content strategist. Create a detailed content brief for:
- Target keyword: [keyword]
- Search intent: [informational/commercial/transactional]
- Target audience: [audience description]
- Competitors ranking top 3: [competitor URLs or descriptions]

Include: recommended H2 structure, key points to cover, word count target,
suggested internal links, FAQ questions to answer, and a featured snippet target.
```

### Blog Post Article Prompt (for Article Writer v5)
```
Title: [Exact title with primary keyword]
Sections: [Based on content brief H2s]
Tone: Expert but approachable
Include: Statistics, examples, actionable steps, FAQ section at the end
Call to action: [Specific CTA for this page]
```

### Meta Tag Batch Prompt (for SEO Meta Tags)
```
Page: [Page name]
Description: [What this page covers in 2 sentences]
Primary keyword: [keyword]
Brand: [Brand name]
Generate 3 title tag options (max 60 chars) and 3 meta description options (max 160 chars).
```

### Location Page Differentiation Prompt
```
We have a service page for "[service]" that targets [city 1].
Rewrite the following intro paragraph and FAQ section to target [city 2].
Add local context specific to [city 2]. Keep the same structure and length.
[Original content]
```

---

## Quality Control Rules for Writesonic Output

All Writesonic-generated content MUST be reviewed and edited before publishing:

1. **Fact-check all statistics** — AI can hallucinate data. Verify every stat cited.
2. **Add E-E-A-T signals** — AI doesn't have first-hand experience. Add client-specific
   examples, case study data, or expert perspective.
3. **Check for generic phrasing** — Remove phrases like "In today's fast-paced world...",
   "In conclusion...", "It's important to note that..."
4. **Verify keyword density** — Aim for 1–2% primary keyword density. Don't keyword stuff.
5. **Add internal links** — AI won't know the client's site structure. Add manually.
6. **Human review** — Every published piece should have a human read-through for tone,
   accuracy, and brand alignment.

---

## Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| 401 Unauthorized | Invalid API key | Check `config/api-keys.env` |
| 429 Rate Limited | Too many requests | Add 2-second delay between calls |
| 400 Bad Request | Malformed JSON body | Check request body format |
| 500 Server Error | Writesonic outage | Retry after 60 seconds |
