# Phase 3: On-Page SEO & Content Strategy

**Estimated time: 16–24 hours (initial setup + ongoing)**
**Output: Optimized pages, Content calendar, Meta tag spreadsheet, Content briefs**

On-page SEO is where keyword research meets execution. Every page must be intentionally designed
to rank for its target keyword cluster while delivering genuine value to the reader. Content that
ranks long-term satisfies both Google's algorithms and real human needs.

---

## Writesonic Integration (Phase 3)

Phase 3 is the **primary Writesonic phase**. Before starting any content task:
1. Read `config/api-keys.env` → load `WRITESONIC_API_KEY`
2. Read `tools/writesonic.md` → choose the right endpoint for the task:
   - Full blog posts → Article Writer v5
   - Meta tags → SEO Meta Tags endpoint
   - Service/landing pages → Landing Pages endpoint
   - Content refresh → Content Rephrase endpoint
   - Briefs, FAQs, research → Chatsonic

All Writesonic output MUST be reviewed against the quality control rules in `tools/writesonic.md`
before handing to client or publishing.

---

## 3.1 Content Strategy & Calendar (2h)

### Content Hierarchy
Based on the topic cluster architecture from Phase 1, build the content calendar:

**Week 1–2 (Quick Wins)**
Optimize existing pages that already have traction but aren't fully optimized.
Find these in GSC: positions 8–20 with significant impressions = "low-hanging fruit."
These often need: better title tags, stronger content, improved internal links.

**Week 3–4 (Pillar Pages)**
Create or rebuild Tier 1 pillar pages first. These are the most important pages and
other cluster content will link back to them.

**Month 2 (Cluster Pages)**
Publish Tier 2 cluster pages. At least 2–4 per pillar page.

**Month 3+ (Support Content + Refresh)**
Tier 3 supporting content + regular refresh of existing content.

### Content Calendar Template
For each piece, define before writing:

| Field | Value |
|-------|-------|
| Target URL | /blog/what-is-content-marketing/ |
| Page Type | Blog post (Tier 2 cluster) |
| Primary Keyword | "what is content marketing" |
| Supporting Keywords | "content marketing definition", "content marketing examples" |
| Search Intent | Informational |
| Target Word Count | 1,800 words |
| SERP Features to Target | Featured snippet, PAA |
| Author/E-E-A-T signal | Named author with bio + credentials |
| Publish Date | [date] |
| Status | Draft / Review / Published |

---

## 3.2 Content Briefing (Per Page, 30–60min each)

Before writing any piece of content, create a content brief. This prevents rewrites.

### Content Brief Generation with Writesonic (Chatsonic)
Use this prompt template via the Chatsonic endpoint:
```
You are a senior SEO content strategist. Create a detailed content brief for:
- Business: [business name and description]
- Target keyword: [primary keyword]
- Supporting keywords: [list]
- Search intent: [type]
- Top 3 competitors currently ranking: [URLs or describe]

Output:
1. Recommended H1
2. H2 structure (6–8 subheadings)
3. Key points to cover under each H2
4. Recommended word count
5. 6 FAQ questions with 50-word answers each
6. Suggested featured snippet target (the most likely snippet format + a draft answer in 50 words)
7. Internal link opportunities
8. CTA recommendation
```

### Content Brief Components (Manual Review)
1. **Target keyword + supporting keywords**
2. **Search intent** — what is the user trying to accomplish?
3. **SERP analysis** — review top 3 ranking pages:
   - What headings do they use? (use SEMrush/Ahrefs "SERP analysis")
   - What word count?
   - What questions do they answer?
   - What do they NOT cover? (content gap = your differentiation opportunity)
4. **Recommended structure** — H1, H2s, H3s
5. **Key points to cover** — must-answer questions
6. **Internal links to include** — link to pillar, relevant cluster pages
7. **External authority links** — 1–3 credible sources to cite
8. **CTA** — what should the reader do after reading?
9. **Featured snippet target** — if the SERP shows a featured snippet, write a direct
   answer in 40–60 words to win it

---

## 3.3 SEO Content Creation with Writesonic (Ongoing)

### Step 1: Generate Draft with Writesonic Article Writer v5
Use the Article Writer v5 endpoint from `tools/writesonic.md` with:
- `article_title`: The exact H1 from the content brief
- `article_sections`: The H2s from the content brief
- `writing_style`: "informative" for blogs, "persuasive" for service pages
- `conclusion_and_cta`: The CTA from the content brief

Then apply the quality control checklist from `tools/writesonic.md` before proceeding.

### Step 2: Apply Content Quality Standards (E-E-A-T)

**Experience**: Show first-hand knowledge. Case studies, examples, personal observations.
Not: "According to experts, X is important." Yes: "After auditing 200 sites, we found X."

**Expertise**: Demonstrate deep knowledge. Go beyond surface-level points that AI generates.
Add unique data, expert quotes, proprietary frameworks, counterintuitive insights.

**Authoritativeness**: Named authors with bios, credentials, and links to LinkedIn/portfolio.
About page with team details. Cite credible sources.

**Trustworthiness**: Accurate, up-to-date information. Clear author/business identity.
Secure site (HTTPS). Privacy policy, terms of service. No misleading claims.

### Content Formatting for Both Humans and Search Engines

**Title (H1)**: Include primary keyword, ideally near the front. Max 60 characters.
Compelling for humans too — not just keyword stuffing.

**Introduction (first 100 words)**:
- Answer the question immediately for featured snippet potential
- Establish what the reader will learn
- Include primary keyword naturally

**Subheadings (H2/H3)**:
- Use keyword-rich H2s (these are often pulled for featured snippets and PAA)
- H2s should map to major topics; H3s to subtopics within H2s
- Include question-format headings: "How does X work?" "What is the best Y?"

**Body content**:
- Short paragraphs (3–5 sentences max) for readability
- Use bullet points and numbered lists for scannable information
- Bold key concepts and terms
- Include statistics, data, and examples (cite sources)
- Target word count based on SERP benchmark (match or slightly exceed top competitors)

**Images**:
- Include at least 1 featured image and 1 supporting image per article
- Use descriptive, keyword-rich file names: `content-marketing-strategy.jpg` not `IMG_1234.jpg`
- Add descriptive alt text: "Diagram showing content marketing funnel stages"
- Compress all images to <200KB

**Conclusion + CTA**:
- Summarize key takeaways
- Clear next step: "Download our content calendar template" / "Contact us for a free audit"
- Internal links to related content

---

## 3.4 Meta Tag Optimization (2h)

### Title Tags
**Formula**: `[Primary Keyword] | [Secondary Modifier] | [Brand]`
or: `[Primary Keyword]: [Compelling Benefit] | [Brand]`

**Rules**:
- 50–60 characters (max 60 to avoid truncation in SERPs)
- Include primary keyword, ideally in the first 30 characters
- Write for click-through rate, not just ranking
- Every page needs a unique title tag
- Don't use the same title tag as the H1 (they can be similar but should differ)

**Examples**:
- Bad: "SEO Services | Homepage"
- Good: "SEO Services London | Grow Organic Traffic | Growthmak"

### Meta Descriptions
**Rules**:
- 150–160 characters (longer will be truncated)
- Include primary keyword (bolded in SERPs when matching search)
- Include a compelling benefit and a call to action
- Every page needs a unique meta description
- Not a direct ranking factor — but strongly influences click-through rate (CTR)

**Example**:
"We help London businesses rank #1 on Google with data-driven SEO strategies. Free audit
included. See real results from our SEO clients. Contact us today."

### Meta Tags Audit Checklist
- [ ] All pages have unique title tags (check: Screaming Frog → Page Titles → duplicates)
- [ ] All title tags 50–60 characters
- [ ] All pages have unique meta descriptions
- [ ] All meta descriptions 150–160 characters
- [ ] Primary keyword appears in title and meta description for every page

---

## 3.5 Heading Structure Optimization (2h)

### H1 Tag
- One H1 per page (never more)
- Must contain the primary keyword
- Should match or closely reflect the title tag
- 20–70 characters

### H2 Tags
- Main sections of the page
- Include primary or supporting keywords where natural
- Use question formats for PAA targeting: "What is [X]?", "How does [X] work?"

### H3–H6 Tags
- Subsections under H2s
- Good for long-form content, comparison tables, step-by-step sections

### Common Heading Mistakes
- Skipping levels (H1 → H3, skipping H2)
- Using heading tags for styling (bold text that looks like a heading)
- Multiple H1 tags on one page
- No keywords in headings
- Using generic headings: "Introduction", "Conclusion" (missed keyword opportunity)

---

## 3.6 URL Optimization (2h)

### URL Best Practices
- Short and descriptive: `/seo-audit-checklist/` not `/blog/post-id-4872-seo-checklist-complete-guide-2024/`
- Use hyphens, not underscores (Google treats hyphens as word separators)
- Include primary keyword
- Lowercase only
- No stop words (a, the, and, or) unless needed for readability
- Match the URL hierarchy to site architecture: `/services/technical-seo/` not `/technical-seo-services/`

### URL Hygiene
- Audit for parameter-heavy URLs: fix with canonical tags or noindex
- Fix URL inconsistencies: `/page/` vs `/page` (pick one, 301 redirect the other)
- Clean up old dated URLs: `/blog/2019/post-title/` → `/blog/post-title/` (301 redirect)

---

## 3.7 Image Optimization (2h)

### Technical Image Optimization
- **Format**: Use WebP (90% smaller than JPEG with same quality) or AVIF
- **Compression**: Every image <200KB for blog images, <500KB for hero images
- **Dimensions**: Don't upload a 4000px image to display at 800px — resize first
- **Lazy loading**: Add `loading="lazy"` to all below-fold images

### SEO Image Optimization
- **File name**: Descriptive and keyword-rich: `seo-audit-process.webp`
- **Alt text**: Descriptive, includes keyword where natural: "SEO audit process showing 5 key steps"
  — Don't keyword stuff: "SEO audit SEO checklist SEO process SEO"
- **Title attribute** (optional): Appears on hover; can match alt text
- **Image sitemap**: Submit for image-heavy sites (e-commerce, photography)
- **Structured data**: Add `ImageObject` schema for key images

---

## 3.8 Internal Linking Strategy (2h)

Internal links are one of the most underutilized on-page SEO tools. They pass PageRank
between pages and help Google understand site structure.

### Internal Linking Rules
1. Every new page should receive at least 3 internal links from existing pages
2. Anchor text: use descriptive, keyword-rich text (not "click here" or "read more")
3. Link from high-authority pages (homepage, pillar pages) to new content
4. Link from new content to pillar pages (hub-and-spoke model)
5. Remove or update links to 404 pages immediately
6. Orphan pages (no internal links) must be linked to — they can't rank

### Internal Link Audit
- Screaming Frog: Bulk Export → All Inlinks report
- Find pages with 0 inlinks (orphans)
- Find pages with only 1–2 inlinks (under-linked, need more)
- Find pages with 50+ inlinks (over-linked, may dilute focus — audit and reduce if needed)

### Contextual Linking Pattern
When publishing new content, always:
1. Search existing content for opportunities to link to the new page
2. Update existing relevant pages to link to the new page
3. Add links from the new page to the most relevant pillar and cluster pages

---

## 3.9 E-E-A-T Optimization (1h)

E-E-A-T is not a single ranking factor but a framework Google uses to assess content quality.
It's particularly important for YMYL (Your Money or Your Life) topics: health, finance, legal, safety.

### Signals to Build
**Experience**:
- First-person case studies, examples, and results
- Client testimonials and case studies on service pages
- "We tested X across 50 clients and found..."

**Expertise**:
- Named authors with credentials
- Author bio pages with links to work/publications
- Depth of content that only a true expert would know

**Authoritativeness**:
- Backlinks from recognized industry publications
- Mentions by name in other credible content
- Wikipedia page (for established brands)
- High-quality About Us page with team bios

**Trustworthiness**:
- About page with full team details
- Contact page with physical address if applicable
- Privacy policy, terms of service, cookie policy
- Secure site (HTTPS, no mixed content)
- Accurate and regularly updated content (add "Last updated: [date]")
- No misleading or clickbait content

---

## 3.10 Featured Snippet & PAA Optimization (1h)

Featured snippets appear at position 0 — above all organic results. Winning them dramatically
increases click-through rate.

### How to Win Featured Snippets

**Paragraph snippets** (most common for "what is" and "how to" questions):
- Write a direct 40–60 word answer immediately after the H2 that matches the question
- Format: Question as H2 → Direct answer paragraph → Expanded explanation

**List snippets** (for "how to" and "steps" queries):
- Use numbered lists for step-by-step processes
- Use H3 tags for each step (Google often pulls H3 text as list items)

**Table snippets** (for comparison and data queries):
- Use actual HTML `<table>` elements for comparison content
- Include the comparison keyword in the table caption or surrounding H2

### PAA (People Also Ask) Targeting
- Use AlsoAsked.com to find PAA questions for your target keywords
- Add an FAQ section to relevant pages answering these questions in 40–60 words each
- Add FAQPage schema to FAQ sections

---

## 3.11 Content Refresh Strategy (Ongoing)

Old content loses rankings over time. Regular refreshes maintain and recover positions.

### Refresh Prioritization
Identify pages needing refresh using GSC:
- Pages that were ranking top 5 but have dropped to positions 6–20
- Pages with declining clicks over 6+ months
- Pages with outdated statistics, examples, or references

### Refresh Process
1. Review current SERP for the target keyword — what are top 3 pages doing better?
2. Update all statistics and dates
3. Add new sections covering topics competitors now cover
4. Improve E-E-A-T signals
5. Update internal links (new related content to link to/from)
6. Update meta title/description if CTR has dropped
7. Change "Last updated: [current date]" in the byline
8. Request re-indexation via GSC URL Inspection

---

## Phase 3 Completion Checklist

- [ ] Content calendar created (Month 1–3)
- [ ] Content briefs written for all Priority 1 content
- [ ] All Priority 1 pages created or optimized
- [ ] All pages have unique, optimized title tags (50–60 chars)
- [ ] All pages have unique, compelling meta descriptions (150–160 chars)
- [ ] H1 on every page, H2/H3 structure logical and keyword-rich
- [ ] URLs clean, short, keyword-optimized
- [ ] All images: WebP format, compressed, descriptive filenames, alt text
- [ ] Internal linking audit: no orphan pages, new pages linked from 3+ existing pages
- [ ] E-E-A-T signals in place: author bios, About page, trust signals
- [ ] FAQ sections added to relevant pages with FAQPage schema
- [ ] Quick-win pages optimized (GSC positions 8–20)
- [ ] Content refresh schedule established for existing content

**→ Proceed to Phase 4: Off-Page Authority & Link Building**
