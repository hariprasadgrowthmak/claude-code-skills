# Phase 1: Keyword Research & Topic Architecture

**Estimated time: 12–16 hours**
**Output: Master Keyword Spreadsheet, Topic Cluster Map, Keyword-to-Page Map, Priority Matrix**

Keyword research is the strategic backbone of the entire SEO engagement. Done right, it tells you
exactly what content to create, in what order, and with what angle. The goal is not just a list of
keywords — it's a complete content architecture that builds topical authority.

---

## Writesonic Integration (Phase 1)

Before starting, read `config/api-keys.env` to load `WRITESONIC_API_KEY` and
read `tools/writesonic.md` for the Chatsonic endpoint details.

**Writesonic is used in this phase for**:
- Seed keyword brainstorming (Chatsonic prompt)
- Search intent classification at scale (Chatsonic prompt)
- Content brief generation (Chatsonic prompt)

---

## 1.1 Seed Keyword Identification (0.5h)

Start with the business, not the tools. Before opening Ahrefs or SEMrush:

- List all products, services, and solutions the business offers
- List the pain points and problems the target customer searches for
- List industry jargon AND plain-language equivalents (customers search in plain English)
- List competitor brand names (for gap analysis later)

**Output**: 20–50 seed keywords/phrases that represent the core business

**Sources for seeds**:
- Client intake conversation
- Existing GSC data (queries already driving impressions)
- Competitor homepage H1s and nav items
- Amazon/Reddit/Quora for how real customers describe the problem
- **Writesonic (Chatsonic)**: Send this prompt to the Chatsonic endpoint:
  `"You are an SEO expert. List 40 seed keywords a potential customer would search to find [business description]. Include both head terms and long-tail variations. Output as a comma-separated list."`

---

## 1.2 Keyword Expansion (1h)

Use SEMrush, Ahrefs, or Google Keyword Planner to expand seeds into a large raw keyword pool.

### Expansion Methods
- **Ahrefs Keywords Explorer**: Enter seeds → "Matching terms" + "Related terms"
- **SEMrush Keyword Magic Tool**: Enter seed → filter by intent type
- **Google "People Also Search For"**: Manual SERP mining
- **Autocomplete Mining**: "[seed keyword] a/b/c..." systematically
- **GSC Query Export**: All queries with >0 clicks in last 12 months
- **Answer The Public / AlsoAsked**: Question-based keyword expansion
- **Competitor keyword exports**: Ahrefs → Competing Domains → all their keywords

### GEO Keyword Layer (Local/Regional Clients)
For every core keyword, add geographic modifiers:
- "[service] + [city]" (e.g., "web design London")
- "[service] near me" (high-intent mobile searches)
- "[service] + [neighborhood/suburb]"
- "[service] + [county/state/region]"
- "best [service] in [city]"
- "[service] + [city] + [qualifier: affordable, fast, certified]"

### AI/Conversational Query Layer (GEO)
Mine question-based and conversational queries that AI engines answer:
- "How to [achieve outcome related to your service]"
- "What is [industry concept]"
- "What's the best [product/service] for [use case]"
- "Is [your service] worth it"
- "[service] vs [alternative]"
- "How much does [service] cost"

**Target**: 500–2,000 raw keywords before filtering

---

## 1.3 Data Analysis & Filtering (1h)

Pull the following metrics for every keyword (from Ahrefs or SEMrush):

| Metric | Purpose |
|--------|---------|
| Search Volume (monthly) | Size of opportunity |
| Keyword Difficulty (KD) | Effort to rank |
| Cost Per Click (CPC) | Commercial intent signal |
| Traffic Potential | More reliable than volume alone (Ahrefs) |
| SERP Features | Featured snippet, local pack, PAA, etc. |
| Trend (12 months) | Growing vs declining interest |

### Filtering Rules
Remove keywords that are:
- Irrelevant to the business (even if high volume)
- KD > 70 unless you have a strong domain (DR 50+) or long-term budget
- Zero commercial value (pure informational with no conversion path)
- Duplicate intent (same topic searched different ways — pick the best one)

Keep keywords that are:
- KD < 30 and Volume > 50: **Quick wins — prioritize these**
- KD 30–60 and Volume > 200: **Medium-term targets**
- KD > 60 and Volume > 1,000: **Long-term authority plays**
- High CPC ($5+): Strong commercial intent regardless of volume

**Target after filtering**: 100–500 actionable keywords

---

## 1.4 Search Intent Analysis (1.5h)

For every keyword, classify intent. This determines content format — getting this wrong means
even a perfectly written page will fail to rank.

### Intent Types
| Intent | What the Searcher Wants | Content Format |
|--------|------------------------|---------------|
| **Informational** | Learn something | Blog post, guide, FAQ, how-to |
| **Navigational** | Find a specific site/page | Brand page, login page |
| **Commercial Investigation** | Compare options before buying | Comparison, review, "best X" list |
| **Transactional** | Ready to buy/contact | Product page, service page, landing page |

### Writesonic Intent Classification (for bulk processing)
Use Chatsonic to classify intent for large keyword lists efficiently:
```
Classify the search intent for each of these keywords as one of:
[Informational / Commercial Investigation / Transactional / Navigational].
Return a table with two columns: Keyword | Intent.

Keywords:
[paste list of 20-30 keywords]
```

### How to Verify Intent
Always check the actual SERP — tools can misclassify. Look at:
- What content types dominate the first 3 results?
- Are results mostly articles or mostly product/service pages?
- Does Google show a local pack? (local intent)
- Does Google show a featured snippet? (informational intent, direct answer needed)

### Intent-to-Format Mapping
- "how to install solar panels" → Informational → Long-form guide
- "solar panel installation services london" → Transactional → Service landing page
- "best solar panel brands" → Commercial Investigation → Comparison article
- "SolarEdge vs Enphase" → Commercial Investigation → Versus comparison page

---

## 1.5 Competitive Keyword Gap Analysis (1h)

Find keywords competitors rank for that the client does not.

### Process
1. In Ahrefs: Competitive Analysis → Content Gap → Enter client domain + 3 competitors
2. Filter for keywords where client has no ranking (position 0) and competitors rank in top 20
3. Sort by Traffic Potential → identify the highest-value gaps
4. In SEMrush: Keyword Gap Tool → same process

### Gap Categories
- **Easy wins**: Client has content that could rank but hasn't targeted these keywords explicitly
- **Missing content**: Topics competitors cover that the client has no page for
- **Structural gaps**: Competitors have pillar pages; client has only thin blog posts

**Output**: Gap keyword list added to master spreadsheet with "gap" tag

---

## 1.6 Keyword Clustering & Grouping (2h)

Group keywords by topic, not by individual keyword. One page ranks for dozens of related terms —
this is the modern reality of semantic search.

### Clustering Method
Group keywords that share:
1. The same core topic/concept
2. Similar search intent
3. Would logically be answered by the same page

**Example cluster: "content marketing agency"**
- content marketing agency (primary)
- content marketing services (variation)
- content marketing company (variation)
- hire content marketing agency (transactional variation)
- best content marketing agencies 2024 (commercial variation)
- content marketing agency pricing (informational)

All 6 of these → one service page, targeting all simultaneously

### Topic Cluster Architecture (CRITICAL)
Organize clusters into a 3-tier content architecture:

**Tier 1: Pillar Pages** (high volume, broad topics, 2,000–4,000 words)
- One per major service/product category
- Comprehensive overview of the entire topic
- Links out to all related cluster pages

**Tier 2: Cluster Pages** (medium volume, specific subtopics, 1,000–2,500 words)
- Deep dives on specific aspects of the pillar topic
- Link back to the pillar page

**Tier 3: Supporting Content** (low volume, niche/long-tail, 500–1,500 words)
- FAQ pages, glossary entries, specific how-to guides
- Link to relevant Tier 2 and Tier 1 pages

**Example architecture for an SEO agency:**
```
Pillar: "SEO Services" (Tier 1)
├── Cluster: "Technical SEO Services" (Tier 2)
├── Cluster: "Local SEO Services" (Tier 2)
├── Cluster: "SEO for E-commerce" (Tier 2)
│   ├── Support: "Product Page SEO Tips" (Tier 3)
│   └── Support: "Category Page Optimization" (Tier 3)
└── Cluster: "Link Building Services" (Tier 2)
```

---

## 1.7 Keyword Mapping (2h)

Assign every keyword cluster to a specific URL. This is the content architecture plan.

### Mapping Rules
- One primary keyword per page (the keyword the page is most optimized for)
- Supporting keywords: 3–10 secondary keywords per page
- Avoid keyword cannibalization: two pages should not target the same primary keyword
- Existing pages: map keywords to existing content where possible (avoid creating new pages if
  an existing page can be optimized instead)

### Keyword-to-Page Map Format

| URL | Page Type | Primary Keyword | Secondary Keywords | Intent | Status |
|-----|-----------|----------------|-------------------|--------|--------|
| /services/seo | Service page | "SEO services" | "SEO company", "SEO agency" | Transactional | Existing |
| /blog/what-is-seo | Blog post | "what is SEO" | "SEO definition", "how SEO works" | Informational | Create new |

---

## 1.8 Keyword Prioritization (2h)

Not all keywords can be targeted at once. Use a priority scoring matrix to decide what to build first.

### Priority Scoring Matrix (score each keyword 1–5, total = priority score)

| Factor | Weight | Scoring |
|--------|--------|---------|
| Business relevance | 3x | 5=core offer, 1=peripheral |
| Search volume | 2x | 5=1000+, 1=<50 |
| KD (inverted) | 2x | 5=KD<20, 1=KD>60 |
| Commercial intent | 2x | 5=transactional, 1=purely informational |
| Quick win potential | 1x | 5=page exists, needs optimization; 1=new page needed |

### Priority Tiers
- **Priority 1 (Do first)**: Score 18–25 — Quick wins, high-value, achievable
- **Priority 2 (Month 2–3)**: Score 12–17 — Good ROI, moderate effort
- **Priority 3 (Long-term)**: Score <12 — Authority builders, patience required

---

## 1.9 Topic Cluster & Content Calendar Output (1h)

Compile all of the above into:

### Master Keyword Spreadsheet (xlsx)
Columns:
- Keyword | Volume | KD | CPC | Intent | Cluster | Assigned URL | Priority Tier | Status

### Topic Cluster Visual Map
Create a visual showing pillar → cluster → support relationships.
Recommend using a Mermaid diagram or simple table format.

### Content Calendar (Month 1–3)
Based on priority tiers, create a publishing schedule:
- Week 1–2: Optimize existing pages (quick wins)
- Week 3–4: Publish Tier 1 pillar pages
- Month 2: Publish Tier 2 cluster pages
- Month 3: Publish Tier 3 supporting content + continue Tier 2

---

## Phase 1 Completion Checklist

- [ ] Seed keywords identified (20–50)
- [ ] Raw keyword pool built (500–2,000 keywords)
- [ ] GEO keyword layer added (for local clients)
- [ ] AI/conversational query layer added
- [ ] Data pulled: volume, KD, CPC, traffic potential
- [ ] Keywords filtered to actionable list (100–500)
- [ ] Search intent classified for all priority keywords
- [ ] Competitive keyword gap analysis complete
- [ ] Keywords clustered into topic groups
- [ ] Topic cluster architecture designed (pillar/cluster/support)
- [ ] Keyword-to-URL map completed
- [ ] Priority scoring matrix applied
- [ ] Master keyword spreadsheet delivered to client
- [ ] Content calendar (Month 1–3) created

**→ Proceed to Phase 2: Technical SEO Foundation**
