# Phase 5: GEO & AI Search Optimization

**Estimated time: 6–10 hours (initial) + ongoing**
**Output: GBP Optimization, AI Answer Strategy, Entity Plan, Geo-targeted Content**

GEO — Generative Engine Optimization — is the emerging discipline of optimizing for AI-powered
search. As ChatGPT, Perplexity, Google AI Overviews, and Bing Copilot become primary discovery
tools, appearing in AI-generated answers is as important as ranking in traditional SERPs.

This phase covers both local SEO (geographic targeting) and AI answer engine optimization.

---

## 5.1 Google Business Profile Optimization (2h)

Google Business Profile (GBP) is the most powerful local SEO asset. It controls the Local Pack
(the map + 3 business results that appear for local searches) and Google Maps rankings.

### GBP Initial Setup / Audit
- Claim and verify the profile (postcard verification, phone, email, or instant verification)
- Confirm business name matches exactly what's on the website and all citations (NAP consistency)
- Select the most accurate primary category (this is the most important ranking factor in GBP)
- Add relevant secondary categories (max 9)

### Profile Completeness (complete = 70% better local ranking)
- [ ] Business name (exact match — no keyword stuffing, Google will suspend for this)
- [ ] Primary + secondary categories
- [ ] Full address (or service area if no physical location)
- [ ] Phone number (local number preferred over 0800/toll-free)
- [ ] Website URL
- [ ] Business hours (including special hours for holidays)
- [ ] Business description (750 chars max — include primary keyword and service area naturally)
- [ ] Services/Products added (each with description and price if applicable)
- [ ] Opening date
- [ ] Attributes (e.g., "Women-owned", "Wheelchair accessible", "Outdoor seating")

### GBP Photo Strategy
Photos significantly impact click-through rate and trust:
- Logo (PNG, 720×720px)
- Cover photo (1080×608px) — first impression
- Exterior photos (help customers identify the location)
- Interior photos (build trust)
- Team/people photos (humanize the business)
- Product/service photos
- Minimum: 10 photos. Target: 50+ photos for competitive markets
- Post new photos monthly — GBP rewards active profiles

### Google Posts
Use GBP Posts to publish updates (they appear in the Knowledge Panel):
- Offers: "20% off this month"
- Events: workshop/webinar announcements
- Updates: new services, news, blog posts
- Aim for 2–4 posts per month

### Review Strategy
Reviews are a top local ranking factor AND conversion driver:
- Build a review request process: post-purchase email/SMS asking for a Google review
- Respond to every review (positive and negative) within 24–48 hours
- Never incentivize reviews (Google policy violation)
- Target: 50+ reviews at 4.5+ stars for competitive markets

### Q&A Section
- Seed the Q&A section with 5–10 common customer questions and answers
- Monitor and answer new questions promptly

---

## 5.2 Local Content & Geo-Targeted Landing Pages (2h)

For businesses serving multiple geographic areas, location-specific landing pages dramatically
improve local search visibility.

### When to Create Location Pages
- Businesses serving multiple cities/regions: create one page per city
- Services with geographic demand: "plumber in Manchester" vs "plumber in Liverpool"
- Each page targets "[service] + [city]" keywords from Phase 1 GEO keyword layer

### Location Page Template
Each page must have unique, genuinely useful content (not just "find our word: [city name]"):

**Structure**:
1. H1: "[Service] in [City Name]"
2. Intro paragraph: What you offer, why it's relevant to [City], unique benefits
3. Services offered in this area (may differ from other locations)
4. Local social proof: "Trusted by 200+ businesses in [City]"
5. Local case study or testimonial (from a [City]-based client)
6. Coverage area map or list of neighborhoods served
7. Local contact details (if applicable) or dedicated local phone number
8. LocalBusiness schema with the city-specific address
9. FAQ section with locally-relevant questions

### Content Differentiation Between Location Pages
Google penalizes duplicate location pages (same content, only city name changed).
Each page must have:
- Unique testimonial from that city
- Unique local context, landmarks, or specific area knowledge
- Unique FAQ answers
- Unique statistics or data relevant to that city

---

## 5.3 AI Answer Engine Optimization (GEO Core) (2h)

AI search engines (ChatGPT with browsing, Perplexity, Google AI Overviews, Bing Copilot)
answer questions by synthesizing information from web sources. To appear in these answers,
your content must be structured to be easily parsed, cited, and recommended by LLMs.

### How AI Engines Choose Sources
AI engines favor content that is:
1. **Clearly authored by a credible source** (named author, organization with authority)
2. **Directly answers the question** (no burying the lede)
3. **Well-structured** (headings, lists, tables make parsing easy)
4. **Widely cited/linked** (backlinks signal credibility to AI training)
5. **From HTTPS, fast-loading, crawlable pages** (same as Google)
6. **Up-to-date** (recent dates preferred for current-events queries)

### Content Optimization for AI Answers

**Direct Answer Principle**: Answer the question in the first 1–3 sentences of each section.
AI engines are built to find direct answers — don't make them dig.

**Entity Definition**: Define key entities clearly.
"[Company Name] is a [type of company] that [does X] for [audience Y] in [geography Z]."
This helps AI models understand who and what you are.

**Question-Based Headings**: Format H2s and H3s as questions AI users would ask.
- "How much does [service] cost in [city]?"
- "What is the difference between X and Y?"
- "Is [service] worth it for [use case]?"

**FAQ Sections**: Every service/product page should include 5–8 FAQs.
These directly feed AI answer engines. Add FAQPage schema.

**Data and Statistics**: Include original data where possible.
AI engines love to cite specific statistics — "X% of businesses report..."
Original data creates quotable, citable content.

**Brand Entity Clarity**: Ensure the brand is consistently mentioned across:
- All website pages (brand name + what it does)
- LinkedIn, Crunchbase, industry directories (entity associations)
- Wikipedia or Wikipedia-like references if the brand is large enough
- Press mentions and news articles

### Monitoring AI Search Presence
Weekly: manually search the client's core queries in:
- Perplexity AI
- ChatGPT (with search enabled)
- Google AI Overviews (where available)
- Bing Copilot

Track:
- Is the client mentioned/cited in AI answers?
- Which competitors ARE mentioned?
- What sources are cited? (potential link/citation targets)
- What questions are AI engines answering that the client could create content for?

---

## 5.4 Entity Building & Knowledge Graph (1h)

Google's Knowledge Graph is a database of entities (people, businesses, places, concepts).
Being in the Knowledge Graph signals authority and helps AI engines understand the brand.

### Entity Building Tactics

**Consistent Brand Identity Across the Web**:
- Same business name format everywhere
- Same logo, same founding date, same description
- Cross-reference all brand properties (website, LinkedIn, Crunchbase, Facebook, Twitter/X)

**Wikipedia**: For established brands, a Wikipedia page is the most powerful entity signal.
Requirements: notability (must be covered by independent, reliable sources), NPOV writing,
citations from credible publications.

**Wikidata**: Add/update the business entity on Wikidata (the structured data counterpart to Wikipedia).
Less editorial scrutiny than Wikipedia — great for emerging brands.

**Google's Structured Data**: Use Organization schema with `sameAs` properties linking to all
official brand profiles:
```json
{
  "@type": "Organization",
  "name": "Brand Name",
  "url": "https://domain.com",
  "sameAs": [
    "https://www.linkedin.com/company/brandname",
    "https://twitter.com/brandname",
    "https://www.facebook.com/brandname",
    "https://en.wikipedia.org/wiki/BrandName"
  ]
}
```

**Press Coverage**: News articles from recognized publications are major entity signals.
Even small trade press mentions help. Digital PR from Phase 4 serves double duty here.

---

## 5.5 Voice Search Optimization (30min)

Voice search (Alexa, Siri, Google Assistant) uses conversational, long-tail queries.
Most voice search results come from featured snippets and local packs.

### Voice Search Content Optimization
- Target question-based keywords: "What is the best...", "How do I...", "Where can I find..."
- Write conversational answers (match how people speak, not how they type)
- Include an FAQ section on every page
- Optimize for featured snippets (voice answers ARE featured snippets, read aloud)
- For local businesses: ensure GBP is fully optimized (voice = "near me" results)

### Speakable Schema
For news and editorial content, add `Speakable` schema to mark up the sections most
appropriate to be read aloud:
```json
{
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".article-body", ".intro"]
  }
}
```

---

## 5.6 AI-Assisted Close Loop Optimization (1h, Ongoing)

Use AI tools to continuously improve SEO performance based on data signals.

### AI-Powered Workflows
- **Content gap identification**: Feed GSC query data to AI — "Which of these queries don't have
  dedicated pages? What content should we create?"
- **Meta tag optimization at scale**: Use AI to improve title tags and meta descriptions for
  50+ pages simultaneously, guided by CTR data from GSC
- **Rank tracking pattern analysis**: Feed rank tracking data to AI — "Which pages are declining?
  What might be causing it based on these SERP features?"
- **Content refresh prioritization**: "Based on these performance metrics, which pages should we
  refresh this month?"
- **Competitor content analysis**: Feed competitor blog archives to AI — "What topics are they
  covering that we're not?"

---

## Phase 5 Completion Checklist

- [ ] Google Business Profile: fully complete, verified, 10+ photos, monthly posts
- [ ] Review request process implemented
- [ ] Location landing pages created (for multi-location businesses)
- [ ] All location pages unique and locally differentiated
- [ ] Content audited for AI answer optimization (direct answers, entity definitions, FAQs)
- [ ] Organization schema with sameAs links deployed
- [ ] AI search monitoring process established (weekly checks in Perplexity, ChatGPT, Google AIO)
- [ ] Entity building: Wikidata, Crunchbase, and key profiles updated with consistent info
- [ ] FAQPage schema on all FAQ-containing pages
- [ ] Voice search FAQ optimization on key service pages
- [ ] AI-assisted optimization workflows documented and in regular use

**→ Proceed to Phase 6: Analytics, Monitoring & Reporting**
