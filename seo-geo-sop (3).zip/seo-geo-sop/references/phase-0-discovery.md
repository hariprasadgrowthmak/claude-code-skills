# Phase 0: Discovery & Strategy Foundation

**Estimated time: 6–10 hours**
**Output: Discovery Document, Competitor Matrix, Baseline Audit Report, KPI Framework**

This phase is non-negotiable. Skipping discovery leads to misaligned strategy, wasted content effort,
and keyword targeting that doesn't match the business. Every client engagement starts here.

---

## 0.1 Client Onboarding & Business Discovery (1–2h)

Run a structured intake session with the client. Cover all of the following:

### Business Fundamentals
- What does the business do, and who is the target customer? (ICP — Ideal Customer Profile)
- What are the top 3–5 products or services to prioritize?
- What is the unique value proposition vs. competitors?
- What geographic markets do they serve? (local, regional, national, global)
- What is the average deal size / customer lifetime value?

### Current Digital Presence
- Domain age and existing traffic (pull from GSC/GA4 if available)
- What CMS/platform is the site built on? (WordPress, Webflow, Shopify, custom)
- Are there existing pages? How many indexed? Run: `site:domain.com` in Google
- Current top-ranking keywords (export from GSC)
- Previous SEO work: what's been done before? Any penalties?

### Goals & Success Metrics
- What does success look like in 3 months? 6 months? 12 months?
- Primary KPIs: organic traffic, keyword rankings, leads from organic, revenue from organic
- Secondary KPIs: click-through rate, bounce rate, time on page, pages per session
- Reporting cadence: weekly updates, monthly reports, or quarterly reviews?

### Budget & Resources
- Monthly SEO retainer or project budget
- Is there an in-house dev/designer to implement technical changes?
- Does the client have content writers, or is Growthmak producing all content?
- Are there any brand voice guidelines or a style guide?

**Deliverable**: Discovery Document (use `docx` skill to create a formatted .docx)

---

## 0.2 Competitor Intelligence Research (2–3h)

Identify 3–5 direct competitors (same products/services, same geography) and 2–3 aspirational
competitors (industry leaders worth benchmarking against).

### Competitor Analysis Matrix

For each competitor, capture:

| Metric | Tool |
|--------|------|
| Estimated monthly organic traffic | Ahrefs / SEMrush |
| Domain Rating / Domain Authority | Ahrefs / Moz |
| Number of ranking keywords | Ahrefs / SEMrush |
| Top-performing pages | Ahrefs "Top Pages" |
| Content strategy (blog frequency, topics) | Manual review |
| Backlink profile (volume, quality, anchors) | Ahrefs / Majestic |
| Social proof (reviews, testimonials) | Manual review |
| Technical signals (speed, mobile, schema) | PageSpeed Insights |

### Content Gap Identification
Use Ahrefs "Content Gap" or SEMrush "Keyword Gap" to find:
- Keywords competitors rank for that the client does NOT
- Topics competitors cover that the client has no content for
- SERP features (featured snippets, PAA boxes) competitors own

### SERP Landscape Analysis
For 10–15 of the client's target keywords, manually review Google SERPs:
- What content types rank? (long-form articles, product pages, listicles, videos)
- What SERP features appear? (featured snippets, local pack, image pack, PAA)
- How authoritative are current ranking pages? Can we realistically compete?
- What is the average word count of top-ranking pages?

**Deliverable**: Competitor Matrix spreadsheet (use `xlsx` skill) with traffic, DR, keyword counts,
content gaps, and strategic notes.

---

## 0.3 Baseline Technical Audit (1–2h) [For Existing Sites Only]

Skip this for brand-new sites — proceed to Phase 2 instead.

### Crawl Audit (Screaming Frog or Ahrefs Audit)
- Total pages indexed vs. crawled
- 4xx errors (broken pages)
- 3xx redirects (redirect chains, loops)
- Missing or duplicate title tags
- Missing or duplicate meta descriptions
- Missing H1 tags, duplicate H1s
- Pages with thin content (<300 words)
- Images without alt text

### Core Web Vitals Baseline
Run Google PageSpeed Insights on key pages (homepage, top product/service pages, blog):
- Largest Contentful Paint (LCP) — target: <2.5s
- First Input Delay / Interaction to Next Paint (INP) — target: <200ms
- Cumulative Layout Shift (CLS) — target: <0.1

### Indexation & Coverage Audit
- Check Google Search Console Coverage report
- Identify excluded pages (noindex, soft 404, crawl anomaly)
- Verify XML sitemap is submitted and up to date
- Check robots.txt for unintentional blocks

### Current Performance Baseline
Pull 12 months of data from GSC:
- Total clicks, impressions, CTR, average position
- Top 20 ranking keywords and their positions
- Pages with declining rankings (opportunities for quick wins)
- Pages with high impressions but low CTR (title/meta optimization opportunities)

**Deliverable**: Baseline Audit Report with issues categorized as P0 (critical), P1 (high), P2 (medium)

---

## 0.4 GEO / Local Market Analysis (30min–1h)

Even for non-local businesses, understanding the geographic landscape shapes keyword strategy.

### For Local/Regional Businesses
- Define the primary service area (city, county, radius in km/miles)
- Identify key local competitors — search "[service] + [city]" in Google
- Review Google Maps / Local Pack results for target service keywords
- Check if Google Business Profile exists and is claimed
- Audit local citation consistency (NAP: Name, Address, Phone across directories)

### For National/Global Businesses
- Which regions drive the most current organic traffic? (GA4 → Audience → Geo)
- Are there regional language/dialect considerations?
- Which markets have the most untapped search demand?

### AI Search Landscape
- Search the client's key topics in ChatGPT, Perplexity, and Google AI Overviews
- Does the client appear in any AI-generated answers?
- Which competitors ARE mentioned in AI answers?
- What sources do AI engines cite? (potential backlink/citation targets)

---

## 0.5 Strategy & Roadmap Creation (1h)

Based on discovery, create a 90-day SEO roadmap:

### Roadmap Structure
**Month 1 (Foundation)**
- Complete technical audit and fixes (Phase 2)
- Finalize keyword research and topic clusters (Phase 1)
- Set up tracking and dashboards (Phase 6)

**Month 2 (Content & On-Page)**
- Launch pillar pages and priority cluster content (Phase 3)
- On-page optimization of existing high-potential pages (Phase 3)
- Begin initial citation/link building (Phase 4)

**Month 3 (Authority & GEO)**
- Scale content production
- Active link building outreach (Phase 4)
- GEO optimization implementation (Phase 5)
- First performance review and strategy refinement (Phase 6)

### KPI Framework
Define and document these metrics before work begins:

| KPI | Baseline | 3-Month Target | 6-Month Target |
|-----|----------|----------------|----------------|
| Monthly organic sessions | [baseline] | +20% | +50% |
| Keywords in top 10 | [baseline] | +15 | +40 |
| Keywords in top 3 | [baseline] | +5 | +20 |
| Organic leads/month | [baseline] | +10% | +30% |
| Domain Rating | [baseline] | +2–3 DR | +5–8 DR |

**Deliverable**: 90-Day SEO Roadmap document + KPI tracking spreadsheet

---

## Phase 0 Completion Checklist

- [ ] Discovery document completed and client-approved
- [ ] 3–5 competitors identified and analyzed in competitor matrix
- [ ] Baseline technical audit completed (existing sites) or skipped (new sites)
- [ ] GEO/local landscape reviewed
- [ ] 90-day roadmap drafted and agreed with client
- [ ] KPI baseline documented
- [ ] All tools connected: GSC, GA4, rank tracker, Ahrefs/SEMrush

**→ Proceed to Phase 1: Keyword Research & Topic Architecture**
