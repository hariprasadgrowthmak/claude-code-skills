# Phase 4: Off-Page Authority & Link Building

**Estimated time: 8–12 hours (initial) + ongoing**
**Output: Link Building Outreach Plan, Citation Audit, Backlink Profile Report**

Off-page SEO is about building the reputation of your site in the eyes of Google. Links from
credible, relevant websites remain one of the strongest ranking signals. The goal is quality
over quantity — 5 links from authoritative industry publications beat 500 low-quality directory links.

**Important note on ethics**: Only use tactics that earn links genuinely. No PBNs (private blog networks),
no paid link schemes disguised as editorial, no spammy automated outreach. Google's spam algorithms
detect and penalize these. Every tactic in this phase is compliant with Google's guidelines.

---

## 4.1 Backlink Profile Audit (1h) [Existing Sites]

Before building new links, audit what already exists.

### Audit Process
1. Export all backlinks from Ahrefs or SEMrush
2. Analyze:
   - Total referring domains (not raw links — DR matters less than diversity)
   - Domain Rating (DR) / Domain Authority (DA) distribution
   - Link velocity (how fast are new links being earned?)
   - Anchor text distribution (over-optimized exact-match anchors = risk)
   - Toxic/spammy links (very low DR sites, foreign language spam, adult sites)

### Disavow File (if needed)
If the backlink profile has a significant number of toxic links (from a penalty, negative SEO, or
old black-hat campaigns):
1. Export toxic link list from Ahrefs/SEMrush
2. Create disavow file (domain-level, not individual URLs where possible):
   ```
   # Disavow file - [Domain] - [Date]
   domain:spam-site-one.com
   domain:spam-site-two.net
   ```
3. Submit via GSC → Legacy tools → Disavow Links
4. Only do this if Google has already penalized OR if the toxic link volume is very high

---

## 4.2 Content-Led Link Building (3–4h)

The most sustainable link building strategy: create content so valuable that other sites
naturally want to reference it.

### Linkable Asset Types

**Original Research & Data**
Commission surveys, analyze client data, or aggregate public data into a unique study.
"75% of SMBs don't have a mobile-optimized site" earns links from journalists and bloggers.

**Comprehensive Guides & Definitive Resources**
"The Complete Guide to [Topic]" pages attract links because they become the best resource to reference.
Must be genuinely better than what currently exists — not just longer.

**Free Tools & Calculators**
ROI calculators, cost estimators, audit tools. These earn hundreds of organic links over time.
SEO ROI calculator, content marketing budget planner, etc.

**Infographics & Visualizations**
Visual representation of complex data or processes. Include embed code to make sharing easy.
Submit to infographic directories and offer to publications as a visual resource.

**Industry Reports**
Annual state-of-[industry] reports with original data. Journalists cite these heavily.

### Outreach Process for Content Links
1. Create the linkable asset
2. Identify sites that have linked to similar content (Ahrefs: Content Explorer → search topic → filter by DR 40+)
3. Find the right contact (content editor, founder, managing editor) — use Hunter.io or LinkedIn
4. Personalized outreach email:
   - Reference their specific content
   - Explain why your resource adds value to their readers
   - Short, direct ask
   - No "Dear Webmaster" — personalization is essential
5. Follow up once (not multiple times) after 5–7 business days
6. Track in outreach CRM (Pitchbox, BuzzStream, or a simple spreadsheet)

---

## 4.3 Guest Post Strategy (2h)

Writing guest posts for relevant industry publications earns high-quality contextual backlinks.

### Target Publication Criteria
- DR 40+ (use Ahrefs to check)
- Genuinely relevant to the client's industry
- Real audience engagement (check their social, comments)
- Not a link farm or PBN (signs: excessive guest posts, no original authors, unrelated topics)
- Does NOT have "write for us" pages full of "sponsored post" labels (pay-to-play)

### Guest Post Outreach Process
1. Build a list of 30–50 target publications
2. Study their existing content — understand their audience and tone
3. Propose 2–3 specific article ideas that fit their editorial style
4. Once accepted, write a high-quality piece (treat it like content for the client's own site)
5. Include 1–2 natural contextual links back to relevant client pages
6. Author bio with 1 link to the client's homepage or a relevant page

### Guest Post Quality Control
- Only pitch relevant topics — no off-topic posts just for a link
- Content must be unique, not republished elsewhere
- Avoid over-optimized anchor text: use brand name or natural phrase, not exact-match keyword
- Aim for publications that display author name prominently (E-E-A-T benefit)

---

## 4.4 Broken Link Building (1h)

Find broken links on high-authority sites and suggest the client's content as a replacement.
This works because webmasters appreciate being notified of broken links.

### Process
1. Use Ahrefs: Content Explorer → search your topic → filter to relevant, high-DR sites
2. Run their pages through Broken Link Checker (Ahrefs "Site Audit" or browser extension)
3. Find broken outbound links pointing to content the client could replace
4. Create or point to existing relevant client content
5. Email the webmaster: "Hi [name], I noticed [specific page] has a broken link to [dead URL].
   We have a resource that covers this topic: [URL]. Thought it might be worth updating."

---

## 4.5 Resource Page & Link Roundup Outreach (1h)

Many sites maintain "resource pages" or "useful links" pages linking to helpful content in their industry.

### Finding Resource Pages
Google search operators:
- `[industry keyword] + "resources"` or `"useful links"` or `"recommended resources"`
- `[industry keyword] + inurl:resources`
- `[industry keyword] + "further reading"`

### Outreach
Simple and direct: "Hi [name], I maintain [client site] which [brief description of value].
I think it would be a great addition to your [specific page]. Happy to share a brief description
if helpful."

---

## 4.6 Citation Building & NAP Consistency (2h)

**Critical for local/GEO-focused SEO.** Citations are mentions of the business Name, Address,
and Phone number (NAP) across the web.

### Why Citations Matter
- Google uses citations to verify business legitimacy and location
- Local pack rankings depend heavily on citation volume and consistency
- Inconsistent NAP confuses Google and weakens local signals

### NAP Consistency Audit
Check that the business name, address, and phone number are EXACTLY identical across:
- Google Business Profile
- Website (footer, Contact page)
- All directory listings

Even minor inconsistencies hurt: "St." vs "Street", "+44" vs "0044", suite numbers formatting.

### Tier 1 Citations (Must-Have)
Submit to all of these:
- Google Business Profile (most important)
- Bing Places
- Apple Maps Connect
- Yelp
- Facebook Business Page
- LinkedIn Company Page
- Companies House / BBB (depending on country)

### Tier 2 Citations (Industry-Relevant)
Find and submit to:
- Industry-specific directories (e.g., Houzz for home services, Avvo for lawyers, Zocdoc for doctors)
- Local chamber of commerce directory
- Local newspaper business directory
- City/region business directories

### Citation Building Tools
- BrightLocal: audit + build citations across 1,400+ sites
- Whitespark: manual citation building service
- Moz Local: citation management and consistency monitoring

### Monitoring Ongoing
Set up Google Alerts for the business name to catch new mentions.
Monthly: check BrightLocal/Whitespark for new citation inconsistencies.

---

## 4.7 Digital PR & Brand Mentions (1h, Ongoing)

Digital PR earns links from news sites, industry publications, and high-authority media.

### Tactics

**HARO / Qwoted / SourceBottle**
Journalists post requests for expert sources. Respond with expert commentary and earn
links from DA 70+ news sites (Forbes, Inc., trade publications).
- Sign up for HARO (Help a Reporter Out) and Qwoted
- Respond to 5–10 relevant queries per week
- Be specific, quotable, and responsive (journalists need quick answers)

**Proactive PR Pitches**
- Pitch original data/research to relevant journalists
- Identify journalists who cover your industry (Twitter/X, journalist databases)
- Build relationships before you need a link

**Unlinked Brand Mentions**
- Set up Google Alerts or use Ahrefs "Mentions" for the brand name
- When someone mentions the brand without linking, reach out and ask for a link
- Often a quick win — the person already likes the brand enough to mention it

---

## 4.8 Backlink Monitoring (Ongoing)

### Monthly Backlink Health Check
- New links earned (celebrate and record)
- Lost links (why? Page removed? Competitor outranked you?)
- Toxic new links (disavow if penalty risk is high)
- Competitor new links (identify opportunities from the same sources)

### Link Velocity
Monitor that link growth is:
- Steady and increasing over time
- Not artificially spiking (could trigger algorithmic review)
- Coming from diverse referring domains (not 90% from one site)

---

## Phase 4 Completion Checklist

- [ ] Backlink profile audited (existing sites)
- [ ] Disavow file created and submitted if toxic links present
- [ ] Linkable asset created (research, guide, tool, or infographic)
- [ ] 30–50 guest post targets identified and outreach started
- [ ] Resource page outreach: 20+ targets contacted
- [ ] Broken link building: 10+ opportunities identified
- [ ] Tier 1 citations: all submitted and consistent
- [ ] Tier 2 citations: 20+ industry/local directories submitted
- [ ] HARO/Qwoted account created, responding to relevant queries weekly
- [ ] Brand mention monitoring set up (Google Alerts + Ahrefs)
- [ ] Monthly backlink monitoring process documented

**→ Proceed to Phase 5: GEO & AI Search Optimization**
