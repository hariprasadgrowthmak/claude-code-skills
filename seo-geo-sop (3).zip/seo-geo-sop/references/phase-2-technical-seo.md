# Phase 2: Technical SEO Foundation

**Estimated time: 14–18 hours**
**Output: Technical Audit Report (P0/P1/P2), Redirect Map, Schema Plan, Implementation Checklist**

Technical SEO is the foundation every other phase depends on. A site with brilliant content and
great backlinks will underperform if Google can't efficiently crawl, understand, and index it.
Fix technical issues before investing heavily in content or links.

---

## 2.1 Site Architecture Planning (1h) [New Sites Only]

For new websites, plan the URL structure before building anything.

### URL Architecture Principles
- Flat hierarchy preferred: ideally 3 clicks from homepage to any page
- Logical, keyword-rich URL slugs: `/services/seo-audit/` not `/page?id=42`
- Consistent structure: all blog posts at `/blog/[slug]/`, all services at `/services/[slug]/`
- No unnecessary parameters in URLs for core pages

### Recommended Structure Examples
```
Homepage: domain.com/
Services: domain.com/services/
  Service 1: domain.com/services/seo/
  Service 2: domain.com/services/ppc/
Blog: domain.com/blog/
  Post: domain.com/blog/post-slug/
About: domain.com/about/
Contact: domain.com/contact/
```

### Internal Link Architecture
Plan silo structure — topically related pages should be tightly interlinked:
- Homepage → Pillar pages
- Pillar pages → Cluster pages
- Cluster pages → Support pages + back to pillar

---

## 2.2 Robots.txt Configuration (2h)

### What Robots.txt Does
Tells search engine crawlers which parts of the site to access or ignore.
Misconfigured robots.txt is a critical error — it can accidentally block the entire site.

### Best Practice Template
```
User-agent: *
Disallow: /admin/
Disallow: /wp-admin/
Disallow: /cart/
Disallow: /checkout/
Disallow: /account/
Disallow: /thank-you/
Disallow: /?s=           # Block search result pages (WordPress)
Allow: /wp-admin/admin-ajax.php  # Allow AJAX if needed

Sitemap: https://domain.com/sitemap.xml
```

### What NOT to Block
- Never block CSS and JavaScript files (Google needs these to render pages)
- Never accidentally add `Disallow: /` (blocks everything)
- Don't block pages you want indexed (obvious but commonly done wrong)

### Validation
Test at: `domain.com/robots.txt` — confirm it loads
Test specific URLs: Google Search Console → URL Inspection → test blocked URLs

---

## 2.3 XML Sitemap Creation (1h)

### What Should Be in the Sitemap
- All indexable, canonical pages
- Last modified dates
- Priority hints (optional, often ignored by Google)

### What Should NOT Be in the Sitemap
- Noindex pages
- Paginated pages (except canonical)
- Parameter URLs (filtered product pages, search results)
- Redirect URLs (301/302)
- 404 pages

### Sitemap Types for Large Sites
- `sitemap_index.xml`: Master index pointing to sub-sitemaps
- `sitemap_pages.xml`: Static pages
- `sitemap_posts.xml`: Blog/articles
- `sitemap_products.xml`: E-commerce products

### Submission
1. Submit to Google Search Console: Settings → Sitemaps → Submit
2. Submit to Bing Webmaster Tools
3. Reference in robots.txt: `Sitemap: https://domain.com/sitemap.xml`
4. Monitor: check for sitemap errors in GSC weekly

---

## 2.4 Canonical Tag Implementation (2h)

### When Canonical Tags Are Needed
- Duplicate content from URL parameters (e.g., `?sort=price`, `?color=red`)
- Paginated content (use canonical to point to page 1 or a "view all" page)
- HTTPS vs HTTP versions (always canonical to HTTPS)
- WWW vs non-WWW
- Trailing slash vs no trailing slash: `/page/` vs `/page`

### Implementation
```html
<link rel="canonical" href="https://domain.com/the-correct-page-url/" />
```

### Common Canonical Mistakes
- Self-referencing canonicals missing (every page should have one, including the canonical itself)
- Canonicals pointing to redirected URLs
- Multiple canonical tags on one page
- Canonicals in body instead of `<head>`

### Audit Process
Crawl with Screaming Frog → "Canonicals" tab → check for:
- Missing canonicals
- Non-indexable canonicals
- Canonical chains
- Conflicting canonicals (canonical tag says X, but hreflang/sitemap says Y)

---

## 2.5 Schema Markup Deployment (2h)

Schema markup helps Google understand content context and enables rich results in SERPs.

### Priority Schema Types by Page

| Page Type | Schema Type | Rich Result Benefit |
|-----------|------------|-------------------|
| Homepage | Organization, WebSite, SearchAction | Sitelinks searchbox |
| Service pages | Service, LocalBusiness | Service structured data |
| Blog posts | Article, BlogPosting, BreadcrumbList | Article rich result |
| FAQ sections | FAQPage | FAQ rich snippet (expandable in SERP) |
| How-to content | HowTo | Step-by-step rich result |
| Reviews | AggregateRating | Star ratings in SERP |
| Products | Product, Offer | Price, availability in SERP |
| People/Author | Person | E-E-A-T author signals |
| Events | Event | Event rich result |

### Implementation Methods
1. JSON-LD (recommended — easiest, no HTML touching needed):
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Business Name",
  "url": "https://domain.com",
  "telephone": "+1-555-000-0000",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "123 Main St",
    "addressLocality": "City",
    "addressRegion": "State",
    "postalCode": "12345",
    "addressCountry": "US"
  }
}
</script>
```

### Validation
- Google Rich Results Test: `search.google.com/test/rich-results`
- Schema.org validator
- Monitor GSC → Enhancements tab for schema errors/warnings

---

## 2.6 Core Web Vitals Optimization (2h)

Core Web Vitals are ranking factors. They measure real-world user experience.

### The Three Metrics

**Largest Contentful Paint (LCP)** — loading performance
- Target: < 2.5 seconds
- Fix: Optimize hero images, use CDN, improve server response time, preload key resources

**Interaction to Next Paint (INP)** — interactivity (replaced FID in 2024)
- Target: < 200ms
- Fix: Reduce JavaScript execution time, split code, defer non-critical JS

**Cumulative Layout Shift (CLS)** — visual stability
- Target: < 0.1
- Fix: Set explicit width/height on all images and embeds, avoid inserting content above the fold

### Quick Wins for LCP
- Serve images in WebP/AVIF format
- Add `loading="lazy"` to below-fold images
- Add `fetchpriority="high"` to the hero/LCP image
- Enable browser caching and compression (Gzip/Brotli)
- Use a CDN (Cloudflare, Fastly)
- Upgrade hosting if TTFB > 600ms

### Monitoring
- Google PageSpeed Insights (lab data — instant check)
- GSC → Core Web Vitals report (field data — real user data, 28-day window)
- CrUX Dashboard (Chrome User Experience Report)

---

## 2.7 Site Speed Optimization (2h)

Beyond Core Web Vitals, overall page speed affects crawl budget and user experience.

### Speed Optimization Checklist
- [ ] Images compressed (<200KB for most, <500KB for hero images)
- [ ] Images in WebP or AVIF format
- [ ] CSS/JS minified and combined where possible
- [ ] Render-blocking CSS/JS eliminated or deferred
- [ ] Server response time (TTFB) < 600ms
- [ ] Browser caching headers set (Cache-Control, ETag)
- [ ] CDN implemented for static assets
- [ ] Font loading optimized (`font-display: swap`)
- [ ] Third-party scripts (analytics, chat widgets) loaded asynchronously
- [ ] No excessive plugins (WordPress: audit and remove unused plugins)

### Tools
- Google PageSpeed Insights
- WebPageTest.org (more detailed waterfall)
- GTmetrix
- Lighthouse (in Chrome DevTools)

---

## 2.8 Mobile-First Implementation (2h)

Google indexes and ranks mobile versions of pages. Mobile UX is ranking-critical.

### Mobile Checklist
- [ ] Responsive design (viewport meta tag present)
- [ ] No horizontal scrolling on mobile
- [ ] Tap targets (buttons, links) ≥ 48px × 48px
- [ ] Font size ≥ 16px for body text (no zooming required to read)
- [ ] No intrusive pop-ups/interstitials on mobile (Google penalty risk)
- [ ] Mobile PageSpeed score ≥ 70
- [ ] Test on real devices, not just DevTools

### Testing
- Google Mobile-Friendly Test: `search.google.com/test/mobile-friendly`
- Chrome DevTools → Device Toggle
- BrowserStack for real device testing

---

## 2.9 HTTPS & Security (2h)

### HTTPS Implementation
- All pages must be served over HTTPS (HTTP → HTTPS is a minor ranking signal)
- SSL certificate: obtain from Let's Encrypt (free) or commercial provider
- Force HTTPS via server config or `.htaccess`
- Implement HSTS (HTTP Strict Transport Security) header

### Mixed Content Issues
After migrating to HTTPS, audit for mixed content (HTTP resources on HTTPS pages):
- Check browser console for mixed content warnings
- Use a crawl tool to find HTTP src attributes in HTML
- Update all internal links and resource URLs to HTTPS

### Security Headers (bonus signals)
```
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
Content-Security-Policy: [appropriate policy]
```

---

## 2.10 Crawlability & Indexability (1h)

Ensure Google can crawl every important page and index the right ones.

### Crawl Audit Process
1. Crawl site with Screaming Frog
2. Check for crawl errors in GSC → Coverage report
3. Identify orphan pages (no internal links pointing to them)
4. Check crawl depth (important pages should be reachable in ≤3 clicks from homepage)
5. Audit internal link anchor text (use descriptive, keyword-rich anchors)

### Indexability Audit
Pages that should be indexed but aren't:
- Check: `site:domain.com/page-url` in Google
- Check: GSC URL Inspection → "URL is not on Google"
- Common causes: noindex tag accidentally present, blocked in robots.txt, thin content, soft 404

Pages that shouldn't be indexed but are:
- Thank-you pages, admin pages, duplicate pages, parameter URLs
- Fix with: `<meta name="robots" content="noindex, nofollow">`

### Crawl Budget (for large sites: 10,000+ pages)
- Remove low-value URLs from indexation (thin/duplicate content)
- Ensure XML sitemap only contains high-value pages
- Fix redirect chains (each chain wastes crawl budget)
- Consider crawl rate settings in GSC for large sites

---

## 2.11 Redirect Management (1h)

### 301 Redirect Map
Required when:
- Migrating from HTTP to HTTPS
- Relaunching with new URL structure
- Consolidating old blog posts or duplicate pages
- Changing URL slugs

### Redirect Rules
- Use 301 (permanent) for all SEO-relevant redirects
- Never use 302 (temporary) unless it truly is temporary
- Avoid redirect chains (A → B → C): fix to A → C directly
- Avoid redirect loops (A → B → A)
- Every old URL should redirect to the most contextually relevant new URL
  (not just "redirect everything to homepage")

### Post-Migration Audit
After implementing redirects:
1. Crawl old URL list — confirm all return 301 (not 200 or 404)
2. Check GSC for 404 errors spiking (missed redirects)
3. Update internal links to point directly to new URLs (avoid relying on redirects long-term)

---

## 2.12 AI Integration for Technical Bug Fixing (2h)

Use AI tools to accelerate technical fixes:
- Feed crawl report into Claude/ChatGPT to batch-generate schema markup
- Use AI to write `.htaccess` redirect rules from spreadsheet of old→new URL pairs
- Automate meta tag generation for large sites using AI + spreadsheet
- Use AI to audit and improve existing page titles/descriptions at scale

---

## Phase 2 Completion Checklist

- [ ] Site architecture planned (new sites) or audited (existing sites)
- [ ] Robots.txt configured and validated
- [ ] XML sitemap created, submitted, and error-free
- [ ] Canonical tags implemented on all key pages
- [ ] Schema markup deployed: Organization, LocalBusiness, Article, FAQ, HowTo as relevant
- [ ] Core Web Vitals: LCP < 2.5s, INP < 200ms, CLS < 0.1
- [ ] Site speed optimized: mobile score ≥ 70, desktop ≥ 80
- [ ] Mobile-friendly confirmed
- [ ] HTTPS fully implemented, no mixed content
- [ ] Crawl errors resolved
- [ ] All important pages indexable
- [ ] Redirect map created and implemented
- [ ] Technical audit report delivered to client with P0/P1/P2 classification

**→ Proceed to Phase 3: On-Page SEO & Content Strategy**
