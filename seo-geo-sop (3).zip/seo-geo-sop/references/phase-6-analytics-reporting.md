# Phase 6: Analytics, Monitoring & Reporting

**Estimated time: 4–6h setup, 3–4h/month ongoing**
**Output: KPI Dashboard, Monthly Reports, Quarterly Strategy Reviews**

Analytics closes the loop. Without measurement, SEO is guesswork. This phase sets up the
infrastructure to track what's working, identify what isn't, and make data-driven decisions
that compound results over time.

---

## 6.1 Analytics & Tracking Setup (2h)

### Google Analytics 4 (GA4)
If not already installed:
1. Create GA4 property in Google Analytics
2. Install the tracking code via Google Tag Manager (recommended) or directly in site `<head>`
3. Verify data is flowing: GA4 → Reports → Realtime (visit the site and check)

**Key GA4 Configurations**:
- Enable Enhanced Measurement (scroll depth, outbound clicks, file downloads, video engagement)
- Set up Conversions: form submissions, phone click-to-call, contact page visits, chat initiations
- Link GA4 to Google Search Console (enables combined organic + behavior data)
- Link GA4 to Google Ads (if applicable)
- Set up Audiences for remarketing (organic visitors, high-intent visitors)

### Google Search Console (GSC)
- Verify site ownership (HTML tag, DNS, or Google Analytics method)
- Submit XML sitemap
- Set preferred domain (www vs non-www)
- Connect to GA4

**GSC Reports to Monitor Weekly**:
- Performance → Queries (trending keywords)
- Coverage → report (indexing errors)
- Core Web Vitals (performance issues)
- Manual Actions (Google penalties — check monthly)
- Links (new and lost backlinks)

### Rank Tracking Setup
Choose one: Ahrefs Rank Tracker, SEMrush Position Tracking, AccuRanker, or SERPWatcher.

Configure:
- All Priority 1 and Priority 2 keywords from Phase 1
- Target location (country + city for local clients)
- Competitors to track alongside (3–5)
- Reporting frequency: daily for competitive keywords, weekly for others

### Google Tag Manager (GTM)
GTM is the preferred method for deploying tracking tags without touching site code.
Install GTM first, then deploy GA4, conversion tracking, and any other tags through GTM.

---

## 6.2 KPI Dashboard Setup (1h)

### Recommended Dashboard Tools
- **Looker Studio (free)**: Connect GA4 + GSC + Ahrefs/SEMrush for a single-source dashboard
- **Ahrefs/SEMrush built-in**: Good for SEO-specific metrics
- **Google Sheets**: For manual monthly KPI tracking with automated GSC data pull

### Core KPI Dashboard Metrics

**Traffic Metrics**:
- Monthly organic sessions (vs previous month, vs same month last year)
- Organic users
- New vs returning users from organic
- Top organic landing pages by sessions

**Ranking Metrics**:
- Average position (GSC)
- Keywords in positions 1–3
- Keywords in positions 4–10
- Keywords in positions 11–20 (quick-win opportunities)
- Total ranking keywords (from rank tracker)

**Engagement Metrics**:
- Bounce rate (or Engagement Rate in GA4)
- Average session duration
- Pages per session
- Core Web Vitals scores

**Conversion Metrics**:
- Organic conversions (form fills, calls, purchases)
- Organic conversion rate
- Organic revenue (e-commerce)
- Organic leads cost per acquisition (vs paid)

**Authority Metrics**:
- Domain Rating (Ahrefs) or Domain Authority (Moz)
- Total referring domains
- New referring domains this month
- Lost referring domains this month

---

## 6.3 Performance Monitoring Schedule (Ongoing)

### Weekly Checks (30 minutes)
- GSC Performance: any unusual drops in clicks/impressions?
- GSC Coverage: new indexing errors?
- Rank tracker: significant ranking changes (gain or loss >5 positions)?
- Core Web Vitals: any new issues?
- New backlinks earned this week

### Monthly Analysis (2–3 hours)
- Pull monthly KPI data from GA4 + GSC + rank tracker
- Compare to previous month AND same month last year
- Identify:
  - Top-performing new content (opportunities to build on)
  - Declining pages (need refresh or technical investigation)
  - Keyword ranking changes (wins to celebrate, drops to investigate)
  - New backlinks earned and quality assessment
  - Content gaps revealed by high-impression/low-click queries in GSC

### Quarterly Strategy Review (2–3 hours)
- Full KPI review against 90-day targets from Phase 0
- Competitor rankings check: have competitors gained/lost ground?
- Keyword opportunity refresh: any new keywords worth targeting?
- Technical audit refresh: run a quick crawl to catch new technical issues
- Strategy adaptation: what should the next 90 days focus on?

---

## 6.4 Data Analysis & Insight Generation (Ongoing)

### GSC Query Mining (Monthly)
Export all GSC queries and look for:

**Keyword cannibalization signals**:
Same keyword driving traffic to 2+ different pages → consolidate or differentiate them

**Content opportunity signals**:
- Queries with 100+ impressions but <5 clicks → fix CTR with better title/meta
- Queries with high position but no dedicated page → create the page
- Questions appearing in queries → add FAQ content

**Featured snippet opportunities**:
Queries where you're in positions 2–5 and a featured snippet is present → optimize content
for the snippet format (see Phase 3)

### Content Performance Matrix
Quarterly, categorize all content into:

| Category | Definition | Action |
|----------|-----------|--------|
| Stars | High traffic + High conversions | Scale: create more similar content |
| Workhorses | High traffic + Low conversions | Optimize CTA and conversion path |
| Diamonds | Low traffic + High conversions | Promote: build more links, improve reach |
| Dead weight | Low traffic + Low conversions | Refresh or consolidate into stronger pages |

---

## 6.5 Monthly Client Reporting

Use the `growthmak-reporting` skill to create the monthly client report.

### Report Structure
1. **Executive Summary**: 3–5 bullet points of key highlights and wins
2. **Traffic Overview**: Organic sessions, users, trends
3. **Keyword Rankings**: Movements, new rankings, losses
4. **Content Performance**: Top pages, new content results
5. **Technical Health**: Any issues fixed or outstanding
6. **Link Building**: New links earned, DR/DA progress
7. **Conversions**: Leads/sales from organic
8. **GEO / AI Visibility**: Any improvements in AI search presence
9. **Month-Over-Month Comparison**: Key metrics vs last month
10. **Year-Over-Year Comparison**: Key metrics vs same month last year
11. **Next Month's Plan**: Priority actions for the coming month

### Reporting Tone (Growthmak Standard)
- Data first. No superlatives.
- "Organic sessions grew 12% month-over-month" not "Traffic exploded!"
- Acknowledge challenges openly: "Rankings for [keyword] declined — we're investigating"
- Always end with forward-looking actions

---

## 6.6 AI Integration for Analytics (Ongoing)

### AI-Assisted Data Analysis
- Export GSC/GA4 data and feed to Claude or ChatGPT for pattern identification:
  "Here is 12 months of GSC data. What patterns do you see? Which keywords show the most
  volatility? What content categories are trending up vs down?"

- Use AI to draft insight commentary for reports:
  "Based on this rank tracking data showing positions for [keyword] dropping from 4 to 12 over
  3 months, what might be the cause and what actions would you recommend?"

- Automate repetitive reporting tasks:
  "Here is this month's GA4 data in CSV format. Write the 'Traffic Overview' section of the
  monthly report using the Growthmak reporting tone."

---

## 6.7 Ongoing Optimization & Strategy Adaptation (Continuous)

SEO is never "done." Google's algorithm updates, competitor movements, and user behavior changes
require continuous adaptation.

### Monthly Adaptation Checklist
- [ ] Review Google algorithm update news (Search Engine Land, Search Engine Roundtable)
- [ ] Check if any recent updates affected client rankings (correlate update dates with rank changes)
- [ ] Review 5 competitor sites for new content strategies being deployed
- [ ] Re-prioritize content calendar based on new ranking opportunities
- [ ] Assess if new keywords should be added to rank tracker
- [ ] Review conversion path from organic — are there UX improvements needed?

### Content Decay Protocol
All content decays without maintenance. Establish a review cycle:
- Blog posts: review every 12 months minimum
- Service pages: review every 6 months
- High-traffic pages: review every 3 months
- If a page drops >3 positions over 60 days: trigger immediate review

### Algorithm Update Response
When a Google core update is announced:
1. Wait 2 weeks before acting (updates can take 2 weeks to fully roll out)
2. Assess impact: which pages gained/lost most?
3. Read Google's guidance on the specific update
4. Identify patterns in impacted pages (thin content? E-E-A-T issues? Technical issues?)
5. Create an action plan and implement within 30 days

---

## Phase 6 Completion Checklist

- [ ] GA4 installed, configured, conversions tracked
- [ ] GSC verified, sitemap submitted, linked to GA4
- [ ] Rank tracking configured for all Priority 1–2 keywords
- [ ] Looker Studio (or equivalent) dashboard live
- [ ] Weekly monitoring process documented and in calendar
- [ ] Monthly reporting template created using growthmak-reporting skill
- [ ] First monthly report delivered
- [ ] KPI targets established and tracked against baseline from Phase 0
- [ ] Quarterly review process scheduled
- [ ] AI-assisted analysis workflows set up
- [ ] Content decay review schedule in place

---

## Complete SOP Summary — Total Deliverables

| Phase | Key Deliverables |
|-------|-----------------|
| Phase 0 | Discovery doc, competitor matrix, 90-day roadmap, KPI baseline |
| Phase 1 | Master keyword spreadsheet, topic cluster map, content calendar |
| Phase 2 | Technical audit report, robots.txt, sitemap, schema, speed fixes |
| Phase 3 | Optimized pages, meta tags, content library, internal link audit |
| Phase 4 | Backlink profile report, outreach plan, citation audit |
| Phase 5 | GBP optimization, location pages, GEO content strategy, AI monitoring |
| Phase 6 | Analytics dashboard, monthly reports, ongoing optimization schedule |

**Total estimated initial engagement: 60–90 hours across 30–60 days.**
**Ongoing monthly commitment: 15–25 hours per month.**
