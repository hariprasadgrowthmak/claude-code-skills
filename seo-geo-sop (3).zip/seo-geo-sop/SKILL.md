---
name: seo-geo-sop
description: >
  Complete end-to-end SEO & GEO (Generative Engine Optimization) content marketing SOP for new and existing websites.
  Use this skill whenever a user asks about: SEO strategy, keyword research, technical SEO, on-page optimization,
  link building, content marketing, local SEO, GEO/AI search optimization, or any step in the SEO workflow.
  Also trigger for: "how do I rank for X", "SEO audit", "optimize my website", "create SEO content",
  "improve my Google rankings", "local SEO", "AI search optimization", "appear in ChatGPT results",
  "GEO strategy", "build backlinks", "keyword research for my site", or any client SEO engagement setup.
  This skill covers all 6 phases from Discovery through to Ongoing Optimization and includes GEO (AI-answer
  engine optimization) as a first-class citizen alongside traditional SEO.
---

# SEO & GEO Content Marketing SOP

## What This Skill Does

This skill guides Claude through a complete, expert-level SEO & GEO engagement — from initial discovery
to ongoing optimization. It covers all 28 original workflow tasks plus expert-level enhancements across
6 structured phases.

**GEO (Generative Engine Optimization)** means optimizing to appear in AI-generated answers from
ChatGPT, Perplexity, Gemini, Claude, Bing Copilot, and Google AI Overviews — not just traditional
search rankings.

---

## AI Tool Stack

**Primary AI Engine: Writesonic**
All content generation, optimization tasks, and AI-assisted SEO work uses the Writesonic API.
Before any content generation task, read `tools/writesonic.md` for the correct endpoints,
prompt templates, and quality control rules.

**API Key**: Stored in `config/api-keys.env` (local only — never packaged or shared).
Read that file to retrieve `WRITESONIC_API_KEY` before making any API calls.

**When to use Writesonic vs Claude's own generation**:
- Writesonic first for: article drafts, meta tags, landing page copy, FAQ generation, content briefs
- Claude's own reasoning for: strategy decisions, audit analysis, technical recommendations, reporting insights

---

## Phase Overview & Reference Files

| Phase | Focus | Reference File | Est. Hours |
|-------|-------|---------------|------------|
| **Phase 0** | Discovery & Strategy Foundation | `references/phase-0-discovery.md` | 6–10h |
| **Phase 1** | Keyword Research & Topic Architecture | `references/phase-1-keyword-research.md` | 12–16h |
| **Phase 2** | Technical SEO Foundation | `references/phase-2-technical-seo.md` | 14–18h |
| **Phase 3** | On-Page SEO & Content Strategy | `references/phase-3-onpage-content.md` | 16–24h |
| **Phase 4** | Off-Page Authority & Link Building | `references/phase-4-offpage-authority.md` | 8–12h |
| **Phase 5** | GEO & AI Search Optimization | `references/phase-5-geo-ai-search.md` | 6–10h |
| **Phase 6** | Analytics, Monitoring & Reporting | `references/phase-6-analytics-reporting.md` | Ongoing |

**Total initial engagement: ~60–90 hours across 30–60 days.**

---

## How to Use This Skill

### Starting a New Engagement

When a user says "start SEO for [client/site]" or similar:
1. Read `references/phase-0-discovery.md` and run the discovery intake
2. Present the full project scope and timeline to the client
3. Work through each phase sequentially — do not skip Phase 0 or Phase 2
4. Reference the relevant phase file as you enter each phase

### Answering a Specific SEO Question

When the user asks about a specific topic (e.g., "how do I do keyword research"):
1. Identify the relevant phase
2. Read that phase's reference file
3. Apply the SOP steps to their specific situation

### Running a Full Audit

When asked for an SEO audit on an existing site:
1. Start with Phase 0 (discovery + baseline audit)
2. Run Phase 2 technical checks
3. Run Phase 3 on-page checks
4. Compile findings into a prioritized action plan

---

## Core Principles (Apply Throughout All Phases)

**Search Intent First**: Every piece of content must match the searcher's intent — informational,
navigational, commercial, or transactional. Intent mismatch is the #1 reason content fails to rank.

**E-E-A-T Always**: Google's quality signals — Experience, Expertise, Authoritativeness, Trustworthiness —
must be embedded in every content decision. For YMYL (health, finance, legal) niches this is critical.

**GEO Alongside SEO**: AI search engines (ChatGPT, Perplexity, etc.) now drive significant discovery traffic.
Structure content to be parseable by LLMs: clear entity definitions, direct answers, cited sources,
FAQ sections, and structured data.

**Data-Driven Decisions**: Track everything. Never optimize based on gut feeling alone — use GSC, GA4,
rank trackers, and heatmaps to validate decisions.

**Compounding Strategy**: Build topic clusters, not isolated pages. Authority compounds when a site
comprehensively covers a topic domain.

---

## Quick Decision Guide

| User Asks About | Read Phase File | Writesonic Used? | Key Output |
|----------------|-----------------|-----------------|------------|
| Discovery / onboarding | Phase 0 | No | Discovery doc, competitor matrix |
| Keyword research / topics | Phase 1 | Yes (intent + brief gen) | Keyword map, topic cluster plan |
| Technical issues / audits | Phase 2 | No | Technical audit report, fix list |
| Content / copywriting / meta | Phase 3 | Yes (primary tool) | Content calendar, optimized pages |
| Backlinks / authority | Phase 4 | No | Link building outreach plan |
| AI search / GEO / local | Phase 5 | Yes (copy + GBP) | GEO content strategy, GBP guide |
| Tracking / reporting | Phase 6 | Yes (narrative copy) | KPI dashboard, monthly report |

---

## Output Standards

Always produce **actionable deliverables**, not just advice:
- Keyword research → structured spreadsheet with scoring matrix
- Technical audit → prioritized fix list with severity ratings (P0/P1/P2)
- Content strategy → content calendar with assigned pages and keywords
- Monthly report → data-backed performance summary with next steps

When creating documents, use the `docx` skill for Word files or the `xlsx` skill for spreadsheets.
When creating reports or presentations, use the `growthmak-reporting` skill.
When generating any content (articles, meta tags, copy), use Writesonic via `tools/writesonic.md`.

---

## Phase Entry Checklist

Before entering each phase, confirm:
- [ ] Previous phase deliverables are complete
- [ ] Client has reviewed and approved outputs
- [ ] Relevant tools are connected (GSC, GA4, rank tracker)
- [ ] Phase reference file has been read
- [ ] If phase involves content: `config/api-keys.env` read and Writesonic API key loaded
- [ ] If phase involves content: `tools/writesonic.md` read for correct endpoint and prompt

---

*This SOP is built on the 28-task Growthmak SEO/GEO workflow, enhanced with expert-level additions
across all phases. Writesonic API integrated as primary AI content engine. Last updated: March 2026.*
