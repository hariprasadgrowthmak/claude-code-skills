---
name: social-media-creatives
description: >
  Full-stack social media creative generation skill for growth/performance marketers. Use this skill whenever a user wants to generate, plan, or batch-produce social media creatives — including static images, carousels, and video scripts/storyboards — for organic or paid channels (Meta, TikTok, Instagram, LinkedIn, YouTube Shorts, X). Trigger this skill for any request involving: "create creatives", "make ad creatives", "generate social media content", "write ad copy", "create carousel", "write video script", "create storyboard", "batch creatives", "creative variations", "ad angles", "creative strategy", "organic content", "paid social creatives", "UGC script", "hook writing", or any mention of producing visual/copy assets for social platforms. Also trigger when users mention a product, brand, or offer and want to promote it — even if they don't say "creatives" explicitly. Always use this skill — do not attempt creative generation at scale without it.
---

# Social Media Creatives Generation Skill

A scalable creative production system for growth marketers. Produces full creative decks — static, carousel, and video — across organic and paid formats, with differentiated angles and copy variations ready for A/B testing.

---

## Phase Overview

```
PHASE 1 → INTAKE       (collect brand context)
PHASE 2 → RESEARCH     (optional competitor scan)
PHASE 3 → STRATEGY     (angles + plan) → ⛳ APPROVAL GATE
PHASE 4 → GENERATE     (full batch output)
PHASE 5 → PACKAGE      (structured creative deck)
```

Always follow phases in order. Never skip the approval gate before generation.

---

## PHASE 1: INTAKE

### Goal
Gather enough context to produce differentiated, on-brand creatives. Ask only for what's missing — if the user already provided info, don't re-ask it.

### Required Inputs
Collect these before proceeding. Ask in a single structured message, not one-by-one:

```
1. BRAND/PRODUCT
   - What is the product or service?
   - What problem does it solve?
   - Who is the target audience? (demographics, psychographics, pain points)

2. OFFER/CAMPAIGN
   - What's the main offer or CTA? (e.g., free trial, 30% off, book a call)
   - Is there a specific campaign goal? (awareness, leads, purchases, installs)
   - Any promotions, deadlines, or urgency triggers?

3. BRAND VOICE
   - 3 words that describe the brand tone (e.g., bold, playful, premium)
   - Any phrases, terms, or styles to avoid?

4. PLATFORMS
   - Which platforms? (IG, FB, TikTok, LinkedIn, YT Shorts, X — or "all")

5. CONTEXT (optional but helpful)
   - Competitor brands or creative styles they admire or want to differentiate from
   - Any existing creatives that worked or flopped?
   - Any visual direction? (colors, style, real people vs graphic)
```

### Adaptive Logic
- If user provides a URL → use web_fetch to pull product/brand context automatically
- If user says "figure it out" or gives minimal info → make smart assumptions, state them clearly, proceed
- If industry is niche → note it, apply industry-specific angle selection in Phase 3

---

## PHASE 2: RESEARCH (Optional)

**When to run:** Default ON for paid campaigns. Skip only if user says "skip research" or brief is very detailed.

### Research Steps
1. **Competitor creative scan** — Search for "[brand/product category] ads" or "[competitor] social media creatives" using web search
2. **Market positioning** — Identify 2-3 dominant creative approaches in the space
3. **Gap analysis** — What angles are competitors NOT using? That's your differentiation opportunity.

### Output
A short "Creative Landscape Summary" (3-5 bullets):
- Dominant creative patterns in the space
- Overused angles to avoid (or subvert)
- White space opportunities
- Relevant social proof signals or trends to leverage

Read: `references/creative-angles.md` for angle taxonomy to apply here.

---

## PHASE 3: STRATEGY

**This is the creative director phase.** Synthesize intake + research into a crisp creative strategy.

### Deliverables

#### A. Audience Segments (2-3 max)
For each segment define:
- Who they are (1 line)
- Primary pain point or desire
- Emotional state when they see the ad
- Best platform to reach them

#### B. Creative Angles (5-7 angles)
Select from `references/creative-angles.md`. For each angle:
- Angle name + type (rational / emotional / social)
- Core message in 1 sentence
- Best format fit (static / carousel / video)
- Organic vs Paid suitability

Read: `references/organic-vs-paid.md` to assign each angle correctly.

#### C. Platform + Format Matrix
Map angles to formats:

| Angle | Platform | Format | Organic/Paid | Priority |
|-------|----------|--------|--------------|----------|
| ...   | ...      | ...    | ...          | High/Med |

#### D. Production Plan
State clearly:
- Total variations to be generated (target: 10-15)
- Breakdown by format: X static, Y carousels, Z video scripts
- Which angles get multiple copy variations

### ⛳ APPROVAL GATE
**Stop here. Present the strategy to the user. Ask:**
> "Here's the creative strategy. Does this direction look right? Any angles to add, swap, or remove before I generate the full batch?"

Do not proceed to Phase 4 without explicit approval.

---

## PHASE 4: GENERATE

Generate all creatives in one structured output. Read relevant reference files as needed.

### Reference Files to Load
- `references/copywriting-frameworks.md` — for copy structure
- `references/platform-specs.md` — for character limits, dimensions, format rules
- `references/video-scripting.md` — for video outputs

### Output Structure Per Creative

Use this format for EVERY creative variation:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CREATIVE #[N] — [ANGLE NAME]
Format: [Static / Carousel / Video]
Platform: [Platform(s)]
Type: [Organic / Paid]
Audience Segment: [Segment name]
Framework: [e.g., PAS / Hook-Story-Offer / AIDA]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[FORMAT-SPECIFIC CONTENT — see below]

COPY ELEMENTS:
• Primary Text / Caption: [Full copy]
• Headline: [For paid / overlay]
• Description: [For paid ads]
• CTA: [Button text or closing line]
• Hashtags: [For organic — 5-10 relevant]

NOTES FOR DESIGNER/EDITOR:
• Visual direction: [What to show, style, mood]
• Text overlays: [What text appears on the visual]
• Brand elements: [Colors, logo placement]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Format-Specific Content Blocks

#### STATIC IMAGE
```
VISUAL CONCEPT:
• Hero element: [Main visual — product, person, graphic]
• Background/setting: [Scene or color]
• Mood: [e.g., aspirational, raw/real, clean minimal]
• Text on image: [Headline or hook overlay]
• Layout style: [e.g., product-forward, lifestyle, text-heavy]
```

#### CAROUSEL (read: templates/carousel-brief.md)
```
SLIDE BREAKDOWN:
Slide 1 (Hook): [Visual + headline — must stop scroll]
Slide 2: [Supporting point or story beat]
Slide 3: [Supporting point or story beat]
Slide 4: [Supporting point or story beat]
Slide 5 (CTA): [Final slide — offer + action]
[Add slides as needed, max 10]

SWIPE PROMPT: [Text encouraging swipe — on slide 1 or 2]
```

#### VIDEO / REEL / SHORT (read: references/video-scripting.md)
```
DURATION: [Recommended seconds]
STYLE: [UGC / motion graphic / talking head / product demo / text-on-screen]

STORYBOARD:
[00:00-00:03] HOOK FRAME
  Visual: [What viewer sees]
  Audio/VO: [What they hear — exact words]
  Text overlay: [Any on-screen text]

[00:03-00:08] PROBLEM/SETUP
  Visual: [...]
  Audio/VO: [...]
  Text overlay: [...]

[00:08-00:20] SOLUTION/BODY
  Visual: [...]
  Audio/VO: [...]
  Text overlay: [...]

[00:20-00:27] PROOF/CREDIBILITY
  Visual: [...]
  Audio/VO: [...]

[00:27-00:30] CTA
  Visual: [...]
  Audio/VO: [Exact CTA line]
  Text overlay: [CTA text on screen]

VOICEOVER SCRIPT (full):
[Complete word-for-word script]

MUSIC DIRECTION: [Vibe, energy, tempo — e.g., "upbeat lo-fi", "tense/dramatic build"]
CAPTION TEXT: [Full caption for the post]
```

### Batch Scale Target
- **Minimum:** 10 variations
- **Target:** 12-15 variations
- **Distribution:**
  - 4-5 static image creatives
  - 3-4 carousel concepts
  - 3-4 video scripts/storyboards
  - Split: ~60% paid, ~40% organic (adjust based on campaign goal)

### Copy Variation Rule
For highest-priority angles, produce 2 copy variations:
- **Version A:** Rational/benefit-led
- **Version B:** Emotional/story-led

---

## PHASE 5: PACKAGE

After full generation, present a summary:

```
📦 CREATIVE DECK SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Brand: [Name]
Campaign Goal: [Goal]
Total Creatives: [N]
  • Static: [N]
  • Carousel: [N]
  • Video Scripts: [N]
Platforms Covered: [List]
Creative Angles Used: [List]
Organic Variations: [N]
Paid Variations: [N]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RECOMMENDED TESTING PRIORITY:
1. [Creative #X] — [Why: highest-differentiation angle]
2. [Creative #Y] — [Why: proven format for this platform]
3. [Creative #Z] — [Why: emotional hook, high engagement potential]

NEXT STEPS:
• Design/edit: Send static + carousel briefs to designer
• Video: Send scripts to editor or UGC creator
• Launch: Upload paid variations to Meta/Google Ads Manager
• Test: A/B test [angle A] vs [angle B] first
```

Offer to:
- Export the full deck as a document (trigger docx skill)
- Refine any specific creative
- Generate additional variations for a specific angle
- Adapt the deck for a specific platform only

---

## Quick Reference

| Need | Go To |
|------|-------|
| Angle selection | `references/creative-angles.md` |
| Copy structure | `references/copywriting-frameworks.md` |
| Platform rules | `references/platform-specs.md` |
| Organic vs paid logic | `references/organic-vs-paid.md` |
| Video scripting | `references/video-scripting.md` |
| Carousel template | `templates/carousel-brief.md` |
| **Generate actual assets** | `agents/creative-production-agent.md` |
| Image gen prompting | `references/image-gen-prompting.md` |
| Carousel PNG renderer | `scripts/carousel-renderer.html` |

## Full Agent System

This skill runs four agents. Each has a defined role and feeds the next.

```
WEEKLY OPERATING RHYTHM:

MON: competitor-research-agent → intelligence brief
     performance-audit-agent   → action plan + next batch briefs

TUE: SKILL.md Phase 1-3 → creative strategy
     (fed by research + audit outputs)

WED: creative-production-agent → real assets generated
     (images, carousels, video packs)

THU: Launch new creatives
FRI: Mid-week pulse check
```

**Agent 1 — Competitor Research** → `agents/competitor-research-agent.md`
Scans Meta Ad Library, TikTok Creative Center, Google Ads Transparency Center. Identifies winning patterns, dominant angles, gap opportunities. Produces Competitive Intelligence Brief. Trigger: new client onboarding + every week.

**Agent 2 — Performance Audit** → `agents/performance-audit-agent.md`
Ingests performance data (manual paste / CSV / screenshot). Classifies creatives: Scale / Test / Kill / Iterate. Outputs weekly action plan + next batch creative briefs. Builds cumulative brand intelligence log. Trigger: every Monday.

**Agent 3 — Creative Production** → `agents/creative-production-agent.md`
Takes approved strategy and generates real assets. Image generation via tool hierarchy. Carousel rendering via carousel-renderer.html. Full video production packs. Trigger: after Phase 3 approval OR after audit briefs.

**Image Gen Tool Hierarchy** → `references/image-gen-tools.md`

Free-to-paid escalation order:
1. Pollinations.ai — $0, no key, instant (concepts)
2. Raphael.app — $0, unlimited, ad-quality (best free all-rounder)
3. Puter.js — $0, multi-model (DALL-E 3, SDXL, Flux — no key)
4. Gemini 2.0 Flash — Free tier via Google AI Studio key
5. Ideogram v2 — Free 10/day → $7/mo (best for text-in-image)
6. Leonardo.ai — Free 150 credits/day → $12/mo (brand consistency)
7. Stability AI — $10/mo (product photography)
8. Runway ML — $15/mo (actual video generation)
9. OpenAI GPT Image — $0.04-0.17/image (pay-per-use)

First-time setup (zero-cost start):
- Pollinations + Raphael: no setup, use immediately
- Gemini free: aistudio.google.com → Get API key (2 min)
- Ideogram: ideogram.ai → sign up → Dashboard → API
- Leonardo: leonardo.ai → sign up → API key
