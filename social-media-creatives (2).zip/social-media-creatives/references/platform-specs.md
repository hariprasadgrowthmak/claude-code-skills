# Platform Specs Reference

Character limits, image sizes, video rules, and best practices per platform. Always check this before finalizing copy or format briefs.

---

## INSTAGRAM

### Feed Post (Static)
- **Image size:** 1080×1080px (1:1) or 1080×1350px (4:5 — more screen space)
- **Caption:** Up to 2,200 characters (show more after ~125 chars)
- **Hashtags:** 3-10 (quality over quantity post-2023)
- **Best practice:** Lead with the strongest line — caption truncates early
- **Paid note:** 20% text rule relaxed, but text-heavy images still underperform

### Stories
- **Size:** 1080×1920px (9:16)
- **Safe zones:** Keep key content in center 70% (avoid top/bottom 250px)
- **Text on story:** Max 2-3 lines readable
- **Sticker/CTA:** Link sticker now available to all
- **Duration:** 15 sec per card (up to 3 cards per story)

### Reels
- **Size:** 1080×1920px (9:16)
- **Duration:** 15 sec – 90 sec (sweet spot: 15-30 sec for reach)
- **Caption:** Up to 2,200 chars
- **Hashtags:** 3-5 (Reels algorithm is interest-based, not hashtag-based)
- **Hook rule:** First frame must stop scroll — no black intro screens
- **Subtitles:** Always add — 80%+ watch on mute

### Carousel
- **Slides:** 2–10 images/videos
- **Size:** 1080×1080px or 1080×1350px (consistent across slides)
- **Caption:** Applies to whole carousel — hook in first line
- **Paid:** First slide = thumbnail — must be scroll-stopping

---

## FACEBOOK

### Feed Image (Single)
- **Size:** 1200×628px (link ads) or 1080×1080px (awareness)
- **Headline:** Up to 40 chars (truncates on mobile)
- **Primary text:** Up to 125 chars before "See more" (write for 90 chars)
- **Description:** Up to 30 chars
- **Best practice:** Put key message in primary text, not just the image

### Stories
- **Size:** 1080×1920px
- **Same specs as Instagram Stories**

### Reels/Video
- **Size:** 1080×1920px (9:16) or 1280×720px (16:9) for feed
- **Duration:** Up to 60 sec for Reels, up to 240 min for feed video
- **Paid video:** 15-30 sec performs best for conversion objectives

### Carousel Ads
- **Cards:** 2-10
- **Image per card:** 1080×1080px
- **Headline per card:** 25 chars
- **Description per card:** 25 chars
- **CTA:** One button across all cards (or unique per card)

---

## TIKTOK

### Video
- **Size:** 1080×1920px (9:16) — vertical only
- **Duration:** 15 sec – 10 min (sweet spot: 21-34 sec for organic, 9-15 sec for paid)
- **Caption:** 150 chars visible (2,200 max)
- **Hashtags:** 3-5 relevant
- **Hook rule:** First 2-3 seconds are everything — state the hook verbally AND visually
- **Style:** Raw > polished. Authentic > produced. Native-looking content outperforms ad-looking content.
- **Text overlay:** Essential — use TikTok's native text, not burned-in
- **Subtitles:** Critical — auto-captions or manual

### TikTok Ads (In-Feed)
- **Duration:** 9-60 sec (15-30 sec sweet spot)
- **Headline:** Up to 100 chars
- **No hashtags needed**
- **Creative tip:** Must look organic — avoid logo-heavy, brand-polished look

---

## LINKEDIN

### Feed Post (Static/Image)
- **Image size:** 1200×627px (landscape) or 1080×1080px (square)
- **Caption:** Up to 3,000 chars (show more at ~140-200 chars)
- **Best practice:** No link in post — put in first comment. Text-only posts often outperform image posts for reach.
- **Hashtags:** 3-5

### Video
- **Size:** 1920×1080px (16:9) or 1080×1080px (1:1)
- **Duration:** 3 sec – 30 min (sweet spot: 30-90 sec)
- **Subtitles:** Critical for LinkedIn — many watch without sound in offices
- **Hook:** State value prop in first 5 seconds

### Carousel (Document Posts)
- **Format:** Upload as PDF — LinkedIn renders as swipeable
- **Slides:** Unlimited (10-15 recommended)
- **Size:** 1080×1080px per slide
- **Best practice:** End slide should have a strong CTA + "save for later" prompt
- **Performance:** Document/carousel posts have highest organic reach on LinkedIn currently

### Sponsored Content (Paid)
- **Image:** 1200×627px
- **Headline:** Up to 150 chars (70 chars recommended)
- **Intro text:** Up to 600 chars (150 chars recommended)
- **CTA button:** Choose from preset options (Learn More, Download, Register, etc.)

---

## YOUTUBE SHORTS

### Video
- **Size:** 1080×1920px (9:16)
- **Duration:** Up to 60 sec
- **Title:** Up to 100 chars (first 40 most important)
- **Description:** Up to 5,000 chars
- **Hook:** Must appear within first 3 sec OR be strong enough to capture from thumbnail
- **Loop:** Shorts algorithm rewards watch-through — write content that loops naturally

### YouTube Long-Form (for context)
- **Thumbnail:** 1280×720px — most important creative element
- **Title:** 60 chars max visible
- **Hook:** First 30 sec determine retention — state the promise, create curiosity

---

## X (TWITTER)

### Tweet with Image
- **Image size:** 1200×675px (16:9) or 1200×1200px (square)
- **Character limit:** 280 chars
- **Best practice:** Write the tweet to stand alone — image is supporting
- **Hashtags:** 1-2 max (more reduces engagement)

### Video
- **Size:** 1280×720px or 1080×1920px
- **Duration:** Up to 140 sec
- **Max file:** 512MB
- **Caption:** Essential (most watch muted on X too)

---

## Quick Reference Table

| Platform | Best Ratio | Caption Sweet Spot | Hashtags | Key Rule |
|---|---|---|---|---|
| Instagram Feed | 4:5 | 90-125 chars | 5-10 | Hook in first line |
| Instagram Reels | 9:16 | 90 chars | 3-5 | Hook in first frame |
| Instagram Story | 9:16 | Minimal | None | Safe zones |
| Facebook Feed | 1:1 or 1.91:1 | 90 chars | None | Short headline |
| TikTok | 9:16 | 150 chars | 3-5 | Look organic |
| LinkedIn | 1.91:1 or 1:1 | 140-200 chars | 3-5 | Text-first |
| YouTube Shorts | 9:16 | 40-60 chars | 3-5 | Loop design |
| X | 16:9 | 240 chars | 1-2 | Tweet standalone |
