# Image Generation Tool Hierarchy

Full tool stack with free-to-paid escalation logic. The agent always tries tools in order — free first, paid only when free tools can't meet quality requirements.

---

## Tool Selection Decision Tree

```
START: What quality level is needed?

→ CONCEPT VALIDATION / QUICK TEST
   → Use: Pollinations.ai (free, instant, no key)
   → Or: Raphael.app (free, unlimited, no key)

→ PRODUCTION-QUALITY STATIC AD
   → Need text-in-image? → Ideogram v2 (best for this)
   → Need lifestyle/photorealistic? → Leonardo.ai free tier
   → Need product photography? → Stability AI (paid)
   → Need ultra-high-aesthetic? → Midjourney (paid, no API)

→ HIGH VOLUME BATCH (20+ images)
   → Raphael.app (unlimited free) → Pollinations.ai backup
   → If quality must be high: Gemini 2.0 Flash (free tier, rate limited)

→ BRAND-CONSISTENT SERIES (same characters/faces)
   → Leonardo.ai (consistent face/style with LoRA)
   → Or: Stability AI with img2img reference

→ ACTUAL VIDEO GENERATION
   → Runway ML (paid, $15/mo) — best quality
   → Kling AI ($10/mo) — good alternative
   → Pika Labs (free tier available)
```

---

## TIER 1 — COMPLETELY FREE (No Key Required)

### 1. Pollinations.ai ⭐ Primary Free Tool
- **Cost:** $0 forever, no account, no key
- **Best for:** Concept validation, high-volume generation, Reels cover frames
- **Quality:** Good (Flux model) — not quite ad-production level but solid
- **Rate limit:** None stated, but use reasonable intervals
- **API call:**
```javascript
const prompt = encodeURIComponent("Your prompt here");
const url = `https://image.pollinations.ai/prompt/${prompt}?width=1080&height=1350&model=flux&nologo=true&enhance=true`;
// Use as <img src="{url}"> or fetch as blob
```
- **Aspect ratio:**
  - 1080×1350 = Instagram 4:5
  - 1080×1080 = Square
  - 1080×1920 = Story/Reels 9:16
  - 1280×720 = Landscape 16:9
- **Pro tips:**
  - Add `&enhance=true` for automatic prompt enhancement
  - Add `&seed=[number]` for reproducibility
  - Model options: `flux` (default), `flux-realism`, `flux-pro`

### 2. Raphael.app ⭐ Best Free Quality
- **Cost:** $0, unlimited, no registration
- **Best for:** Ad-quality statics, photorealistic lifestyle, product mockups
- **Quality:** Excellent (Z-Image + Flux 2 routing) — genuinely ad-quality
- **API:** Via web interface or unofficial endpoint
- **Best use:** When Pollinations quality isn't sufficient but you don't want to spend credits
- **URL:** https://raphael.app
- **Prompt style:** Natural language, same formula as Ideogram

### 3. Puter.js — Multi-Model Free Access
- **Cost:** $0 (user-pays model — costs push to end user, not developer)
- **Best for:** Accessing DALL-E 3, SDXL, Flux without paying
- **Models available:** GPT Image, DALL-E 2/3, Gemini 2.5 Flash, Flux.1, Stable Diffusion XL
- **API call:**
```javascript
// Include in HTML: <script src="https://js.puter.com/v2/"></script>
const imageEl = await puter.ai.txt2img("Your prompt", false, "dall-e-3");
document.body.appendChild(imageEl);
// model options: "dall-e-3", "dall-e-2", "stable-diffusion-xl", "flux"
```
- **Best for:** When you need DALL-E 3 or SDXL quality without paying OpenAI/Stability AI

---

## TIER 2 — FREEMIUM (Free Tier + Paid Upgrade)

### 4. Ideogram v2 ⭐ Best for Text-in-Image
- **Cost:** Free (10 slow generations/day) → $7/mo (100+/day, fast)
- **Best for:** Text-on-image ads (unmatched text rendering), bold graphic ads, designed creatives
- **Quality:** Excellent — best in class for ad creatives with text overlays
- **API:**
```javascript
const response = await fetch("https://api.ideogram.ai/generate", {
  method: "POST",
  headers: { "Api-Key": API_KEY, "Content-Type": "application/json" },
  body: JSON.stringify({
    image_request: {
      prompt: prompt,
      negative_prompt: negativePrompt,
      aspect_ratio: "ASPECT_RATIO_4_5", // 1_1, 9_16, 16_9, 4_5, 3_2
      model: "V_2",
      style_type: "REALISTIC", // DESIGN, RENDER_3D, ANIME
      magic_prompt_option: "ON"
    }
  })
});
const data = await response.json();
const imageUrl = data.data[0].url;
```
- **Setup:** ideogram.ai → sign up → Dashboard → API → Generate Key
- **When to use:** Any creative that needs text rendered in the image itself

### 5. Leonardo.ai ⭐ Best for Brand Consistency
- **Cost:** Free (150 credits/day ≈ 10-15 images) → $12/mo (8,500 credits/mo)
- **Best for:** Consistent brand characters, product lifestyle shots, face consistency across a series
- **Quality:** Excellent — especially with their Phoenix model
- **API:**
```javascript
// Generate image
const genResponse = await fetch("https://cloud.leonardo.ai/api/rest/v1/generations", {
  method: "POST",
  headers: { "Authorization": `Bearer ${API_KEY}`, "Content-Type": "application/json" },
  body: JSON.stringify({
    prompt: prompt,
    negative_prompt: negativePrompt,
    modelId: "b24e16ff-06e3-43eb-8d33-4416c2d75876", // Leonardo Phoenix
    width: 1024, height: 1280, // 4:5 ratio
    num_images: 1,
    guidance_scale: 7,
    public: false
  })
});
const genData = await genResponse.json();
const generationId = genData.sdGenerationJob.generationId;

// Poll for result (Leonardo is async)
const resultResponse = await fetch(
  `https://cloud.leonardo.ai/api/rest/v1/generations/${generationId}`,
  { headers: { "Authorization": `Bearer ${API_KEY}` } }
);
const result = await resultResponse.json();
const imageUrl = result.generations_by_pk.generated_images[0].url;
```
- **Setup:** leonardo.ai → create account → API → generate key

### 6. Gemini 2.0 Flash Image (Google AI Studio)
- **Cost:** Free tier (2 images/min) → $0.02/image on paid
- **Best for:** High quality versatile generation, multimodal prompts
- **API:**
```javascript
const response = await fetch(
  `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${API_KEY}`,
  {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { responseModalities: ["TEXT", "IMAGE"] }
    })
  }
);
const data = await response.json();
const imageBase64 = data.candidates[0].content.parts
  .find(p => p.inlineData)?.inlineData.data;
```
- **Setup:** aistudio.google.com → Get API key (free, instant)

---

## TIER 3 — PAID (When Volume + Quality Both Required)

### 7. Stability AI (SDXL / SD3)
- **Cost:** $10/mo → pay-per-image on API
- **Best for:** Product photography, fine-grained control, img2img variations
- **API:**
```javascript
const formData = new FormData();
formData.append("prompt", prompt);
formData.append("aspect_ratio", "4:5"); // or 1:1, 9:16, 16:9
formData.append("output_format", "webp");

const response = await fetch(
  "https://api.stability.ai/v2beta/stable-image/generate/ultra",
  {
    method: "POST",
    headers: { "Authorization": `Bearer ${API_KEY}`, "Accept": "image/*" },
    body: formData
  }
);
const imageBlob = await response.blob();
```
- **Setup:** platform.stability.ai → sign up → API Keys

### 8. Runway ML (Video Generation)
- **Cost:** $15/mo (standard) → $35/mo (pro)
- **Best for:** Generating actual video from text or image+text
- **API:**
```javascript
const response = await fetch("https://api.dev.runwayml.com/v1/image_to_video", {
  method: "POST",
  headers: {
    "Authorization": `Bearer ${API_KEY}`,
    "Content-Type": "application/json",
    "X-Runway-Version": "2024-11-06"
  },
  body: JSON.stringify({
    model: "gen3a_turbo",
    promptImage: imageUrl, // starting frame
    promptText: videoPrompt,
    duration: 10, // 5 or 10 seconds
    ratio: "1280:768" // or 768:1280 for vertical
  })
});
```
- **Setup:** runwayml.com → sign up → API access

### 9. OpenAI GPT Image 1 (gpt-image-1)
- **Cost:** $0.04-0.17 per image depending on quality
- **Best for:** When you need GPT-quality understanding of complex prompts
- **API:**
```javascript
const response = await fetch("https://api.openai.com/v1/images/generations", {
  method: "POST",
  headers: { "Authorization": `Bearer ${API_KEY}`, "Content-Type": "application/json" },
  body: JSON.stringify({
    model: "gpt-image-1",
    prompt: prompt,
    size: "1024x1536", // 2:3 portrait
    quality: "medium", // low, medium, high
    n: 1
  })
});
const data = await response.json();
const imageBase64 = data.data[0].b64_json;
```

---

## Agent Tool Selection Logic

When the production agent needs to generate an image, use this decision flow:

```javascript
function selectImageTool(requirements) {
  const { needsTextInImage, quality, volume, hasBudget, brandConsistency } = requirements;
  
  // Text in image = Ideogram always
  if (needsTextInImage) return "ideogram";
  
  // High volume + no budget = Raphael or Pollinations
  if (volume > 10 && !hasBudget) return "raphael"; // best free quality
  
  // Brand consistency series = Leonardo
  if (brandConsistency) return "leonardo";
  
  // Quick concept = Pollinations (fastest)
  if (quality === "concept") return "pollinations";
  
  // Production quality + budget = Stability AI
  if (quality === "production" && hasBudget) return "stability";
  
  // Video = Runway
  if (requirements.isVideo) return "runway";
  
  // Default: Raphael (best free all-rounder)
  return "raphael";
}
```

---

## Prompt Compatibility Notes

| Tool | Prompt Style | Max Length | Special Params |
|---|---|---|---|
| Pollinations | Natural language | 500 chars | model, enhance, seed |
| Raphael | Natural language | Unlimited | Style selector in UI |
| Ideogram | Detailed descriptive | 1500 chars | negative_prompt, style_type, magic_prompt |
| Leonardo | Natural language + tags | 1000 chars | negative_prompt, guidance_scale, modelId |
| Gemini | Conversational/instructional | 32k tokens | responseModalities |
| Stability | Natural language | 10k chars | negative_prompt, aspect_ratio, style_preset |
| Runway | Action-oriented | 512 chars | promptImage for img2video |

---

## Monthly Cost Estimation by Scale

| Team Size | Volume | Recommended Stack | Est. Monthly Cost |
|---|---|---|---|
| Solo / just starting | 20-50 images/mo | Pollinations + Raphael + Ideogram free | $0 |
| Small team (2-5) | 100-300 images/mo | Ideogram $7 + Leonardo $12 | $19/mo |
| Agency (5-10 clients) | 500-1000 images/mo | Ideogram Pro + Stability AI + Leonardo | ~$50/mo |
| Scale (10+ clients) | 2000+/mo | Full stack above + Runway for video | ~$100-150/mo |
