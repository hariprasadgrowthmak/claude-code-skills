# Copywriting Frameworks Reference

Proven copy structures for social media ads and organic content. Select based on format, angle, and funnel stage.

---

## FRAMEWORK 1: PAS — Problem → Agitate → Solution

**Best for:** Paid ads, high-intent audiences, pain-driven angles
**Format fit:** Static, short video, story

```
P — Problem: Name the pain clearly and specifically
A — Agitate: Make the pain feel real, urgent, consequential
S — Solution: Present your product as the relief

Example:
P: "Managing client projects in spreadsheets is a mess."
A: "Missed deadlines. Angry clients. Hours wasted chasing updates."
S: "[Product] gives your team one place for everything. Try it free."
```

---

## FRAMEWORK 2: AIDA — Attention → Interest → Desire → Action

**Best for:** Carousels, longer copy, mid-funnel paid
**Format fit:** Carousel (one stage per slide), long-form video

```
A — Attention: Stop the scroll with a bold hook (visual or copy)
I — Interest: Give them a reason to keep reading/watching
D — Desire: Make them want the outcome
A — Action: Clear, friction-free CTA

Example (carousel):
Slide 1 (Attention): "You're leaving money on the table every month."
Slide 2 (Interest): "Here's the 3-step system top DTC brands use."
Slide 3-4 (Desire): Show the system, the results, the transformation
Slide 5 (Action): "Download the free guide →"
```

---

## FRAMEWORK 3: Hook → Story → Offer (HSO)

**Best for:** Video (Reels, TikTok), UGC-style content
**Format fit:** Video (most powerful here), Carousel narrative

```
Hook (0-3 sec): One line that creates an open loop or emotion
Story (4-20 sec): Relatable context or journey — the "before"
Offer (last 5-8 sec): What you have, what they should do

Example:
Hook: "I was spending 4 hours a day on email."
Story: "Then I found this tool. I thought it was too good to be true.
        Here's what happened after 30 days of using it..."
Offer: "Try [product] free — link in bio."
```

---

## FRAMEWORK 4: Before → After → Bridge (BAB)

**Best for:** Transformation angles, testimonials, case studies
**Format fit:** Static (split layout), Video, Carousel

```
Before: Current pain state (relatable, specific)
After: Desired outcome state (vivid, aspirational)
Bridge: Your product is how they get there

Example:
Before: "Cold outreach with 2% reply rates."
After: "Warm pipeline that books 15 calls a week on autopilot."
Bridge: "[Product] personalizes every email in seconds. Here's how."
```

---

## FRAMEWORK 5: 4 U's (Useful, Urgent, Unique, Ultra-specific)

**Best for:** Headlines, static ad copy, carousel hooks
**Format fit:** Single-frame creatives, story ads

```
Useful: Does it give the reader something valuable?
Urgent: Is there a reason to act now?
Unique: Is this framing different from what they've seen?
Ultra-specific: Numbers, names, timeframes — not vague claims

Weak headline: "Improve your marketing."
Strong headline: "Get 3x more leads in 30 days — or we work for free."
```

---

## FRAMEWORK 6: SLAP — Stop → Look → Act → Purchase

**Best for:** E-commerce, direct-response static ads
**Format fit:** Static, Story, carousel first slide

```
Stop: Visual + headline that interrupts scrolling
Look: Clear product/offer presentation
Act: Obvious next step (swipe, click, tap)
Purchase: Remove friction — make buying feel easy and safe

Example:
Stop: [Bold product image with "60% off today only"]
Look: [Product features, social proof, price]
Act: "Tap to shop"
Purchase: [Guarantee / free returns mention]
```

---

## FRAMEWORK 7: Question → Insight → Proof → CTA

**Best for:** B2B, thought leadership, education-first organic
**Format fit:** Carousel, LinkedIn, long-form caption

```
Question: Open with a genuine, relevant question your audience has
Insight: Deliver a non-obvious, valuable answer
Proof: Back it with data, story, or example
CTA: Soft CTA — save, share, comment, or link

Example:
Q: "Why do most SaaS trials fail to convert?"
Insight: "It's not the product — it's the onboarding moment at day 3."
Proof: "We analyzed 200 trials. 70% churned within 72 hours without X."
CTA: "What's your day-3 activation event? Drop it below."
```

---

## FRAMEWORK 8: Credibility Stack

**Best for:** Cold audiences, high-ticket offers, B2B
**Format fit:** Static, carousel, video intro

```
Layer 1 — Social proof number: "Join 50,000+ [audience]"
Layer 2 — Authority signal: "Featured in [publication]" or "Used by [brand]"
Layer 3 — Specific result: "Average customer saves X hours/month"
Layer 4 — Risk reversal: "Free trial / money-back guarantee"
Layer 5 — CTA

Note: Don't use all layers in one ad — pick 2-3 most relevant.
```

---

## HOOK WRITING GUIDE

The hook is the most important copy element. Applies to video (first 3 seconds), static (headline), carousel (slide 1), caption (first line).

### Hook Formulas

**Curiosity/Open Loop:**
- "Nobody talks about [topic] but it's the reason [outcome]."
- "I tried [X] for 30 days. Here's what happened."
- "The [industry] secret that [brands/experts] don't want you to know."

**Pattern Interrupt:**
- "Stop [common behavior]. It's costing you [outcome]."
- "Unpopular opinion: [contrarian statement]."
- "This [common thing] is a lie."

**Specificity Hook:**
- "How [name] grew from [X] to [Y] in [timeframe] using [method]."
- "We tested [X] versions of [thing]. Here's what won."
- "[Specific number] ways to [desirable outcome] in [timeframe]."

**Direct Benefit:**
- "Get [outcome] without [pain/barrier]."
- "The fastest way to [goal] — even if [objection]."

**Audience Call-Out:**
- "If you're a [audience] struggling with [pain], read this."
- "For [audience] who want [outcome] but don't have [resource]."

**Fear/Pain:**
- "You're [making this mistake] and it's costing you [X]."
- "Most [audience] will [negative outcome] this year. Here's why."

---

## CTA Selection Guide

Match CTA to funnel stage and platform:

| Stage | CTA Examples |
|-------|-------------|
| Awareness | "Save this", "Follow for more", "Share this with [person]" |
| Engagement | "Drop a [emoji] if this is you", "Comment your answer" |
| Consideration | "Learn more", "See how it works", "Read the case study" |
| Conversion | "Try free", "Get [X]% off", "Book a call", "Shop now" |
| Retargeting | "Don't miss out", "You were close — complete your order", "Last chance" |
