# Video Scripting Reference

Frameworks for writing high-performing video scripts and storyboards for Reels, TikTok, YouTube Shorts, and paid video ads.

---

## Video Creative Fundamentals

### The Attention Economy Rule
- **0-3 sec:** Hook window — if you don't have them here, you've lost them
- **3-10 sec:** Setup — establish context, raise stakes
- **10-25 sec:** Body — deliver the value or story
- **25-30 sec:** CTA — single, clear action

For longer videos (60-90 sec), the structure expands proportionally but the hook rule never changes.

### The Muted-Watch Test
70-85% of social video is watched on mute. Every video must work without audio:
- On-screen text for every key point
- Subtitles/captions always (auto-captions are fine but review for accuracy)
- Visual storytelling must carry the narrative independently
- Use emojis or visual cues as audio substitutes

---

## Video Styles Guide

### 1. Talking Head (Direct to Camera)
**Best for:** UGC, testimonials, founder content, opinions, tutorials
**Production:** Phone + ring light, or natural window light. Raw is better than overly polished.
**Key rule:** Energy must match the content. Low energy = viewer drops off.
**Script style:** Conversational, natural pauses, first person
**Feels like:** A friend giving advice, not a commercial

### 2. Screen Recording / Demo
**Best for:** SaaS, apps, tools, anything with a UI or digital output
**Production:** Loom, QuickTime, or Zoom recording. No special equipment.
**Key rule:** Narrate what you're doing in real time — don't go silent
**Script style:** Step-by-step walkthrough with running commentary
**Feels like:** A how-to tutorial

### 3. Text-on-Screen (No Face)
**Best for:** Lists, tips, myths, stats, quotes — high-volume organic content
**Production:** CapCut, Adobe Express, or Canva. Easy to batch-produce.
**Key rule:** One point per screen. 3-6 words per text card. Fast pacing.
**Script style:** Punchy fragments, not full sentences
**Feels like:** A fast-moving listicle

### 4. Product Demo / Unboxing
**Best for:** Physical products, e-commerce, beauty, food
**Production:** Good lighting, stable shot, B-roll of product in use
**Key rule:** Show the product doing the most impressive thing as early as possible
**Script style:** VO or text describing what's happening on screen
**Feels like:** Product discovery, not a commercial

### 5. Motion Graphic / Animated
**Best for:** Data-driven content, abstract concepts, B2B, brand awareness
**Production:** After Effects, MotionArray, Canva animated templates
**Key rule:** Keep animation simple — don't let motion distract from message
**Script style:** Clear VO with synchronized text overlays
**Feels like:** An explainer or infographic brought to life

### 6. Lifestyle / B-Roll Montage
**Best for:** Brand building, aspirational products, services
**Production:** Cinematic b-roll of product in use or lifestyle context
**Key rule:** Music choice and pacing are the creative — they carry the emotion
**Script style:** Minimal VO or text, let visuals speak
**Feels like:** A brand film

---

## Hook Formula Library

### Curiosity Hooks
- "The reason [common thing] isn't working for you..."
- "Nobody shows you this part of [topic]."
- "I tested [X] for 30 days. Here's the honest truth."
- "There's a reason [surprising fact]. Let me show you."

### Pain/Fear Hooks
- "You're losing [X] every [timeframe] because of this."
- "Stop doing [thing] — here's why it's hurting you."
- "Most [audience] make this mistake and don't realize it until [consequence]."

### Benefit/Promise Hooks
- "How to [outcome] in [timeframe] — even if [objection]."
- "I went from [before] to [after] using one simple [thing]."
- "The [X]-step system that [specific result]."

### Pattern Interrupt Hooks
- "This is not what you think it is."
- "Hear me out." (then pause)
- "Hot take: [contrarian statement]."
- "[Show something surprising visually in the first frame — no words needed]"

### Direct Call-Out Hooks
- "If you're a [audience], stop scrolling."
- "This one's for the [audience] who [relatable situation]."
- "Every [role] needs to hear this."

---

## Storyboard Structure Templates

### Template A: 15-Second Paid Video (TikTok/Reels)

```
[00:00-00:02] HOOK FRAME
  Visual: [Most attention-grabbing image possible]
  VO: [One punchy hook line]
  Text overlay: [Repeat hook or key word]

[00:02-00:07] PROBLEM/CONTEXT
  Visual: [Show the pain or before state]
  VO: [Establish the problem briefly]
  Text overlay: [Key pain point]

[00:07-00:12] SOLUTION REVEAL
  Visual: [Product in action or result]
  VO: [Name product, state the key benefit]
  Text overlay: [Benefit + product name]

[00:12-00:15] CTA
  Visual: [Product, logo, or result visual]
  VO: [Action line — "Try it free", "Link in bio"]
  Text overlay: [CTA + offer if any]
```

### Template B: 30-Second Paid Video (Full Funnel)

```
[00:00-00:03] HOOK
  Visual: [Pattern interrupt — unexpected visual or text]
  VO: [Bold claim or question]
  Text overlay: [Hook text]

[00:03-00:08] PROBLEM
  Visual: [Relatable pain scenario]
  VO: [Describe the problem — be specific]
  Text overlay: [Pain point label]

[00:08-00:18] SOLUTION + DEMO
  Visual: [Product doing the thing]
  VO: [How the product solves it — 2-3 key features max]
  Text overlay: [Feature labels or benefit callouts]

[00:18-00:24] PROOF
  Visual: [Results screen, testimonial clip, or metric]
  VO: [Social proof stat or testimonial quote]
  Text overlay: [Number or quote]

[00:24-00:30] CTA
  Visual: [Product/logo/offer visual]
  VO: [Exact CTA line]
  Text overlay: [CTA + offer]
```

### Template C: 60-Second Organic Reel / TikTok

```
[00:00-00:03] HOOK
  Visual: [Must stop scroll immediately]
  VO: [Open loop or bold statement]
  Text overlay: [Hook text — question or promise]

[00:03-00:10] SETUP / RELATE
  Visual: [Relatable context — show before state]
  VO: [Tell a relatable story or establish the problem]
  Text overlay: [Situation label]

[00:10-00:25] VALUE DELIVERY
  Visual: [Show the insight/method/product]
  VO: [Deliver the actual value — be specific]
  Text overlay: [Key points — numbered list works well]

[00:25-00:45] STORY / PROOF
  Visual: [Show results or journey]
  VO: [What happened, what changed]
  Text overlay: [Before/after callouts]

[00:45-00:55] IMPLICATIONS
  Visual: [Zoom out — what does this mean for the viewer?]
  VO: [Why this matters to them specifically]
  Text overlay: [Key takeaway]

[00:55-01:00] SOFT CTA
  Visual: [Friendly closing frame]
  VO: ["Follow for more" / "Link in bio" / "Comment below"]
  Text overlay: [CTA]
```

### Template D: YouTube Shorts (Loop-Optimized)

```
[00:00-00:03] HOOK (also functions as loop ending)
  — Design so the end of the video flows back into this naturally
  Visual: [Something that creates visual or narrative loop]
  VO: [Hook that also resolves the ending]

[00:03-00:15] VALUE CORE
  Visual: [The single best thing about the product/insight]
  VO: [The one thing they should know]

[00:15-00:25] PROOF OR EXAMPLE
  Visual: [Demonstrate or evidence the claim]
  VO: [Back it up fast]

[00:25-00:30] CTA / LOOP
  Visual: [Circles back to hook visual]
  VO: ["Subscribe for more" or product mention]
  — Viewer loops back to start
```

---

## Voiceover Writing Rules

1. **Write for ears, not eyes.** Spoken language is shorter and more fragmented than written. Read every line aloud.

2. **One idea per sentence.** No compound sentences in VO. Period. Full stop. Move on.

3. **Pace = engagement.** Fast pacing (1 sentence per 1.5-2 sec) feels energetic. Slower pacing (1 sentence per 3-4 sec) feels authoritative. Match to brand and content type.

4. **Contractions are mandatory.** "You are" = stiff. "You're" = human. Always use contractions in VO.

5. **Numbers land hard.** "A lot of customers" < "12,000 customers". Be specific.

6. **End on action, not statement.** Last VO line should be a verb: "Try it." "Start here." "Follow for more." Not: "It's really great."

---

## Music Direction Guide

Music direction should be specific enough for a video editor to act on:

| Vibe | Direction | Example |
|---|---|---|
| Energetic/hype | "Fast-paced trap/hip-hop, 140+ BPM, punchy drops" | Product launch, sale |
| Professional/trustworthy | "Clean corporate background, piano or light strings" | B2B, finance |
| Inspirational | "Uplifting indie/acoustic, building progression" | Transformation, brand story |
| Urgent | "Tense electronic, rising tempo" | Limited offer, problem-focused |
| Playful | "Light lo-fi, bubbly synths" | Consumer apps, lifestyle |
| Premium/luxury | "Minimal, low bass, slow tempo" | Fashion, premium products |
| Authentic/raw | "No music or ambient-only" | UGC testimonials, honest reviews |

Always note: "TikTok-trending audio preferred for organic reach" when relevant.
