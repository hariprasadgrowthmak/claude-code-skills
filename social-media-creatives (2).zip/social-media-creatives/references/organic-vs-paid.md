# Organic vs. Paid Creative Logic

The same angle can succeed in both organic and paid — but the execution must be fundamentally different. This file defines the logic for adapting creatives between channels.

---

## The Core Difference

| Dimension | Organic | Paid |
|---|---|---|
| **User intent** | Browsing, discovering, entertaining | Interrupted — didn't ask for this |
| **Trust level** | Higher (they chose to follow/find) | Lower (cold or warm audience) |
| **Primary goal** | Engagement, brand love, community | Clicks, leads, purchases |
| **Success metric** | Saves, shares, comments, reach | CTR, CPC, ROAS, CPA |
| **Creative style** | Native, educational, entertaining | Direct, benefit-led, offer-driven |
| **CTA energy** | Soft, inviting | Clear, urgent, low-friction |
| **Brand voice** | More personality, more opinion | More clarity, less noise |
| **Length** | Can be longer if value is high | Shorter = almost always better |
| **Hook purpose** | Earn attention, deliver value | Stop the scroll, create desire |

---

## Organic Creative Principles

### 1. Value First, Brand Second
Organic content succeeds when it genuinely helps, entertains, or connects. Brand mentions should feel natural, not forced. Lead with the insight or story — let the product come in as "how I did it."

### 2. Platform-Native Formats Win
On TikTok: raw, real, trending audio, subtitles.
On LinkedIn: personal stories, text-heavy, strong take.
On Instagram: aesthetic coherence, carousel saves, Reels with utility.
Don't cross-post without adapting tone and format.

### 3. Engagement Loops
Organic algorithms reward comments and saves over likes. Engineer this:
- Ask a question at the end
- Make a bold claim that invites debate
- Create "save this for later" utility (checklist, guide, template)
- Use carousel format — swipes are a positive signal

### 4. Consistency > Virality
Organic growth compounds. A consistent series (weekly format, recurring theme) outperforms one-off viral attempts over 90 days.

### 5. Organic-First Angles
Priority angles for organic: Education, Myth Busting, Behind the Scenes, Relatability, Challenge/Controversy, Trend, Aspiration/Identity.

---

## Paid Creative Principles

### 1. Hook in 3 Seconds
Paid content is interrupting someone who didn't ask for it. You have ~3 seconds before they scroll past. The hook must be visual AND verbal. Never start a paid video with a logo or intro sequence.

### 2. State the Offer Clearly
Don't make them guess. The value proposition must be obvious:
- What is this?
- Why should I care?
- What do I do next?
Answer all three within the first 15 seconds (video) or in one glance (static).

### 3. Match Creative to Funnel Stage

**Top of Funnel (Cold):**
- Angles: Curiosity, Pain Amplification, Education, Aspiration
- Goal: Awareness and click
- Avoid: Hard sell on first touch
- Copy: Focus on the problem or insight, not the product

**Middle of Funnel (Warm — visited site, viewed content):**
- Angles: Testimonial, Comparison, Demo, Social Proof
- Goal: Consideration, email capture, trial
- Copy: More specific, acknowledge they've seen you before

**Bottom of Funnel (Retargeting — added to cart, started signup):**
- Angles: Urgency, Risk Reversal, Scarcity, Discount
- Goal: Conversion
- Copy: Remind, overcome objection, make it easy

### 4. Test Angles Before Polishing
Run cheap tests ($10-20/day per creative) with simple variations before investing in production. Test the angle and hook first — if the concept doesn't work in lo-fi, it won't work polished.

### 5. Paid-First Angles
Priority angles for paid: Social Proof, Testimonial, Free/Risk Reversal, FOMO, Pain Amplification, Demo, Discount, Comparison.

---

## Adapting the Same Angle: Example

**Angle: Transformation / Before & After**
**Brand: Productivity SaaS**

### Organic Version
```
Caption: "I used to spend 3 hours a day in my inbox.

Then I changed one thing.

Instead of [old behavior], I started [new behavior using the product].

90 days later:
→ Inbox zero every morning by 9am
→ 2 hours back in my day
→ Actually excited to start work again

The tool I use? [Product] — link in bio.

What's your biggest productivity time sink? Drop it below 👇"

Format: Carousel or Reel (talking head, raw/casual)
CTA: Soft — "link in bio", question to drive comments
```

### Paid Version
```
Hook (video): "I used to spend 3 hours a day just on email."
Body: "Not anymore. [Product] cut that to 20 minutes."
Proof: "50,000 teams use it. Average user saves 2 hours/day."
CTA: "Try it free — no credit card required."

Format: 15-30 sec video or static with bold stat
CTA: Hard — "Try free now" button
Primary text: "Spending too long on email? [Product] fixes that in minutes."
```

---

## Platform-Specific Organic/Paid Splits

| Platform | Organic Strength | Paid Strength |
|---|---|---|
| Instagram | Brand building, lifestyle, Reels reach | E-commerce, lead gen, retargeting |
| TikTok | Virality, brand discovery, UGC | Performance for younger demos, impulse products |
| LinkedIn | Thought leadership, B2B credibility | B2B lead gen, job-adjacent offers |
| YouTube | Education, long-form trust | Intent-based targeting, mid-funnel |
| Facebook | Community, local organic | Retargeting, age 30+ demographics |
| X/Twitter | Real-time takes, niche communities | Awareness, tech/finance audiences |

---

## Repurposing Rules

When adapting organic content into paid:
1. Trim to essential — remove all filler
2. Add explicit CTA — organic rarely needs one, paid always does
3. Recut the hook — make it interruptive, not discovery-based
4. Add social proof if missing
5. Check for offers — organic content rarely has an offer; add one

When adapting paid content into organic:
1. Remove "ad feel" — no offer in first half
2. Add personality and context — tell the story behind the stat
3. Invite engagement explicitly
4. Remove hard CTAs — replace with soft ones
5. Optimize for native platform format
