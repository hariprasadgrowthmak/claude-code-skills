# Creative Angles Reference

A taxonomy of 25+ proven creative angles for social media. Each angle includes its psychological trigger, best use case, and format fit.

---

## EMOTIONAL ANGLES

### 1. Transformation / Before & After
- **Trigger:** Hope, aspiration, desire for change
- **Core message:** "Here's what's possible for you"
- **Best for:** Fitness, beauty, SaaS, coaching, finance
- **Format fit:** Static (split image), Carousel (journey), Video (testimonial)
- **Paid/Organic:** Both — extremely versatile
- **Example hook:** "I was [problem state]. 90 days later — [result]."

### 2. Fear of Missing Out (FOMO)
- **Trigger:** Loss aversion, social comparison
- **Core message:** "Everyone else is already doing this. Are you?"
- **Best for:** Trending products, limited offers, communities
- **Format fit:** Static, Story
- **Paid/Organic:** Paid (urgency drives clicks)
- **Example hook:** "While you hesitate, [competitor/peer] is already [winning]."

### 3. Fear / Pain Amplification
- **Trigger:** Anxiety, risk avoidance
- **Core message:** "This problem is worse than you think — here's the solution"
- **Best for:** Insurance, security, health, productivity
- **Format fit:** Video (build tension), Carousel (problem reveal)
- **Paid/Organic:** Paid (high intent trigger)
- **Example hook:** "Most [audience] don't realize they're [making this mistake]."
- **Warning:** Don't overdo — pair with immediate relief/solution

### 4. Aspiration / Identity
- **Trigger:** Desired self-image, status, belonging
- **Core message:** "This is who you become when you use this"
- **Best for:** Fashion, lifestyle brands, premium SaaS, fitness
- **Format fit:** Static (lifestyle), Video (lifestyle montage)
- **Paid/Organic:** Both — especially strong for organic brand-building
- **Example hook:** "Built for people who [identity trait]."

### 5. Curiosity / Pattern Interrupt
- **Trigger:** Intrigue, novelty, open loops
- **Core message:** "You won't believe this / Here's something unexpected"
- **Best for:** Education, content marketing, products with a surprising angle
- **Format fit:** Video (hook-driven), Carousel (reveal format)
- **Paid/Organic:** Organic (high share/save rate), Paid (strong CTR)
- **Example hook:** "Nobody talks about this but [counterintuitive truth]."

### 6. Relatability / Shared Experience
- **Trigger:** Empathy, "they get me"
- **Core message:** "We understand your struggle better than anyone"
- **Best for:** Consumer products, community brands, lifestyle
- **Format fit:** UGC video, Carousel (meme-style), Static
- **Paid/Organic:** Both — organic gold
- **Example hook:** "If you've ever [relatable problem], this is for you."

### 7. Us vs. Them / Contrarian
- **Trigger:** Tribal identity, rebellion against status quo
- **Core message:** "The old way is broken. We're different."
- **Best for:** Challenger brands, disruptors, B2B SaaS
- **Format fit:** Static (bold statement), Video (manifesto style)
- **Paid/Organic:** Both — very shareable organically
- **Example hook:** "Everyone said [conventional wisdom] was the answer. We disagree."

---

## RATIONAL / PROOF ANGLES

### 8. Social Proof / Numbers
- **Trigger:** Herd mentality, trust, risk reduction
- **Core message:** "X people can't be wrong"
- **Best for:** Any product with strong metrics, reviews, or user base
- **Format fit:** Static (stat highlight), Carousel (testimonial stack)
- **Paid/Organic:** Paid (high trust, drives conversion)
- **Example hook:** "50,000+ [customers] chose us. Here's why."

### 9. Testimonial / User Story
- **Trigger:** Vicarious experience, trust transfer
- **Core message:** "Someone just like you got this result"
- **Best for:** Any product — universal angle
- **Format fit:** Video (talking head UGC), Carousel (story format)
- **Paid/Organic:** Both — best performing paid format consistently
- **Example hook:** "[Name] was [situation]. Then she tried [product]."

### 10. Authority / Credibility
- **Trigger:** Trust, expertise, legitimacy
- **Core message:** "We're the experts — backed by [proof]"
- **Best for:** B2B, health, finance, education, consulting
- **Format fit:** Static (badge/award), Carousel (credentials), Video (expert interview)
- **Paid/Organic:** Both
- **Example hook:** "Used by [logos/names]. Trusted by [credential]."

### 11. Comparison / Competitor
- **Trigger:** Rational evaluation, switching motivation
- **Core message:** "See why [we] beats [alternative]"
- **Best for:** SaaS, tools, products with clear feature advantages
- **Format fit:** Carousel (comparison table), Static (side-by-side)
- **Paid/Organic:** Paid (retargeting, high-intent audiences)
- **Example hook:** "Tired of paying for [competitor]? See what you're missing."

### 12. ROI / Value Proof
- **Trigger:** Logic, financial motivation
- **Core message:** "This pays for itself"
- **Best for:** SaaS, tools, B2B, anything with measurable ROI
- **Format fit:** Static (math visual), Carousel (breakdown), Video (case study)
- **Paid/Organic:** Paid (B2B especially)
- **Example hook:** "Our customers save [X hours / $Y] every month. Here's the math."

### 13. Demo / How It Works
- **Trigger:** Curiosity, confidence in product
- **Core message:** "See it in action — it's simpler than you think"
- **Best for:** Apps, tools, physical products with a wow factor
- **Format fit:** Video (screen recording, hands-on), Carousel (step-by-step)
- **Paid/Organic:** Both
- **Example hook:** "Watch how [product] does [impressive thing] in under 60 seconds."

---

## OFFER / DIRECT RESPONSE ANGLES

### 14. Urgency / Scarcity
- **Trigger:** Loss aversion, deadline pressure
- **Core message:** "Act now or miss out"
- **Best for:** E-commerce, SaaS trials, events, seasonal
- **Format fit:** Static (countdown/bold offer), Story
- **Paid/Organic:** Paid (direct response)
- **Example hook:** "Only [X] left. [Offer] ends [date]."

### 15. Free / Risk Reversal
- **Trigger:** Risk removal, zero-barrier entry
- **Core message:** "Try it free. Nothing to lose."
- **Best for:** SaaS, subscriptions, services with strong retention
- **Format fit:** Static, Story
- **Paid/Organic:** Paid (top of funnel)
- **Example hook:** "Try [product] free for 14 days — no credit card required."

### 16. Discount / Deal
- **Trigger:** Value seeking, savings motivation
- **Core message:** "Now is the best time to buy"
- **Best for:** E-commerce, consumer software, events
- **Format fit:** Static (bold % graphic), Story (swipe-up)
- **Paid/Organic:** Paid (conversion campaigns)
- **Example hook:** "[X%] off — this week only."

### 17. Bundle / Value Stack
- **Trigger:** Perceived value, deal mentality
- **Core message:** "Look at everything you get for this price"
- **Best for:** E-commerce, info products, SaaS tiers
- **Format fit:** Carousel (item-by-item reveal), Static (stacked value)
- **Paid/Organic:** Paid
- **Example hook:** "For [price], you get: [list everything]."

---

## CONTENT / ORGANIC-FIRST ANGLES

### 18. Education / How-To
- **Trigger:** Desire for knowledge, self-improvement
- **Core message:** "Here's something valuable you didn't know"
- **Best for:** B2B, coaching, tools, thought leadership
- **Format fit:** Carousel (tips list), Video (tutorial), Static (stat/insight)
- **Paid/Organic:** Organic (saves/shares), Paid (awareness stage)
- **Example hook:** "5 things [audience] should know about [topic]."

### 19. Myth Busting
- **Trigger:** Surprise, recalibration of beliefs
- **Core message:** "What you've been told is wrong"
- **Best for:** Health, finance, marketing, any space with misconceptions
- **Format fit:** Carousel (myth vs. reality), Video (talking head)
- **Paid/Organic:** Organic (highly shareable)
- **Example hook:** "[Common belief] is actually hurting your [goal]. Here's the truth."

### 20. Behind the Scenes / Transparency
- **Trigger:** Trust, authenticity, curiosity
- **Core message:** "Here's how we really do it"
- **Best for:** DTC brands, creator economy, founder-led brands
- **Format fit:** Video (raw/authentic), Carousel (process breakdown)
- **Paid/Organic:** Organic (brand building)
- **Example hook:** "How we [make/do X] — no filters."

### 21. Trend / Cultural Hook
- **Trigger:** Relevance, timeliness, "this is happening now"
- **Core message:** "This is what's happening — and here's your angle on it"
- **Best for:** Any brand that can authentically connect to current events/trends
- **Format fit:** Video (Reels/TikTok trend format), Static (reactive)
- **Paid/Organic:** Organic (virality potential)
- **Example hook:** "Everyone's talking about [trend]. Here's what it means for [audience]."

### 22. Challenge / Controversy
- **Trigger:** Debate, strong opinion, engagement bait (genuine)
- **Core message:** "Here's a hot take — do you agree?"
- **Best for:** Thought leaders, B2B, opinionated brands
- **Format fit:** Static (bold statement), Carousel (debate format)
- **Paid/Organic:** Organic (comment-driving)
- **Example hook:** "Unpopular opinion: [contrarian statement about industry]."

---

## ADVANCED / HYBRID ANGLES

### 23. Storytelling / Narrative Arc
- **Trigger:** Emotional investment, empathy
- **Core message:** "Let me take you on a journey"
- **Best for:** Brand films, founder stories, product origin stories
- **Format fit:** Video (mini-documentary), Carousel (chapter format)
- **Paid/Organic:** Both — video ads with story structure outperform
- **Example hook:** "3 years ago, [founder/customer] had [problem]. This is what happened next."

### 24. Problem-Solution-Proof Stack
- **Trigger:** Rational + emotional combo
- **Core message:** "Here's the problem, here's the fix, here's the evidence"
- **Best for:** SaaS, health, any product solving a clear pain
- **Format fit:** Carousel (3-act structure), Video
- **Paid/Organic:** Paid (mid-funnel)

### 25. Lifestyle Integration
- **Trigger:** Aspiration, "fits my life"
- **Core message:** "This fits seamlessly into your world"
- **Best for:** Consumer products, apps, fashion, food & drink
- **Format fit:** Static (lifestyle photography), Video (day-in-the-life)
- **Paid/Organic:** Both
- **Example hook:** "Made for your [routine / lifestyle / world]."

---

## Angle Selection Framework

Use this matrix when choosing angles:

| Funnel Stage | Best Angles |
|---|---|
| Awareness (cold) | Curiosity, Education, Trend, Relatability, Aspiration |
| Consideration | Transformation, Demo, Comparison, Social Proof, Testimonial |
| Conversion | Urgency, Free/Risk Reversal, Discount, ROI, Value Stack |
| Retention/Loyalty | Behind the Scenes, Storytelling, Community |

| Objective | Best Angles |
|---|---|
| High CTR | Curiosity, FOMO, Pain Amplification, Contrarian |
| High Engagement | Relatable, Myth Busting, Challenge, Trend |
| High Conversion | Testimonial, Social Proof, Risk Reversal, Urgency |
| Brand Building | Aspiration, Storytelling, Identity, Transparency |
