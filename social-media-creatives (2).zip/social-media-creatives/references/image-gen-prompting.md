# Image Generation Prompting for Ad Creatives

How to write prompts that produce scroll-stopping ad images. Covers Ideogram v2, Pollinations, and Stability AI. Includes industry-specific templates and ad format formulas.

---

## The Core Prompt Formula

Every ad image prompt = 7 layers:

```
[1. SUBJECT] + [2. ACTION/CONTEXT] + [3. COMPOSITION] + [4. LIGHTING] + 
[5. STYLE] + [6. MOOD/EMOTION] + [7. TECHNICAL SPEC]
```

Never write a prompt with fewer than 4 layers. 7 layers = consistently great output.

---

## Layer-by-Layer Guide

### Layer 1: Subject
Be hyper-specific. Generic subjects = generic images.

❌ "A woman using a laptop"
✅ "A focused woman in her early 30s, dark hair, minimal jewelry, wearing a soft grey linen shirt, looking at a laptop screen with a slight smile"

❌ "A product shot"
✅ "A sleek matte black protein powder container, lid off, powder slightly spilling, on a white marble surface"

### Layer 2: Action / Context
What is happening? Where are they?

❌ "in an office"
✅ "seated at a minimalist oak desk in a sunlit home office, plants visible in soft focus background, coffee cup to the right"

### Layer 3: Composition
Tell the AI where things should be in frame.

Options:
- `close-up portrait` / `medium shot` / `wide establishing shot`
- `centered subject, negative space on left for text overlay`
- `rule of thirds, subject left, product right`
- `overhead flat lay` / `45-degree product angle` / `eye-level`
- `split composition — before on left, after on right`

### Layer 4: Lighting
Lighting makes or breaks ad images.

| Lighting Type | Use Case | Prompt Words |
|---|---|---|
| Natural window light | Lifestyle, authentic | "soft natural light from left window, gentle shadows" |
| Golden hour | Aspirational, warm brands | "warm golden hour sunlight, long soft shadows" |
| Studio clean | Product shots, SaaS | "clean studio lighting, pure white background, even light" |
| Dramatic side light | Premium, luxury | "dramatic single side light, strong contrast, moody" |
| Overcast outdoor | Real/raw, UGC feel | "overcast daylight, flat even lighting, no harsh shadows" |
| Backlit | Aspirational, energy | "backlit with halo glow, lens flare, energetic" |

### Layer 5: Style
Defines the visual language.

| Style | When to Use | Prompt |
|---|---|---|
| Editorial / Magazine | Fashion, lifestyle, premium | "editorial photography style, magazine quality" |
| UGC / Authentic | TikTok, raw ads, testimonials | "authentic UGC style, slightly grainy, phone camera quality, real and unposed" |
| Clean Product | E-commerce, SaaS, tools | "clean commercial product photography, high detail, sharp" |
| Lifestyle | Consumer goods, services | "lifestyle photography, candid, real moments, not staged" |
| Bold Graphic | Direct response, sales | "bold graphic design, high contrast colors, flat design" |
| 3D Render | Tech, SaaS, abstract products | "3D render, product visualization, studio lighting, hyperrealistic" |
| Minimalist | Premium, B2B, consulting | "minimalist composition, lots of white space, restrained palette" |

### Layer 6: Mood / Emotion
The feeling the image should evoke in the viewer.

Options: `aspirational and warm`, `urgent and energetic`, `calm and trustworthy`, `bold and confident`, `authentic and relatable`, `premium and exclusive`, `playful and fun`, `serious and professional`

### Layer 7: Technical Spec
Always end with platform/format specs.

- `4:5 vertical format, optimized for Instagram feed`
- `9:16 vertical format for TikTok and Reels`
- `1:1 square format for Facebook feed`
- `16:9 horizontal for YouTube thumbnail`
- `leave clean text-safe area on [top/bottom/left/right] for copy overlay`

---

## Negative Prompts (Always Include)

Always add these to prevent common AI image failures:

**Universal negatives:**
```
text, watermarks, logos, blurry, out of focus, low quality, distorted faces, 
extra limbs, unrealistic proportions, stock photo look, overly staged, 
corporate stiffness, oversaturated colors, noise, grain (unless UGC style)
```

**For people:**
```
deformed hands, extra fingers, unnatural skin texture, uncanny valley, 
blank stare, overly perfect teeth, plastic skin
```

**For products:**
```
distorted labels, wrong colors, floating objects, inconsistent shadows, 
reflections showing studio equipment
```

---

## Industry-Specific Prompt Templates

### E-Commerce / Physical Products

**Hero product shot:**
```
[Product name and description], placed on [surface: marble/wood/concrete/fabric], 
[props that support brand: flowers/leaves/coffee/tools], 
flat lay overhead composition OR 45-degree hero angle, 
[brand-appropriate lighting: soft natural / clean studio / warm ambient], 
clean commercial product photography, hyperrealistic detail, 
[dominant brand color] accent in background, 
1:1 square or 4:5 format, text-safe negative space on [side]
```

**Lifestyle product in use:**
```
[Target audience description] using/wearing/holding [product], 
[relatable setting: kitchen / gym / office / outdoors], 
candid authentic moment, not posed, 
[lighting], lifestyle photography style, 
warm and aspirational mood, 4:5 vertical format
```

### SaaS / Digital Tools

**UI mockup in context:**
```
Close-up of [device: MacBook Pro / iPhone 15 / iPad] 
showing a clean modern web app dashboard UI on screen, 
[setting: desk / coffee shop / home office], 
person's hands on keyboard (optional), 
soft bokeh background, 
3D render or editorial photography style, 
professional and aspirational mood, 
1:1 or 4:5 format
```

**Abstract concept for SaaS:**
```
Abstract representation of [concept: growth / connection / automation / data], 
using [brand colors] geometric shapes and flowing lines, 
dark or light background, 
minimal and modern design, 
bold graphic design style, 
no text, 1:1 format
```

### Coaching / Services / Personal Brand

**Authority/Expertise:**
```
[Person description: confident professional, age range, style] 
in a [setting: modern office / speaking on stage / at whiteboard], 
confident posture, direct eye contact with camera, 
[lighting: dramatic side light / clean studio / natural window], 
editorial portrait photography, 
premium and trustworthy mood, 
4:5 vertical, centered composition with space for text overlay
```

**Transformation result:**
```
Before/after split composition: 
left side — [struggling/before state: stressed, overwhelmed, cluttered], 
right side — [after state: calm, successful, organized, glowing], 
[appropriate setting], 
warm aspirational mood on right, muted desaturated mood on left, 
horizontal dividing line or natural split, 1:1 format
```

### Local / Service Business

**Team/Real people:**
```
[Business type] professional team in [work environment], 
genuine smiles, candid moment not posed, 
[relevant props: tools / uniforms / workspace], 
warm natural lighting, 
authentic documentary photography style, 
trustworthy and approachable mood, 
1:1 or 4:5 format
```

**Result/Outcome:**
```
[Before/after of service outcome], 
[e.g.: beautiful renovated kitchen / clean organized space / happy client], 
[setting], professional photography, 
high quality result visible, 
[lighting appropriate to space], 
aspirational and satisfying mood, 
1:1 format
```

---

## Text-on-Image Ideogram Tips

Ideogram v2 is uniquely good at rendering readable text in images — use this for bold headline-on-image ads.

**Text prompt structure:**
```
[Background image description], 
with bold text reading "[YOUR HEADLINE]" displayed prominently 
in [position: top center / large centered / bottom third],
[font style: bold sans-serif / elegant serif / handwritten],
[text color] text on [contrasting background]
```

**Rules for text-in-image:**
- Keep text to 5 words or fewer for reliability
- Specify font style and color explicitly
- Add "high contrast, clearly readable text" to prompt
- Use `magic_prompt_option: "ON"` in Ideogram API — it helps with text placement
- Always check output — regenerate if text is garbled (happens ~20% of the time)

---

## Multi-Creative Consistency (Brand Series)

When generating 10+ creatives for one brand, maintain consistency:

**Consistency seed prompt** — use this prefix on every image:
```
[Base prompt for all images in series]:
"[Brand visual language]: [color palette], [photography style], 
[subject type], [lighting signature], [overall mood]"

Then add creative-specific details after.
```

**Example series anchor:**
```
"Visual language: warm earth tones (terracotta #C4622D, cream #F5ECD7), 
lifestyle photography, real people not models, 
golden hour or soft window light, 
authentic and aspirational mood — "

+ [Creative-specific prompt]
```

---

## Quick Prompt Builder

For fast generation, use this fill-in-the-blank:

```
A [age/gender/type] [subject] [action verb + doing what] 
in a [setting], [composition notes], 
[lighting type] lighting, 
[style] photography/design style, 
[mood] mood, 
[platform format], 
leave text-safe space on [position]
```

Fill in → add negatives → generate → done.

---

## Ideogram API Style Type Selector

| Campaign Type | Style Type | Reasoning |
|---|---|---|
| Lifestyle ads | `REALISTIC` | People in context, product in use |
| Bold direct response | `DESIGN` | High contrast, graphic, text-friendly |
| SaaS / tech product | `RENDER_3D` | Clean product renders, UI mockups |
| Premium brand | `REALISTIC` | Photorealistic editorial quality |
| Young/Gen Z brand | `ANIME` or `DESIGN` | Only if clearly fits brand |
| Abstract concept | `DESIGN` | Geometric, bold, conceptual |

Default to `REALISTIC` when unsure — it's the most versatile for ads.
