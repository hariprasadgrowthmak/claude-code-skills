# Carousel Brief Template

Use this structure for every carousel creative. Carousels work on Instagram, Facebook, and LinkedIn (as PDF/document posts).

---

## Carousel Creative Brief

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CAROUSEL BRIEF
Brand: [Name]
Angle: [Creative angle used]
Framework: [e.g., AIDA / Before-After / List / Problem-Solution]
Platform: [IG / FB / LinkedIn]
Type: [Organic / Paid]
Goal: [Engagement / Awareness / Leads / Conversions]
Audience: [Segment]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CAPTION (Post-level copy):
[Full caption — hook in first line, context, CTA at end]

HASHTAGS: [5-10 for organic, none for paid]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SLIDE BREAKDOWN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SLIDE 1 — HOOK (Most important)
Headline: [Bold, scroll-stopping text — 5-8 words]
Visual: [What should be shown — product, bold graphic, person, stat]
Subtext: [Optional supporting text — max 1 line]
Swipe prompt: [e.g., "Swipe to see →" or arrow indicator]
Design note: [Color, contrast, visual style direction]

SLIDE 2
Headline: [Continues story or deepens hook]
Visual: [Description]
Body text: [2-3 lines max — readable at a glance]
Design note: [...]

SLIDE 3
Headline: [...]
Visual: [...]
Body text: [...]
Design note: [...]

SLIDE 4
Headline: [...]
Visual: [...]
Body text: [...]
Design note: [...]

SLIDE 5 — CTA (Last slide)
Headline: [Clear offer or action]
Visual: [Product / Logo / Result image]
CTA text: [e.g., "Try it free", "DM us", "Link in bio", "Shop now"]
Design note: [Make CTA prominent — contrasting button or bold text]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DESIGN SPECS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Size: [1080×1080px or 1080×1350px — must be consistent across all slides]
Color palette: [Primary, secondary, accent — brand colors or direction]
Typography: [Font style direction — e.g., "bold sans-serif headlines, clean body text"]
Brand elements: [Logo placement, brand icons]
Visual style: [Minimal / Bold / Lifestyle / Data-driven / Illustrative]
Slide consistency: [Note any repeating design elements — progress bar, slide number, corner logo]
```

---

## Carousel Formats by Goal

### Format 1: Listicle / Tips
Best for: Education, organic reach, saves
Structure: Hook → Tip 1 → Tip 2 → Tip 3 → Tip 4 → Tip 5 → CTA
Example: "7 things every [audience] should stop doing"

### Format 2: Before / After Story
Best for: Transformation angles, testimonials
Structure: Hook → Before state → Turning point → After state → How → CTA
Example: "How [customer] went from [X] to [Y] in 60 days"

### Format 3: Problem → Solution
Best for: Paid conversion, pain-driven angles
Structure: Hook (problem) → Agitate → Solution reveal → Proof → Offer → CTA
Example: "Why [problem] keeps happening (and how to fix it)"

### Format 4: Step-by-Step Tutorial
Best for: Demo angles, thought leadership, saves
Structure: Hook → Step 1 → Step 2 → Step 3 → Step 4 → Result → CTA
Example: "The exact process we use to [achieve X]"

### Format 5: Myth vs. Reality
Best for: Contrarian/myth-busting angles, engagement
Structure: Hook → Myth 1 / Reality → Myth 2 / Reality → Myth 3 / Reality → Takeaway → CTA
Example: "[3/5/7] myths about [topic] — debunked"

### Format 6: Comparison / vs.
Best for: Competitor angles, paid retargeting
Structure: Hook → [Old/competitor way] → [New/your way] (side by side) → Proof → CTA
Example: "[Competitor/Old Method] vs. [Your Product] — see the difference"

### Format 7: Data / Stats Story
Best for: B2B, authority building, LinkedIn
Structure: Hook stat → Context → Implication → More data → What to do → CTA
Example: "The [industry] stats that should change how you [do X]"

---

## Carousel Copy Rules

1. **Slide 1 is everything.** The feed shows only the first slide. If it doesn't stop the scroll, nothing else matters. Spend 50% of creative effort here.

2. **Each slide = one idea.** Don't put two points on one slide. Split them.

3. **Text must be readable at 50% zoom.** People see carousels in a small thumbnail before they tap. Test legibility.

4. **Create a "gap" between slides.** Each slide should make the reader want to see the next one. Unfinished thoughts, numbered lists ("3 of 5"), and visual cliffhangers all work.

5. **Last slide must have a CTA.** The last swipe is your highest-intent moment. Never waste it.

6. **Caption and Slide 1 should not be identical.** Caption drives context. Slide 1 drives attention. They should work together, not repeat each other.
