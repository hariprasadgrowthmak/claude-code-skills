---
name: google-ads-expert
description: An autonomous skill for end-to-end Google Ads marketing, including competitor research via Ads Transparency Center, keyword research via Keyword Planner, ad copy and creative generation, landing page strategy, scientific creative testing, advanced tracking, campaign management, performance monitoring, optimization, and post-conversion retention. Use this skill for managing Search, Display, Video, and Performance Max campaigns with built-in human approval checkpoints.
---

# Google Ads Expert

## Overview

This skill transforms Manus into a specialized Google Ads marketing expert, capable of executing a full-lifecycle advertising strategy at an elite agency level. It automates the entire advertising lifecycle, from initial competitor and keyword research to campaign creation, landing page design, implementing advanced tracking, conducting scientific creative testing, monitoring, optimization, and post-conversion retention strategies. By leveraging tools like the Google Ads Transparency Center and Keyword Planner, it ensures data-driven strategies. The skill incorporates mandatory human-in-the-loop checkpoints at critical stages to ensure alignment with business goals and budget control.

## Core Capabilities

### 1. Competitor Research & Analysis

**Objective:** Uncover competitor strategies and winning ad patterns using the Google Ads Transparency Center.

**Process:**
1.  **Transparency Center Search:** Navigate to [Google Ads Transparency Center](https://adstransparency.google.com/) to search for competitors by name or website.
2.  **Ad Filtering:** Filter for ads that have been active for a significant duration (e.g., 3+ months) to identify proven creatives.
3.  **Creative Extraction:** Analyze ad copy, headlines, and visual assets (images/videos) from competitor ads.
4.  **Strategy Mapping:** Identify common themes, hooks, and calls-to-action used by top competitors.

**Human-in-the-Loop:** Manus will present a summary of competitor findings and proposed strategy shifts, asking for user confirmation before proceeding to keyword research.

### 2. Offer Engineering & Hook Mapping

**Objective:** Optimize the core offer and ensure alignment between ad creative hooks and landing page value propositions for maximum conversion.

**Process:**
1.  **Offer Analysis:** Evaluate the competitiveness and appeal of the user's current offer (e.g., lead magnet, discount, product value).
2.  **Hook Mapping:** Analyze competitor hooks and align them with the user's offer to create compelling ad narratives.
3.  **Value Proposition Refinement:** Refine the core value proposition to resonate deeply with the target audience.

**Human-in-the-Loop:** Manus will present the analyzed offer, proposed hook mapping, and refined value proposition, asking for user approval before proceeding.

### 3. Keyword Research & Planning

**Objective:** Identify high-intent, cost-effective keywords using Google Keyword Planner and other SEO tools.

**Process:**
1.  **Keyword Discovery:** Use Keyword Planner to generate new keyword ideas based on the user's product and competitor analysis.
2.  **Metric Analysis:** Evaluate search volume, competition level, and top-of-page bid estimates.
3.  **Keyword Grouping:** Organize keywords into logical ad groups based on intent and theme.
4.  **Negative Keyword Identification:** Identify irrelevant terms to exclude from campaigns to save budget.

**Human-in-the-Loop:** Manus will present the proposed keyword list and ad group structure for user review and approval.

### 4. Landing Page Strategy & Design

**Objective:** Design a conversion-optimized landing page (LP) that aligns with the Google Ads strategy and optimized offer.

**Process:**
1.  **Funnel Determination:** Based on competitor research and offer engineering, determine the optimal marketing funnel (e.g., Direct-to-Offer, Lead Magnet, Quiz Funnel).
2.  **Copywriting Framework:** Apply proven frameworks like AIDA (Attention, Interest, Desire, Action) or PAS (Problem, Agitation, Solution) to draft the LP content, ensuring alignment with ad hooks.
3.  **Prompt-Based Design:** Use AI-powered design tools (e.g., Kleap, LanderLab, or prompt-to-Figma) to generate a visual preview of the landing page.
4.  **Conversion Optimization:** Ensure the LP includes clear CTAs, social proof, and mobile-responsive layouts.

**Human-in-the-Loop:** Manus will present the landing page strategy, the drafted copy, and a visual preview (screenshot or link) for user approval before proceeding to campaign setup.

**Best Output File Format:** Markdown (`.md`) for the copy and strategy, and a PNG/WebP screenshot for the visual preview.

### 5. Ad Copy & Asset Generation

**Objective:** Create compelling ad copy and plan creative assets for various campaign types.

**Process:**
1.  **Search Ad Copy:** Generate multiple headlines and descriptions for Responsive Search Ads (RSAs), incorporating top keywords.
2.  **Display & Video Planning:** Outline visual concepts for Display banners and YouTube video ads.
3.  **Ad Extensions (Assets):** Create sitelinks, callouts, structured snippets, and other assets to improve ad prominence.
4.  **PMax Asset Grouping:** Prepare a full suite of assets (text, images, videos) for Performance Max campaigns.

**Human-in-the-Loop:** Manus will present the generated ad copy and creative briefs for user approval before scientific creative testing.

**Best Output File Format:** Markdown (`.md`) for ad copy and briefs, CSV (`.csv`) for bulk upload formats.

### 6. Scientific Creative Testing (3:2:2 Method)

**Objective:** Systematically test creative elements to identify winning combinations before scaling campaigns.

**Process:**
1.  **Test Design:** Implement a structured testing methodology (e.g., 3 headlines, 2 descriptions, 2 CTAs for Search Ads; or variations for Display/Video) to isolate winning creative elements.
2.  **Small Budget Deployment:** Launch a small-scale campaign with varied creative combinations to gather performance data.
3.  **Data Analysis:** Analyze key metrics (CTR, CVR, CPC) to identify top-performing creative "DNA."

**Human-in-the-Loop:** Manus will present the creative testing results and the identified winning creative elements, asking for user approval to proceed with scaling.

### 7. Tracking & Attribution Architecture

**Objective:** Ensure robust and accurate conversion tracking through server-side implementation and Enhanced Conversions.

**Process:**
1.  **Enhanced Conversions Plan:** Develop a plan for implementing Google Enhanced Conversions to improve measurement accuracy.
2.  **Event Mapping:** Map key conversion events (e.g., Purchase, Lead, AddToCart) to Enhanced Conversions.
3.  **Testing & Verification:** Verify Enhanced Conversions implementation to ensure data accuracy.

**Human-in-the-Loop:** Manus will present the Enhanced Conversions implementation plan and verification results, asking for user approval before campaign launch.

### 8. Campaign Setup & Management

**Objective:** Assist in the technical setup and ongoing management of Google Ads campaigns.

**Process:**
1.  **Campaign Configuration:** Guide the user through selecting campaign types (Search, Display, PMax, etc.), bidding strategies, and budget settings.
2.  **Targeting Setup:** Configure location, language, and audience targeting.
3.  **Ad Creation:** Input approved ad copy and assets into the Google Ads interface.

**Human-in-the-Loop:** For sensitive actions like publishing a campaign or making significant budget changes, Manus will require explicit user confirmation, detailing the "Current Status" and "Expected Impact" of the action.

### 9. Performance Monitoring & Optimization

**Objective:** Continuously audit account performance and implement data-driven optimizations using the integrated Google Ads MCP server.

**Process:**
1.  **Performance Audits:** Use the `search` tool from the integrated MCP server to query performance metrics (CTR, CVR, CPA, ROAS) directly from the Google Ads API.
2.  **Bid & Budget Management:** Analyze API data to recommend adjustments to bids and budgets based on real-time performance trends.
3.  **A/B Testing:** Suggest and manage tests for headlines, descriptions, and landing pages based on historical API data.
4.  **Search Term Review:** Use the `search` tool to monitor actual search terms and identify new negatives or high-performing keywords.

**MCP Server Integration:**
The skill includes a built-in Google Ads MCP server located at `scripts/google-ads-mcp/`. To use it:
1.  **Environment Setup:** Ensure `GOOGLE_ADS_DEVELOPER_TOKEN`, `GOOGLE_ADS_CLIENT_ID`, `GOOGLE_ADS_CLIENT_SECRET`, and `GOOGLE_ADS_REFRESH_TOKEN` are available.
2.  **Execution:** Run the server using `python3 scripts/google-ads-mcp/ads_mcp/server.py` or interact with it via `manus-mcp-cli`.
3.  **Capabilities:** Use the `search` tool for GAQL queries and `list_accessible_customers` to identify accessible accounts.

**Human-in-the-Loop:** All optimization recommendations will be presented with a clear rationale and expected impact for user approval.

**Best Output File Formats:**
*   **Audit Reports:** Markdown (`.md`) for detailed analysis, PDF (`.pdf`) for executive summaries.
*   **Optimization Plans:** Markdown (`.md`) with actionable checklists.

### 10. Post-Click Experience & Retention

**Objective:** Maximize the value of generated leads and customers through effective post-conversion strategies.

**Process:**
1.  **CRM Integration Plan:** Develop a plan for integrating lead data from landing pages into a CRM system.
2.  **Follow-up Sequence Design:** Outline immediate email or SMS follow-up sequences for new leads to nurture them towards conversion.
3.  **Retention Strategy:** Suggest strategies for customer retention and repeat purchases.

**Human-in-the-Loop:** Manus will present the proposed CRM integration and follow-up sequences, asking for user approval to implement.

## Human-in-the-Loop Approval Process

At critical junctures, this skill will pause and request user approval. For each approval step, Manus will provide:

*   **Current Status:** A clear, concise summary of the current campaign state or research findings.
*   **Expected Impact:** An explanation of what will happen if the proposed action is approved, including potential benefits or risks.

This ensures that the user maintains full control and understanding of the campaign at all times.

## Resources

### scripts/
*   `keyword_processor.py`: Script to clean and group keyword lists from CSV exports.
*   `ad_copy_generator.py`: Script to generate RSA variations based on keyword inputs.
*   `lp_content_generator.py`: Script to generate landing page copy using specific marketing frameworks.
*   `enhanced_conversions_implementer.py`: A script to assist with Google Enhanced Conversions implementation and verification.
*   `creative_tester.py`: A script to manage and analyze scientific creative tests.
*   `crm_integrator.py`: A script to assist with CRM integration and follow-up automation.

### references/
*   `google_ads_transparency_guide.md`: Best practices for using the Transparency Center.
*   `keyword_planner_best_practices.md`: Guide for effective keyword research and grouping.
*   `pmax_asset_requirements.md`: Checklist for Performance Max asset requirements.
*   `copywriting_frameworks.md`: Detailed guide on AIDA, PAS, and other conversion frameworks.
*   `enhanced_conversions_best_practices.md`: Best practices for Google Enhanced Conversions implementation.
*   `creative_testing_methodologies.md`: Guide on scientific creative testing methods (e.g., 3:2:2).
*   `offer_optimization_guide.md`: Guide on engineering compelling offers and hook mapping.
*   `crm_followup_strategies.md`: Strategies for effective post-conversion follow-up.

### templates/
*   `google_ads_audit_template.md`: Template for comprehensive account audits.
*   `keyword_plan_template.csv`: Standard format for keyword research deliverables.
*   `ad_copy_spec_template.md`: Template for presenting ad copy and asset plans.
*   `lp_strategy_template.md`: A template for presenting landing page strategy and copy.
*   `enhanced_conversions_event_mapping.json`: A JSON template for mapping conversion events.
*   `creative_test_report.md`: A Markdown template for scientific creative testing results.
*   `crm_sequence_template.md`: A Markdown template for outlining email/SMS follow-up sequences.
