# Google Keyword Planner Best Practices

This document outlines best practices for leveraging Google Keyword Planner for effective keyword research and planning.

## Accessing Keyword Planner

Keyword Planner is available within your Google Ads account.

## Key Features for Keyword Research

1.  **Discover New Keywords:**
    *   Enter product/service terms or a website to get keyword ideas.
    *   Filter by location, language, and negative keywords.
2.  **Get Search Volume and Forecasts:**
    *   Analyze historical metrics (average monthly searches, competition).
    *   Review bid estimates (top of page bid low/high range) to gauge cost-effectiveness.
3.  **Organize Keywords:**
    *   Group related keywords into themes for ad group creation.
    *   Identify long-tail keywords for more specific targeting.

## Best Practices for AI Agents

*   **Iterative Discovery:** Perform multiple rounds of keyword discovery, refining inputs based on initial results.
*   **Data Extraction:** Systematically extract relevant metrics (search volume, competition, bid ranges) for analysis.
*   **Intent-Based Grouping:** Prioritize grouping keywords by user intent to ensure ad relevance.
*   **Negative Keyword Strategy:** Proactively identify and recommend negative keywords to improve ad spend efficiency.
*   **Seasonal Trends:** Account for seasonal fluctuations in search volume when planning campaigns.
