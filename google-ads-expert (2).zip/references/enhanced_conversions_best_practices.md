# Google Enhanced Conversions Best Practices

This document outlines best practices for implementing and verifying Google Enhanced Conversions to improve measurement accuracy and campaign optimization.

## 1. What are Enhanced Conversions?

*   **Definition:** Enhanced conversions improve the accuracy of your conversion measurement by supplementing your existing conversion tags with first-party customer data from your website.
*   **How it works:** It securely hashes and sends first-party customer data (like email addresses) from your website to Google in a privacy-safe way. This data is then used to match your customers to Google accounts, providing a more accurate view of ad performance.

## 2. Implementation Steps

1.  **Enable Enhanced Conversions:** Turn on enhanced conversions in your Google Ads account settings.
2.  **Choose an Implementation Method:**
    *   **Global Site Tag (gtag.js):** Manually modify your website code to send hashed data.
    *   **Google Tag Manager (GTM):** Configure GTM to automatically collect, hash, and send customer data.
    *   **Google Ads API:** Programmatically send hashed data directly to Google Ads.
3.  **Collect First-Party Data:** Ensure you are collecting customer-provided data (e.g., email, phone number, name, address) at the time of conversion.
4.  **Hash Data:** All customer data must be hashed using the SHA256 algorithm before being sent to Google.

## 3. Verification

*   **Google Tag Assistant:** Use Google Tag Assistant to verify that enhanced conversions are firing correctly.
*   **Google Ads Diagnostics:** Check the diagnostics section in your Google Ads account for any issues or warnings related to enhanced conversions.
*   **Data Comparison:** Compare reported conversions with and without enhanced conversions to observe the impact on measurement accuracy.
