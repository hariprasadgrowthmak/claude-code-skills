# Performance Max Asset Requirements

This document outlines the essential asset requirements for Google Ads Performance Max campaigns.

## Overview

Performance Max campaigns automatically serve ads across all Google channels (Search, Display, YouTube, Gmail, Discover) using a single campaign. To maximize reach and performance, it requires a diverse set of high-quality assets.

## Required Assets

| Asset Type | Minimum | Recommended | Specifications |
| :--------- | :------ | :---------- | :------------- |
| **Headlines** | 3 | 5 | Max 30 characters each. |
| **Long Headlines** | 1 | 5 | Max 90 characters each. |
| **Descriptions** | 2 | 4 | Max 90 characters each. |
| **Business Name** | 1 | 1 | Max 25 characters. |
| **Final URL** | 1 | 1 | Landing page URL. |
| **Images (Landscape)** | 1 | 15 | 1200x628 (1.91:1 aspect ratio). Max 5120KB. |
| **Images (Square)** | 1 | 15 | 1200x1200 (1:1 aspect ratio). Max 5120KB. |
| **Images (Portrait)** | 0 | 5 | 960x1200 (4:5 aspect ratio). Max 5120KB. |
| **Logos (Square)** | 1 | 5 | 1200x1200 (1:1 aspect ratio). Max 5120KB. |
| **Logos (Landscape)** | 0 | 5 | 1200x300 (4:1 aspect ratio). Max 5120KB. |
| **Videos** | 0 | 5 | At least 10 seconds long. Upload to YouTube and link. |

## Best Practices for Assets

*   **Variety:** Provide as many high-quality assets as possible to allow Google AI to optimize across formats and placements.
*   **Relevance:** Ensure all assets are highly relevant to your product/service and target audience.
*   **Quality:** Use professional-grade images and videos. Avoid blurry or low-resolution assets.
*   **Clear Messaging:** Headlines and descriptions should be clear, concise, and highlight unique selling propositions.
*   **Call to Action:** Include strong calls to action in your text assets.
*   **Unique Content:** Avoid duplicating content across different asset types.

## Asset Groups

Performance Max organizes assets into "Asset Groups." Each asset group should be themed around a specific product, service, or audience segment. Google AI will mix and match assets within an asset group to create the most effective ad combinations.
